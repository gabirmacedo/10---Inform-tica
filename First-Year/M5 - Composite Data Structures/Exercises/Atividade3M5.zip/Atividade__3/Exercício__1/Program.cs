﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício__1
{
    internal class Program
    {
        static string PedirNome()
        {
            Console.WriteLine("Introduza um nome");
            return Console.ReadLine();
        }
        static int GeraNota()
        {
            
            int aleatório = new Random().Next(0, 21);
            return aleatório;
            
        }
        struct Aluno
        {
            public string nome;
            public int nota;
        }
        static void Main(string[] args)
        {
            Aluno[] alunos = new Aluno[5];
            double soma = 0;
            Console.WriteLine("A seguir, insira 5 nomes");
            for (int i = 0; i < alunos.Length; i++)
            { 
                alunos[i].nome = PedirNome();
                alunos[i].nota = GeraNota();
                Console.WriteLine(PedirNome() + " - " + GeraNota());
                soma = soma + GeraNota();
            }

            Console.WriteLine("A média é igual a " + soma/alunos.Length);
            Console.ReadKey();
           
        }
    }
}
