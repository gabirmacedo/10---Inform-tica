﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_de_avaliação
{
    public partial class form_menu : Form
    {
        public form_menu()
        {
            InitializeComponent();
        }

        private void form_menu_Load(object sender, EventArgs e)
        {

        }

        private void bt_cliente_Click(object sender, EventArgs e)
        {
            form_clientes form_clientes = new form_clientes();
            form_clientes.ShowDialog();
            this.Close();
        }

        private void bt_livro_Click(object sender, EventArgs e)
        {
            form_livros form_livros = new form_livros();
            form_livros.ShowDialog();
            this.Close();
        }

        private void bt_compra_Click(object sender, EventArgs e)
        {
            form_compras form_compras = new form_compras();
            form_compras.ShowDialog();
            this.Close();
        }
    }
}
