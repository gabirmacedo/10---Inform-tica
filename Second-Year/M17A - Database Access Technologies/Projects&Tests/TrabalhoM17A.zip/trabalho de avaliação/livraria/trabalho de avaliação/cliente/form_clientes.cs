﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using trabalho_de_avaliação.cliente;

namespace trabalho_de_avaliação
{ 
    public partial class form_clientes : Form
    {
        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=livraria";
        struct Cliente
        {
            public int idcliente;
            public string nome;
            public int nif;
            public int ncompra;
            public string morada;
            public string email;
        }
        List<Cliente> clientes = new List<Cliente>();
        Cliente cliente = new Cliente();
        private void LimparCampos()
        {
            tb_nomecli.Text = "";
            tb_nif.Text = "";
            tb_morada.Text = "";
            tb_email.Text = "";
            
        }
        public form_clientes()
        {
            InitializeComponent();
        }
        private void Preencher()
        {
            string sql = "select * from cliente";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cliente.idcliente = reader.GetInt32("idcliente");
                        cliente.nome = reader.GetString("nomecliente");
                        cliente.nif = reader.GetInt32("nif");
                        cliente.ncompra = reader.GetInt32("ncompras");
                        cliente.morada = reader.GetString("morada");
                        cliente.email = reader.GetString("email");

                        clientes.Add(cliente);
                    }
                }
            }
        }
        private void form_clientes_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();

                Preencher();
                tb_idcli.Text = (clientes.Count() + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(form_clientes.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_inserir_Click(object sender, EventArgs e)
        {
            if (tb_idcli.Text != "" && tb_nomecli.Text != "" && tb_nif.Text != "" && tb_morada.Text != "" && tb_email.Text != "" )
            {

                cliente.idcliente = Convert.ToInt32(tb_idcli.Text);
                cliente.nome = tb_nomecli.Text;
                cliente.nif = Convert.ToInt32(tb_nif.Text);
                cliente.morada = tb_morada.Text;
                cliente.email = tb_email.Text;

                clientes.Add(cliente);

                string sql = "insert into livraria.cliente values(@idcliente,@nomecliente,@nif,@ncompras,@morada,@email)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@idcliente", null);
                    cmd.Parameters.AddWithValue("@nomecliente", cliente.nome);
                    cmd.Parameters.AddWithValue("@nif", cliente.nif);
                    cmd.Parameters.AddWithValue("@ncompras", 0);
                    cmd.Parameters.AddWithValue("@morada", cliente.morada);
                    cmd.Parameters.AddWithValue("@email", cliente.email);

                    cmd.ExecuteNonQuery();

                }

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
            tb_idcli.Text = (clientes.Count() + 1).ToString();
        }

        private void bt_limpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void bt_consultar_Click(object sender, EventArgs e)
        {
            form_listcli listagem = new form_listcli();
            foreach (Cliente a in clientes)
            {
                listagem.listagem_cli.Rows.Add(
                a.idcliente, a.nome, a.nif,a.ncompra, a.morada, a.email);
            }
            listagem.Show();
        }
        private void bt_voltar_Click(object sender, EventArgs e)
        {
            form_menu form_menu = new form_menu();
            form_menu.ShowDialog();
            this.Close();
        }
    }
}
