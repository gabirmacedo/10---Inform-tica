﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Projeto_Gabriella
{
    class Program
    {
        static void PreencherLoja(ref Distribuidora[] quantloja)
        {
            for (int i = 0; i < quantloja.Length; i++)
            {
                Console.WriteLine("Introduza o nome da " + (1 + i) + "º loja");
                quantloja[i].nomeloja = Console.ReadLine();
            }
        }

        static void PreencherBolacha(ref Distribuidora[] quantloja, int mes)
        {
            double soma2 = 0;
            double[] mediaLojas = new double[quantloja.Length];

            for (int i = 0; i < mes; i++)
            {
                double soma1 = 0;
                for (int j = 0; j < quantloja.Length; j++)
                {
                    Console.WriteLine("Introduza o nome do tipo de bolacha que a loja " + quantloja[j].nomeloja + " comprou no mês " + (i + 1));
                    quantloja[j].tipobolacha = Console.ReadLine();

                    Console.WriteLine("Introduza a quantidade comprada");
                    string resptxt = Console.ReadLine();
                    if (double.TryParse(resptxt, out quantloja[j].quant) == false)
                    {
                        do
                        {
                            Console.WriteLine("Deve ser introduzido um valor numérico");
                            Console.WriteLine("Introduza a quantidade comprada");
                            resptxt = Console.ReadLine();
                        } while (double.TryParse(resptxt, out quantloja[j].quant) == false);
                    }

                    Console.WriteLine("Introduza o preço do tipo de bolacha que a loja " + quantloja[j].nomeloja + " comprou no mês " + (i + 1));
                    resptxt = Console.ReadLine();
                    if (double.TryParse(resptxt, out quantloja[j].preçobolacha) == false)
                    {
                        do
                        {
                            Console.WriteLine("Deve ser introduzido um valor numérico");
                            Console.WriteLine("Introduza o preço do tipo de bolacha que a loja " + quantloja[j].nomeloja + " comprou no mês " + (i + 1));
                            resptxt = Console.ReadLine();
                        } while (double.TryParse(resptxt, out quantloja[j].preçobolacha) == false);
                    }
                    
                    soma1 = soma1 + (quantloja[j].preçobolacha * quantloja[j].quant);
                    mediaLojas[j] = mediaLojas[j] + (quantloja[j].preçobolacha * quantloja[j].quant);
                }
                Console.WriteLine("");
                Console.WriteLine("A média das " + quantloja.Length + " lojas no mês " + (i + 1) + " é " + (soma1 / quantloja.Length));
                soma2 = soma2 + soma1;
                Console.WriteLine("");
            }
            Console.WriteLine("");
            Console.WriteLine("A média de todos os meses é " + (soma2 / mes));

            int melhorLoja = 0;
            for (int i = 1; i < quantloja.Length; i++)
            {
                if (mediaLojas[i] > mediaLojas[melhorLoja])
                {
                    melhorLoja = i;
                }
            }
            
            Console.WriteLine("A loja com maior média de compras foi " + quantloja[melhorLoja].nomeloja + " com média de " + (mediaLojas[melhorLoja] / mes));
        }

        struct Distribuidora
        {
            public string nomeloja;
            public string tipobolacha;
            public double preçobolacha;
            public double quant;

        }
        static void MostrarComércio(ref Distribuidora[] quantloja)
        {
            for (int i = 0; i < quantloja.Length; i++)
            {
                Console.WriteLine("");
                Console.WriteLine("Loja: " + quantloja[i].nomeloja);
                Console.WriteLine("Tipo de Bolacha: " + quantloja[i].tipobolacha);
                Console.WriteLine("Quantidade Comprada: " + quantloja[i].quant);
                Console.WriteLine("Preço Unitário: " + quantloja[i].preçobolacha);
                Console.WriteLine("Valor Total: " + (quantloja[i].preçobolacha * quantloja[i].quant));
            }
        }

        static void Main()
        {
            int resp1;
            Console.WriteLine("Quantas Lojas estão associadas a sua distribuidora?");
            string resp1txt = Console.ReadLine();
            if (int.TryParse(resp1txt, out resp1) == false)
            {
                do
                {
                    Console.WriteLine("Deve ser introduzido um valor numérico");
                    Console.WriteLine("Quantas Lojas estão associadas a sua distribuidora?");
                    resp1txt = Console.ReadLine();
                } while (int.TryParse(resp1txt, out resp1) == false);
            }

            Distribuidora[] quantloja = new Distribuidora[resp1];
            PreencherLoja(ref quantloja);

            int mes;
            Console.WriteLine("Introduza o mês em que estamos");
            string resptxt = Console.ReadLine();
            if (int.TryParse(resptxt, out mes) == false)
            {
                do
                {
                    Console.WriteLine("Deve ser introduzido um valor numérico");
                    Console.WriteLine("Introduza o mês em que estamos");
                    resp1txt = Console.ReadLine();
                } while (int.TryParse(resptxt, out mes) == false);
            }

            PreencherBolacha(ref quantloja, mes);
            MostrarComércio(ref quantloja);

            Console.ReadKey();
        }
    }
}
