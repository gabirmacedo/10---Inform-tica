﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Exercício__
{
    internal class Program
    {
        static void Main(string[] args)
        {
            String S1;

            S1 = "Computador";
            Console.WriteLine(S1);
            char[] S2 = new char[10];

            for (int i = 0; i < S1.Length; i++) 
            { 
            S2[i] = S1[i]; //wwwwwww
            }

            for (int i = 0; i < S1.Length; i++)
            {
                Console.Write(S1[i]);
            }
            Console.WriteLine();

            //for (int i = 0; i < S1.Length; i++) {Console.WriteLine(S1[i]);}

            for (int i = 0; i < S2.Length; i++)
            {
                S2[i] = S1[i]; //wwwwwww
            }

            Console.ReadKey();
        }
    }
}
