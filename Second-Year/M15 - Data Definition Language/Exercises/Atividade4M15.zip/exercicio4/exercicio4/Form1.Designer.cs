﻿namespace exercicio4
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.cbx_russo = new System.Windows.Forms.CheckBox();
            this.cbx_portugues = new System.Windows.Forms.CheckBox();
            this.cbx_frances = new System.Windows.Forms.CheckBox();
            this.cbx__espanhol = new System.Windows.Forms.CheckBox();
            this.cbx_alemao = new System.Windows.Forms.CheckBox();
            this.cbx_ingles = new System.Windows.Forms.CheckBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prova = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prova2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Aptidão = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Linguas = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Situação = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.cb_apt = new System.Windows.Forms.ComboBox();
            this.cb_oral = new System.Windows.Forms.ComboBox();
            this.cb_esc = new System.Windows.Forms.ComboBox();
            this.txtbox_nome = new System.Windows.Forms.TextBox();
            this.bt_submeter = new System.Windows.Forms.Button();
            this.bt_limpar = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.cbx_russo);
            this.groupBox1.Controls.Add(this.cbx_portugues);
            this.groupBox1.Controls.Add(this.cbx_frances);
            this.groupBox1.Controls.Add(this.cbx__espanhol);
            this.groupBox1.Controls.Add(this.cbx_alemao);
            this.groupBox1.Controls.Add(this.cbx_ingles);
            this.groupBox1.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(25, 384);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(626, 235);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Conhecimento de Línguas";
            this.groupBox1.Enter += new System.EventHandler(this.groupBox1_Enter);
            // 
            // cbx_russo
            // 
            this.cbx_russo.AutoSize = true;
            this.cbx_russo.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_russo.Location = new System.Drawing.Point(293, 163);
            this.cbx_russo.Name = "cbx_russo";
            this.cbx_russo.Size = new System.Drawing.Size(90, 30);
            this.cbx_russo.TabIndex = 5;
            this.cbx_russo.Text = "Russo";
            this.cbx_russo.UseVisualStyleBackColor = true;
            // 
            // cbx_portugues
            // 
            this.cbx_portugues.AutoSize = true;
            this.cbx_portugues.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_portugues.Location = new System.Drawing.Point(293, 114);
            this.cbx_portugues.Name = "cbx_portugues";
            this.cbx_portugues.Size = new System.Drawing.Size(134, 30);
            this.cbx_portugues.TabIndex = 4;
            this.cbx_portugues.Text = "Português";
            this.cbx_portugues.UseVisualStyleBackColor = true;
            // 
            // cbx_frances
            // 
            this.cbx_frances.AutoSize = true;
            this.cbx_frances.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_frances.Location = new System.Drawing.Point(293, 62);
            this.cbx_frances.Name = "cbx_frances";
            this.cbx_frances.Size = new System.Drawing.Size(110, 30);
            this.cbx_frances.TabIndex = 3;
            this.cbx_frances.Text = "Francês";
            this.cbx_frances.UseVisualStyleBackColor = true;
            // 
            // cbx__espanhol
            // 
            this.cbx__espanhol.AutoSize = true;
            this.cbx__espanhol.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx__espanhol.Location = new System.Drawing.Point(35, 163);
            this.cbx__espanhol.Name = "cbx__espanhol";
            this.cbx__espanhol.Size = new System.Drawing.Size(122, 30);
            this.cbx__espanhol.TabIndex = 2;
            this.cbx__espanhol.Text = "Espanhol";
            this.cbx__espanhol.UseVisualStyleBackColor = true;
            // 
            // cbx_alemao
            // 
            this.cbx_alemao.AutoSize = true;
            this.cbx_alemao.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_alemao.Location = new System.Drawing.Point(35, 114);
            this.cbx_alemao.Name = "cbx_alemao";
            this.cbx_alemao.Size = new System.Drawing.Size(109, 30);
            this.cbx_alemao.TabIndex = 1;
            this.cbx_alemao.Text = "Alemão";
            this.cbx_alemao.UseVisualStyleBackColor = true;
            // 
            // cbx_ingles
            // 
            this.cbx_ingles.AutoSize = true;
            this.cbx_ingles.Font = new System.Drawing.Font("Miriam Libre", 9.999999F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbx_ingles.Location = new System.Drawing.Point(35, 63);
            this.cbx_ingles.Name = "cbx_ingles";
            this.cbx_ingles.Size = new System.Drawing.Size(98, 30);
            this.cbx_ingles.TabIndex = 0;
            this.cbx_ingles.Text = "Inglês";
            this.cbx_ingles.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeColumns = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Nome,
            this.Prova,
            this.Prova2,
            this.Aptidão,
            this.Linguas,
            this.Situação});
            this.dataGridView1.Location = new System.Drawing.Point(688, 58);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersVisible = false;
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 28;
            this.dataGridView1.Size = new System.Drawing.Size(783, 634);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // Nome
            // 
            this.Nome.HeaderText = "Nome";
            this.Nome.MinimumWidth = 8;
            this.Nome.Name = "Nome";
            this.Nome.Width = 450;
            // 
            // Prova
            // 
            this.Prova.HeaderText = "Esc.";
            this.Prova.MinimumWidth = 8;
            this.Prova.Name = "Prova";
            this.Prova.Width = 50;
            // 
            // Prova2
            // 
            this.Prova2.HeaderText = "Oral";
            this.Prova2.MinimumWidth = 8;
            this.Prova2.Name = "Prova2";
            this.Prova2.Width = 50;
            // 
            // Aptidão
            // 
            this.Aptidão.HeaderText = "Apt.";
            this.Aptidão.MinimumWidth = 8;
            this.Aptidão.Name = "Aptidão";
            this.Aptidão.Width = 50;
            // 
            // Linguas
            // 
            this.Linguas.HeaderText = "Línguas";
            this.Linguas.MinimumWidth = 8;
            this.Linguas.Name = "Linguas";
            this.Linguas.Width = 80;
            // 
            // Situação
            // 
            this.Situação.HeaderText = "Situação";
            this.Situação.MinimumWidth = 8;
            this.Situação.Name = "Situação";
            this.Situação.Width = 150;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(51, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 32);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nome";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(51, 159);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(164, 32);
            this.label2.TabIndex = 3;
            this.label2.Text = "Prova Escrita";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(54, 226);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(131, 32);
            this.label3.TabIndex = 4;
            this.label3.Text = "Prova Oral";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(54, 286);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(174, 32);
            this.label4.TabIndex = 5;
            this.label4.Text = "Aptidão física";
            // 
            // cb_apt
            // 
            this.cb_apt.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_apt.FormattingEnabled = true;
            this.cb_apt.Location = new System.Drawing.Point(236, 283);
            this.cb_apt.Name = "cb_apt";
            this.cb_apt.Size = new System.Drawing.Size(289, 40);
            this.cb_apt.TabIndex = 6;
            // 
            // cb_oral
            // 
            this.cb_oral.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_oral.FormattingEnabled = true;
            this.cb_oral.Location = new System.Drawing.Point(236, 223);
            this.cb_oral.Name = "cb_oral";
            this.cb_oral.Size = new System.Drawing.Size(289, 40);
            this.cb_oral.TabIndex = 7;
            // 
            // cb_esc
            // 
            this.cb_esc.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cb_esc.FormattingEnabled = true;
            this.cb_esc.Location = new System.Drawing.Point(233, 155);
            this.cb_esc.Name = "cb_esc";
            this.cb_esc.Size = new System.Drawing.Size(289, 40);
            this.cb_esc.TabIndex = 8;
            // 
            // txtbox_nome
            // 
            this.txtbox_nome.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtbox_nome.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox_nome.Location = new System.Drawing.Point(145, 83);
            this.txtbox_nome.Name = "txtbox_nome";
            this.txtbox_nome.Size = new System.Drawing.Size(377, 39);
            this.txtbox_nome.TabIndex = 9;
            // 
            // bt_submeter
            // 
            this.bt_submeter.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_submeter.Location = new System.Drawing.Point(25, 649);
            this.bt_submeter.Name = "bt_submeter";
            this.bt_submeter.Size = new System.Drawing.Size(279, 43);
            this.bt_submeter.TabIndex = 10;
            this.bt_submeter.Text = "Submeter";
            this.bt_submeter.UseVisualStyleBackColor = true;
            this.bt_submeter.Click += new System.EventHandler(this.bt_submeter_Click);
            // 
            // bt_limpar
            // 
            this.bt_limpar.Font = new System.Drawing.Font("Miriam Libre", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_limpar.Location = new System.Drawing.Point(372, 649);
            this.bt_limpar.Name = "bt_limpar";
            this.bt_limpar.Size = new System.Drawing.Size(279, 43);
            this.bt_limpar.TabIndex = 11;
            this.bt_limpar.Text = "Limpar";
            this.bt_limpar.UseVisualStyleBackColor = true;
            this.bt_limpar.Click += new System.EventHandler(this.bt_limpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 21F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(1516, 787);
            this.Controls.Add(this.bt_limpar);
            this.Controls.Add(this.bt_submeter);
            this.Controls.Add(this.txtbox_nome);
            this.Controls.Add(this.cb_esc);
            this.Controls.Add(this.cb_oral);
            this.Controls.Add(this.cb_apt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Miriam Libre", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.CheckBox cbx_russo;
        private System.Windows.Forms.CheckBox cbx_portugues;
        private System.Windows.Forms.CheckBox cbx_frances;
        private System.Windows.Forms.CheckBox cbx__espanhol;
        private System.Windows.Forms.CheckBox cbx_alemao;
        private System.Windows.Forms.CheckBox cbx_ingles;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox cb_apt;
        private System.Windows.Forms.ComboBox cb_oral;
        private System.Windows.Forms.ComboBox cb_esc;
        private System.Windows.Forms.TextBox txtbox_nome;
        private System.Windows.Forms.Button bt_submeter;
        private System.Windows.Forms.Button bt_limpar;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prova;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prova2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Aptidão;
        private System.Windows.Forms.DataGridViewTextBoxColumn Linguas;
        private System.Windows.Forms.DataGridViewTextBoxColumn Situação;
    }
}

