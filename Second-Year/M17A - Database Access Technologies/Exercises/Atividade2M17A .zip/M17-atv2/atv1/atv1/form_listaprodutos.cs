﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv1
{
    public partial class lista_produtos : Form
    {
        public lista_produtos()
        {
            InitializeComponent();
        }

        private void lista_produtos_Load(object sender, EventArgs e)
        {
            lista_produtos listagem = new lista_produtos();
        }
    }
}
