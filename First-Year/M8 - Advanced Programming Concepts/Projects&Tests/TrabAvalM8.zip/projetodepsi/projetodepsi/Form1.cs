﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Contracts;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;

namespace projetodepsi
{
    public partial class Form1 : Form
    {
        static bool TemDigito(string palavra)
        {
            foreach (char a in palavra)
            {
                if (char.IsDigit(a))
                {
                    return true;
                }
            }
            return false;
        }

        static bool NaLista(List<Aluno> c, string n)
        {
            foreach (Aluno a in c)
            {
                if (a.processo == n)
                    return true;
            }
            return false;
        }

        public Form1()
        {
            InitializeComponent();
        }
        struct Aluno
        {
            public string nome;
            public int idade;
            public string processo;
            public int ano;
            public int curso;
            public string nomeed;
            public int contactoed;
        }

        List<Aluno> alunos = new List<Aluno>();
        Aluno a = new Aluno();

        int num;

        private void Sair_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.Exit();
        }

        private void Mostrar_Click(object sender, EventArgs e)
        {
            GBIntrodução.Visible = false;
            alteraraluno.Visible = false;
            preencheraluno.Visible = false;
            processoaluno.Visible = false;
            processoalunolb.Visible = false;
            nomealuno.Enabled = false;
            idadealuno.Enabled = false;
            nomed.Enabled = false;
            contactoed.Enabled = false;
            anoaluno.Enabled = false;
            cursoaluno.Enabled = false;
            concluirinscricao.Visible = false;
            aplicarinfo.Visible = false;
        }

        private void ndoprocesso_TextChanged(object sender, EventArgs e)
        {

        }

        private void Alterar_Click(object sender, EventArgs e)
        {
            GBIntrodução.Visible = false;
            veraluno.Visible = false;
            preencheraluno.Visible = false;
            processoaluno.Visible = false;
            processoalunolb.Visible = false;
            concluirinscricao.Visible = false;
            aplicarinfo.Visible = false;

        }

        private void Adicioanr_Click(object sender, EventArgs e)
        {
            GBIntrodução.Visible = false;
            alteraraluno.Visible = false;
            veraluno.Visible = false;
            lblprocesso.Visible = false;
            ndoprocesso.Visible = false;
            inserir.Visible = false;
            Concluir.Visible = false;
            concluirinscricao.Visible = true;
            aplicarinfo.Visible = true;
        }

        private void Concluir_Click(object sender, EventArgs e)
        {
            
            alunos.Add(a);
            nomealuno.Clear();
            idadealuno.Clear();
            processoaluno.Clear();
            anoaluno.SelectedIndex = -1;
            cursoaluno.SelectedIndex = -1;
            nomed.Clear();
            contactoed.Clear();
            GBIntrodução.Visible = true;
            alteraraluno.Visible = true;
            veraluno.Visible = true;
            preencheraluno.Visible = true;
            lblprocesso.Visible = true;
            ndoprocesso.Visible = true;
            inserir.Visible = true;
            processoaluno.Visible = true;
            processoalunolb.Visible = true;
            concluirinscricao.Visible = true;

            nomealuno.Enabled = true;
            idadealuno.Enabled = true;
            nomed.Enabled = true;
            contactoed.Enabled = true;
            anoaluno.Enabled = true;
            cursoaluno.Enabled = true;
            concluirinscricao.Visible = true;
            aplicarinfo.Visible = true;


        }
        private void inserir_Click(object sender, EventArgs e)
        {
                foreach (Aluno p in alunos)
                {
                    if (p.processo == ndoprocesso.Text)
                    {
                        nomealuno.Text = p.nome;
                        idadealuno.Text = Convert.ToString(p.idade);
                        anoaluno.SelectedIndex = p.ano;
                        cursoaluno.SelectedIndex = p.curso;
                        nomed.Text = p.nomeed;
                        contactoed.Text = Convert.ToString(p.contactoed);
                        ndoprocesso.Clear();
                    }
                }
        }

        private void concluirinscricao_Click(object sender, EventArgs e)
        {
            GBIntrodução.Visible = true;
            alteraraluno.Visible = true;
            veraluno.Visible = true;
            preencheraluno.Visible = true;
            lblprocesso.Visible = true;
            ndoprocesso.Visible = true;
            inserir.Visible = true;
            processoaluno.Visible = true;
            processoalunolb.Visible = true;
            Concluir.Visible = true;

            nomealuno.Enabled = true;
            idadealuno.Enabled = true;
            nomed.Enabled = true;
            contactoed.Enabled = true;
            anoaluno.Enabled = true;
            cursoaluno.Enabled = true;
            aplicarinfo.Visible = true;


            alunos.Add(a);
            nomealuno.Clear();
            idadealuno.Clear();
            processoaluno.Clear();
            anoaluno.SelectedIndex = -1;
            cursoaluno.SelectedIndex = -1;
            nomed.Clear();
            contactoed.Clear();
            erro1txt.Visible = false;
            erro2txt.Visible = false;
            erro3txt.Visible = false;
            erro4txt.Visible = false;
            erro1num.Visible = false;
            erro2num.Visible = false;
            erro3num.Visible = false;
            erro4num.Visible = false;
            erro5num.Visible = false;
            erro6num.Visible = false;
            erro7num.Visible = false;
            erro1.Visible = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            erro1.Visible = false;
            erro1txt.Visible = false;
            erro2txt.Visible = false;
            erro3txt.Visible = false;
            erro4txt.Visible = false;
            erro1num.Visible = false;
            erro2num.Visible = false;
            erro3num.Visible = false;
            erro4num.Visible = false;
            erro5num.Visible = false;
            erro6num.Visible = false;
            erro7num.Visible = false;
            erroprocesso.Visible = false;
        }

        private void aplicarinfo_Click(object sender, EventArgs e)
        {
            int b = 0;

            if (TemDigito(nomealuno.Text))
            {
                erro1txt.Visible = true;
                nomealuno.Clear();
                ++b;
            }
            else if (nomealuno.Text.Length < 1)
            {
                erro3txt.Visible = true;
                nomealuno.Clear();
                ++b;
            }
            else
            {
                a.nome = nomealuno.Text;
            }


            if (!Int32.TryParse(idadealuno.Text, out num))
            {
                erro1num.Visible = true;
                idadealuno.Clear();
                ++b;
            }
            else if (num > 120 || num < 14)
            {
                erro6num.Visible = true;
                idadealuno.Clear();
                ++b;
            }
            else
            {
                a.idade = num;
            }


            a.ano = anoaluno.SelectedIndex;
            a.curso = cursoaluno.SelectedIndex;

            if (TemDigito(nomealuno.Text))
            {
                erro5num.Visible = true;
                nomealuno.Clear();
                ++b;
            }
            else if (NaLista(alunos, ndoprocesso.Text))
            {
                erro2num.Visible = true;
                processoaluno.Clear();
                ++b;
            }
            else if (processoaluno.Text.Length > 3 || processoaluno.Text.Length < 3)
            {
                erro4num.Visible = true;
                processoaluno.Clear();
                ++b;
            }
            else
            {
                a.processo = processoaluno.Text;
            }

            if (TemDigito(nomed.Text))
            {
                erro2txt.Visible = true;
                nomed.Clear();
                ++b;
            }
            else if (nomed.Text.Length < 1)
            {
                erro4txt.Visible = true;
                nomed.Clear();
                ++b;
            }
            else
            {
                a.nomeed = nomed.Text;
            }

            if (!Int32.TryParse(contactoed.Text, out num))
            {
                erro3num.Visible = true;
                contactoed.Clear();
                ++b;
            }
            else if (contactoed.Text.Length > 9 || contactoed.Text.Length < 9)
            {
                erro7num.Visible = true;
                contactoed.Clear();
                ++b;
            }
            else
            {
                a.contactoed = num;
            }

            if (b > 0)
            { concluirinscricao.Enabled = false; }
        }

    }
}
