﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n, contn=0;
                for (int i=0;i > 5; i++)
            {
                Console.WriteLine("Introduza um valor valor");
                n =Convert.ToDouble(Console.ReadLine());
                if (n < 0)
                { 
                    contn = contn + 1; 
                }
                Console.WriteLine("São um total de " + contn + " números negativos.");
            }
            Console.ReadKey();
        }
    }
}
