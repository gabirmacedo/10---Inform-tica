﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            static string LerTexto()
            {
                Console.WriteLine();
            }
            static int ContaLetras(string p, char )
        static void Main(string[] args)
            {
                string Lertexto;
                Console.WriteLine("Qual o caracter que quer contar?");
                char letra = Convert.ToChar(Console.ReadLine());

                int quantos =


            for (int i = 0; i < S1.Length; i++)
                {
                    Console.WriteLine("");
                    S2[i] = Console.ReadLine();
                }
    }
}
