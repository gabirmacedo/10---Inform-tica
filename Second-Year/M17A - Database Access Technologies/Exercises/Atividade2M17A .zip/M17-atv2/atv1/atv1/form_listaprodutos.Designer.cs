﻿namespace atv1
{
    partial class lista_produtos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lista = new System.Windows.Forms.DataGridView();
            this.IdProduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeProduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tipoProduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preçoproduto = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantstock = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.lista)).BeginInit();
            this.SuspendLayout();
            // 
            // lista
            // 
            this.lista.AllowUserToAddRows = false;
            this.lista.AllowUserToDeleteRows = false;
            this.lista.AllowUserToResizeColumns = false;
            this.lista.AllowUserToResizeRows = false;
            this.lista.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lista.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lista.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lista.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdProduto,
            this.NomeProduto,
            this.tipoProduto,
            this.preçoproduto,
            this.Quantstock});
            this.lista.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lista.GridColor = System.Drawing.Color.Black;
            this.lista.Location = new System.Drawing.Point(0, 0);
            this.lista.Name = "lista";
            this.lista.RowHeadersVisible = false;
            this.lista.RowHeadersWidth = 62;
            this.lista.RowTemplate.Height = 28;
            this.lista.Size = new System.Drawing.Size(800, 450);
            this.lista.TabIndex = 0;
            // 
            // IdProduto
            // 
            this.IdProduto.HeaderText = "ID";
            this.IdProduto.MinimumWidth = 8;
            this.IdProduto.Name = "IdProduto";
            this.IdProduto.Width = 150;
            // 
            // NomeProduto
            // 
            this.NomeProduto.HeaderText = "Designação";
            this.NomeProduto.MinimumWidth = 8;
            this.NomeProduto.Name = "NomeProduto";
            this.NomeProduto.Width = 150;
            // 
            // tipoProduto
            // 
            this.tipoProduto.HeaderText = "Tipo de Produto";
            this.tipoProduto.MinimumWidth = 8;
            this.tipoProduto.Name = "tipoProduto";
            this.tipoProduto.Width = 150;
            // 
            // preçoproduto
            // 
            this.preçoproduto.HeaderText = "Preço";
            this.preçoproduto.MinimumWidth = 8;
            this.preçoproduto.Name = "preçoproduto";
            this.preçoproduto.Width = 150;
            // 
            // Quantstock
            // 
            this.Quantstock.HeaderText = "Stock";
            this.Quantstock.MinimumWidth = 8;
            this.Quantstock.Name = "Quantstock";
            this.Quantstock.Width = 150;
            // 
            // lista_produtos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lista);
            this.Name = "lista_produtos";
            this.Text = "Listagem Produtos";
            this.Load += new System.EventHandler(this.lista_produtos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lista)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn IdProduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeProduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn tipoProduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn preçoproduto;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantstock;
        public System.Windows.Forms.DataGridView lista;
    }
}