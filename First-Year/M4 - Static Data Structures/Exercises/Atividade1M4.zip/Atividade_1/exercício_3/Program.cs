﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[100];
            Random aleatorio = new Random();

            for (int i = 0; i < num.Length; i++)
            {
                num[i] = aleatorio.Next(0, 1000);
                Console.WriteLine("ordem original" + num[i]);
            }

            Array.Sort(num);
            foreach (int i in num) 
            { Console.WriteLine("ordem crescente " + i); }

            Array.Reverse(num);
            foreach (int i in num)
            { Console.WriteLine("ordem decrescente " + i); }

            Console.ReadKey();
        }
    }
}
