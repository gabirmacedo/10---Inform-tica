﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3
{
    public partial class Form1 : Form
    {
        double precoCriancas, precoDietas, precoAdultos;
        private double valorEmenta(string ementa, string tipoDePessoa, int quantidade)
        {
            double valor = 0;
            switch(ementa)
            {
                case "Deluxe":
                    if(tipoDePessoa.ToLower()=="adulto")
                    {
                        valor = 90*quantidade;
                    }
                    else
                    {
                        valor = 40 * quantidade;
                    }
                    break;
                case "Portuguesa":
                    if (tipoDePessoa.ToLower() == "adulto")
                    {
                        valor = 100 * quantidade;
                    }
                    else
                    {
                        valor = 70 * quantidade;
                    }
                    break;
                case "Prestígio":
                    if (tipoDePessoa.ToLower() == "adulto")
                    {
                        valor = 75 * quantidade;
                    }
                    else
                    {
                        valor = 33 * quantidade;
                    }
                    break;
                case "Rodízio":
                    if (tipoDePessoa.ToLower() == "adulto")
                    {
                        valor = 120 * quantidade;
                    }
                    else
                    {
                        valor = 45 * quantidade;
                    }
                    break;
                case "Soberba":
                    if (tipoDePessoa.ToLower() == "adulto")
                    {
                        valor = 95 * quantidade;
                    }
                    else
                    {
                        valor = 40 * quantidade;
                    }
                    break;
            }
            return valor;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void nud_Criancas_ValueChanged(object sender, EventArgs e)
        {
            lbl_NumCriancas.Text = (valorEmenta(cbo_Ementa.Text, "Crianca", (int)nud_Criancas.Value) + "€");
            precoCriancas = (valorEmenta(cbo_Ementa.Text, "Crianca", (int)nud_Criancas.Value));
        }

        private void lbl_NumDieta_Click(object sender, EventArgs e)
        {

        }

        private void nud_Dieta_ValueChanged(object sender, EventArgs e)
        {
            lbl_NumDieta.Text = (56*(int)nud_Dieta.Value)+"€";
            precoDietas = (56 * (int)nud_Dieta.Value);
        }

        private void lbl_NumAdultos_Click(object sender, EventArgs e)
        {

        }

        private void bt_LimparValores_Click(object sender, EventArgs e)
        {
            nud_Adultos.Value = 0;
            nud_Criancas.Value = 0;
            nud_Dieta.Value = 0;
            lbl_NumAdultos.Text="0€";
            lbl_NumCriancas.Text="0€";
            lbl_NumDieta.Text = "0€";
            lbl_PrecoTotal.Text =null;
            lbl_SinDeReserva.Text =null;
            lbl_PagFinal.Text =null;
        }

        private void nud_Adultos_ValueChanged(object sender, EventArgs e)
        {
            lbl_NumAdultos.Text = (valorEmenta(cbo_Ementa.Text, "Adulto", (int)nud_Adultos.Value) + "€");
            precoAdultos = (valorEmenta(cbo_Ementa.Text, "Adulto", (int)nud_Adultos.Value));
        }

        private void bt_Calcular_Click(object sender, EventArgs e)
        {
            lbl_PrecoTotal.Text = (precoCriancas + precoDietas + precoAdultos).ToString();
            lbl_SinDeReserva.Text = ((precoCriancas + precoDietas + precoAdultos)*0.3).ToString();
            lbl_PagFinal.Text = ((precoCriancas + precoDietas + precoAdultos) - ((precoCriancas + precoDietas + precoAdultos) * 0.3)).ToString();
        }
    }
}
