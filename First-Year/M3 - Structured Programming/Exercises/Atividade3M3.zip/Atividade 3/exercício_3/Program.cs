﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Security;
using System.Text;
using System.Threading.Tasks;

namespace exercício_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n, fatorial;
            
            Console.WriteLine("Introduza um valor");
            n = Convert.ToInt32(Console.ReadLine());
            fatorial = Convert.ToInt32(n);
            do
            {
                n = n - 1;
                fatorial = fatorial * n;
            }
            while (n > 1);
            Console.WriteLine("O fatorial desse valor é: "+ fatorial);
            Console.ReadKey();
        }
    }
}
