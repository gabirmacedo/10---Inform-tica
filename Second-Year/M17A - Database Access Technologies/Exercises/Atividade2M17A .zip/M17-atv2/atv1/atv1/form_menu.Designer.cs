﻿namespace atv1
{
    partial class Form_menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_cliente = new System.Windows.Forms.Button();
            this.bt_produto = new System.Windows.Forms.Button();
            this.bt_encomenda = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_cliente
            // 
            this.bt_cliente.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_cliente.Location = new System.Drawing.Point(230, 115);
            this.bt_cliente.Name = "bt_cliente";
            this.bt_cliente.Size = new System.Drawing.Size(329, 52);
            this.bt_cliente.TabIndex = 0;
            this.bt_cliente.Text = "Inserir Cliente";
            this.bt_cliente.UseVisualStyleBackColor = true;
            this.bt_cliente.Click += new System.EventHandler(this.bt_cliente_Click);
            // 
            // bt_produto
            // 
            this.bt_produto.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_produto.Location = new System.Drawing.Point(230, 196);
            this.bt_produto.Name = "bt_produto";
            this.bt_produto.Size = new System.Drawing.Size(329, 52);
            this.bt_produto.TabIndex = 1;
            this.bt_produto.Text = "Inserir Produto";
            this.bt_produto.UseVisualStyleBackColor = true;
            this.bt_produto.Click += new System.EventHandler(this.bt_produto_Click);
            // 
            // bt_encomenda
            // 
            this.bt_encomenda.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_encomenda.Location = new System.Drawing.Point(230, 275);
            this.bt_encomenda.Name = "bt_encomenda";
            this.bt_encomenda.Size = new System.Drawing.Size(329, 52);
            this.bt_encomenda.TabIndex = 2;
            this.bt_encomenda.Text = "Inserir encomenda";
            this.bt_encomenda.UseVisualStyleBackColor = true;
            this.bt_encomenda.Click += new System.EventHandler(this.bt_encomenda_Click);
            // 
            // Form_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_produto);
            this.Controls.Add(this.bt_cliente);
            this.Controls.Add(this.bt_encomenda);
            this.Name = "Form_menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_cliente;
        private System.Windows.Forms.Button bt_produto;
        private System.Windows.Forms.Button bt_encomenda;
    }
}

