﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Exercicio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] vendas = new double[4, 3];
            
            for (int i = 0; i < vendas.GetLength(0); i++)
            {
                for (int j = 0; j < vendas.GetLength(1); j++)
                {
                    Console.WriteLine($"Indique as vendas da loja {i + 1} para o mês {j + 1}");
                    vendas[i, j] = Convert.ToDouble(Console.ReadLine());
                }
            }

            Console.WriteLine("Vendas da loja 3 em Janeiro");
            Console.WriteLine(vendas[2, 0]);
            
            Console.WriteLine("Vendas das 4 lojas nos 3 meses:");
            for (int i = 0; i < vendas.GetLength(0); i++)
            {
                for (int j = 0; j < vendas.GetLength(1); j++)
                {
                    Console.WriteLine($"Vendas da loja {i + 1} no mês {j + 1}: {vendas[i, j]}");
                }
            }
            
            Console.WriteLine("Vendas de Março nas 4 lojas:");
            for (int i = 0; i < vendas.GetLength(0); i++)
            {
                Console.WriteLine($"Vendas do mes 3 na loja {i + 1}: {vendas[i, 2]}");
            }
            
            char respos;
            do
            {
                Console.WriteLine("De que loja quer consultar as vendas? (1, 2, 3 ou 4)");
                int loja = Convert.ToInt32(Console.ReadLine());

                if (loja < 1 || loja > 4) 
                {
                    Console.WriteLine("Deve ser introduzido um um valor de 1 a 4.");
                }

                else 
                {
                    for (int i = 0; i < vendas.GetLength(1); i++)
                    {
                        Console.WriteLine("Vendas da loja " + loja + " no mês " + (i + 1) + ": " + vendas[loja - 1,
                       i]);
                    }
                
                Console.WriteLine("De que mês quer consultar as loja? (1, 2 ou 3 )");
                int mes = Convert.ToInt32(Console.ReadLine());
                    if (mes < 1 || mes > 3)
                    {
                        Console.WriteLine("Deve ser introduzido um um valor de 1 a 3.");
                    }

                    else
                    {
                        for (int j = 0; j < vendas.GetLength(0); j++)
                        {
                            Console.WriteLine("Vendas da loja " + (j + 1) + " no mês " + mes + ": " + vendas[j,
                           mes - 1]);
                        }
                    }
                }
                Console.WriteLine("Continuar/Resetar? S/N");
                respos = Convert.ToChar(Console.ReadLine().ToUpper());
                
                if (respos != 'S' && respos != 'N')
                {
                    Console.WriteLine("Deve ser introduzido apenas S ou N.");
                }
            } while (respos == 'S');

            Console.WriteLine("De que mês quer consultar a soma das loja? (1, 2 ou 3 )");
            int lojasoma = Convert.ToInt32(Console.ReadLine());
            if (lojasoma < 1 && lojasoma > 4)
            {
                Console.WriteLine("Deve ser introduzido um valor de 1 a 4.");
            }
            else
            {
                double soma = 0;
                for (int i = 0; i < vendas.GetLength(1); i++)
                {
                    soma = soma + vendas[lojasoma, i];
                }
                Console.WriteLine("A soma das vendas da loja" + lojasoma + " é igual a " + soma);
            }
            Console.ReadKey();

        }
    }
}
