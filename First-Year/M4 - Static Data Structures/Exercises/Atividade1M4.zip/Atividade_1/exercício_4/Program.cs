﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace exercício_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] ValorGasto = new int[12];
            char resposta;
            double soma = 0;

            for (int i = 1; i <= ValorGasto.Length; i++)
            {
                
                Console.WriteLine("Insira o valor gasto no " + i + " Mês");
                ValorGasto[i - 1] = Convert.ToInt32(Console.ReadLine());
                soma = soma + ValorGasto[i-1];
            }
            do
            {
                int respostaval;
                Console.WriteLine("Deseja consultar qual mês desse ano?");
                respostaval = Convert.ToInt32(Console.ReadLine());
                if (respostaval < 0 && respostaval > 12)
                { 
                    Console.WriteLine("Deve ser introduzido um número de 1 a 12."); 
                }
                Console.WriteLine(ValorGasto[respostaval - 1]);

                Console.WriteLine("Continuar? S/N");
                resposta = Convert.ToChar(Console.ReadLine());
                if (resposta != 'n' || resposta != 'N')
                { Console.WriteLine("Deve ser introduzido apenas S ou N"); }
            } while (resposta == 'S' && resposta == 's');

            Console.WriteLine("A média é " + soma / 12);
            Console.ReadKey();

        }
    }
}
