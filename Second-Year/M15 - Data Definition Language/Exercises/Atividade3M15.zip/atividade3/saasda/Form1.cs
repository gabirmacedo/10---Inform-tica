﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace saasda
{
    public partial class cbomes : Form
    {
        double[] mes;
        public cbomes()
        {
            InitializeComponent();
        }

        private void cbomes_Load(object sender, EventArgs e)
        {
            mes = new double[12];
            for (int i = 0; i < 12; i++)
            { 
                mes[i] = 0;
            }
        }

        private void btinserir_Click(object sender, EventArgs e)
        {
            double valor = 0;
            if (double.TryParse(txtvalor.Text, out valor) == true && cbmes.SelectedIndex != -1)
            {
                mes[cbmes.SelectedIndex] = valor;
            }
            else
            {
                MessageBox.Show("Selecione o mês e introduza um valor");
            }
            txtvalor.Clear();
        }

        private void btconsultar_Click(object sender, EventArgs e)
        {
            if (cbmes.SelectedIndex != -1)
            { MessageBox.Show("O Valor desse mês é " + mes[cbmes.SelectedIndex]);}
            

        }

        private void txtvalor_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
