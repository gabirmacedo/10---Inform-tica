﻿namespace atv1
{
    partial class form_encomendas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.tbidenc = new System.Windows.Forms.TextBox();
            this.tbidprod = new System.Windows.Forms.TextBox();
            this.dtpenc = new System.Windows.Forms.DateTimePicker();
            this.nudquant = new System.Windows.Forms.NumericUpDown();
            this.nudpreco = new System.Windows.Forms.NumericUpDown();
            this.tbidcli = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.bt_inserirenc = new System.Windows.Forms.Button();
            this.bt_limparenc = new System.Windows.Forms.Button();
            this.bt_Listagemenc = new System.Windows.Forms.Button();
            this.bt_editar = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudquant)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudpreco)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label1.Location = new System.Drawing.Point(224, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 23);
            this.label1.TabIndex = 0;
            this.label1.Text = "ID";
            // 
            // tbidenc
            // 
            this.tbidenc.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbidenc.Location = new System.Drawing.Point(267, 34);
            this.tbidenc.Name = "tbidenc";
            this.tbidenc.Size = new System.Drawing.Size(324, 39);
            this.tbidenc.TabIndex = 1;
            // 
            // tbidprod
            // 
            this.tbidprod.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbidprod.Location = new System.Drawing.Point(267, 133);
            this.tbidprod.Name = "tbidprod";
            this.tbidprod.Size = new System.Drawing.Size(324, 39);
            this.tbidprod.TabIndex = 2;
            // 
            // dtpenc
            // 
            this.dtpenc.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.dtpenc.Location = new System.Drawing.Point(267, 85);
            this.dtpenc.Name = "dtpenc";
            this.dtpenc.Size = new System.Drawing.Size(324, 39);
            this.dtpenc.TabIndex = 3;
            // 
            // nudquant
            // 
            this.nudquant.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.nudquant.Location = new System.Drawing.Point(267, 180);
            this.nudquant.Name = "nudquant";
            this.nudquant.Size = new System.Drawing.Size(324, 39);
            this.nudquant.TabIndex = 4;
            // 
            // nudpreco
            // 
            this.nudpreco.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.nudpreco.Location = new System.Drawing.Point(267, 227);
            this.nudpreco.Name = "nudpreco";
            this.nudpreco.Size = new System.Drawing.Size(324, 39);
            this.nudpreco.TabIndex = 5;
            // 
            // tbidcli
            // 
            this.tbidcli.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.tbidcli.Location = new System.Drawing.Point(267, 275);
            this.tbidcli.Name = "tbidcli";
            this.tbidcli.Size = new System.Drawing.Size(324, 39);
            this.tbidcli.TabIndex = 6;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label2.Location = new System.Drawing.Point(202, 101);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 23);
            this.label2.TabIndex = 7;
            this.label2.Text = "Data";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label3.Location = new System.Drawing.Point(147, 149);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(105, 23);
            this.label3.TabIndex = 8;
            this.label3.Text = "Id_Produto";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label4.Location = new System.Drawing.Point(143, 196);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(109, 23);
            this.label4.TabIndex = 9;
            this.label4.Text = "Quantidade";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label5.Location = new System.Drawing.Point(193, 243);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 23);
            this.label5.TabIndex = 10;
            this.label5.Text = "Preço";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Adobe Gothic Std B", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.label6.Location = new System.Drawing.Point(149, 291);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(103, 23);
            this.label6.TabIndex = 11;
            this.label6.Text = "Id_Clientes";
            // 
            // bt_inserirenc
            // 
            this.bt_inserirenc.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bt_inserirenc.Location = new System.Drawing.Point(209, 331);
            this.bt_inserirenc.Name = "bt_inserirenc";
            this.bt_inserirenc.Size = new System.Drawing.Size(186, 49);
            this.bt_inserirenc.TabIndex = 12;
            this.bt_inserirenc.Text = "Inserir";
            this.bt_inserirenc.UseVisualStyleBackColor = true;
            this.bt_inserirenc.Click += new System.EventHandler(this.bt_inserirenc_Click);
            // 
            // bt_limparenc
            // 
            this.bt_limparenc.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bt_limparenc.Location = new System.Drawing.Point(405, 331);
            this.bt_limparenc.Name = "bt_limparenc";
            this.bt_limparenc.Size = new System.Drawing.Size(186, 49);
            this.bt_limparenc.TabIndex = 13;
            this.bt_limparenc.Text = "Limpar";
            this.bt_limparenc.UseVisualStyleBackColor = true;
            this.bt_limparenc.Click += new System.EventHandler(this.bt_limparenc_Click);
            // 
            // bt_Listagemenc
            // 
            this.bt_Listagemenc.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bt_Listagemenc.Location = new System.Drawing.Point(209, 386);
            this.bt_Listagemenc.Name = "bt_Listagemenc";
            this.bt_Listagemenc.Size = new System.Drawing.Size(186, 49);
            this.bt_Listagemenc.TabIndex = 14;
            this.bt_Listagemenc.Text = "Listagem";
            this.bt_Listagemenc.UseVisualStyleBackColor = true;
            this.bt_Listagemenc.Click += new System.EventHandler(this.bt_Listagemenc_Click);
            // 
            // bt_editar
            // 
            this.bt_editar.Font = new System.Drawing.Font("Adobe Gothic Std B", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(128)));
            this.bt_editar.Location = new System.Drawing.Point(405, 386);
            this.bt_editar.Name = "bt_editar";
            this.bt_editar.Size = new System.Drawing.Size(186, 49);
            this.bt_editar.TabIndex = 15;
            this.bt_editar.Text = "Editar";
            this.bt_editar.UseVisualStyleBackColor = true;
            this.bt_editar.Click += new System.EventHandler(this.bt_editar_Click);
            // 
            // form_encomendas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 458);
            this.Controls.Add(this.bt_editar);
            this.Controls.Add(this.bt_Listagemenc);
            this.Controls.Add(this.bt_limparenc);
            this.Controls.Add(this.bt_inserirenc);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tbidcli);
            this.Controls.Add(this.nudpreco);
            this.Controls.Add(this.nudquant);
            this.Controls.Add(this.dtpenc);
            this.Controls.Add(this.tbidprod);
            this.Controls.Add(this.tbidenc);
            this.Controls.Add(this.label1);
            this.Name = "form_encomendas";
            this.Text = "Encomendas";
            this.Load += new System.EventHandler(this.form_encomendas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nudquant)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nudpreco)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbidenc;
        private System.Windows.Forms.TextBox tbidprod;
        private System.Windows.Forms.DateTimePicker dtpenc;
        private System.Windows.Forms.NumericUpDown nudquant;
        private System.Windows.Forms.NumericUpDown nudpreco;
        private System.Windows.Forms.TextBox tbidcli;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button bt_inserirenc;
        private System.Windows.Forms.Button bt_limparenc;
        private System.Windows.Forms.Button bt_Listagemenc;
        private System.Windows.Forms.Button bt_editar;
    }
}