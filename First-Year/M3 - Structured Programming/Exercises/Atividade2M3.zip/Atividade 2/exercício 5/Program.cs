﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n1, n2, resp;
            Console.WriteLine("Para executarmos um cálculo simples, introduza um valor");
            n1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Introduza outro valor");
            n2 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Escolha uma das operações a seguir. " +
                "Soma - 1 /" +
                "Subtração - 2 /" +
                "Multiplicação - 3 /" +
                "Divisão - 4");
            resp = Convert.ToDouble(Console.ReadLine());
            switch (resp)
            {
                case 1:
                    Console.WriteLine("A soma dos dois valores é " + n1 * n2);
                    break;
                case 2:
                    Console.WriteLine("A subtração dos dois valores é " + (n1 - n2));
                    break;
                case 3:
                    Console.WriteLine("A multiplicação dos dois valores é " + n1 * n2);
                    break;
                case 4:
                    if (n2 != 0)
                        Console.WriteLine("A divisão é " + (n1 / n2));
                    else
                        Console.WriteLine("Não é possível dividir por 0.");
                    break;
                default:
                    Console.WriteLine("Deve ser introduzidos apenas uma das opções acima");
                    break;
            }
            Console.ReadLine();

        }
    }
}
