-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema script2
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema script2
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `script2` DEFAULT CHARACTER SET utf8 ;
USE `script2` ;

-- -----------------------------------------------------
-- Table `script2`.`autor`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `script2`.`autor` (
  `idautor` INT NOT NULL AUTO_INCREMENT,
  `nomeautor` VARCHAR(75) NOT NULL,
  PRIMARY KEY (`idautor`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `script2`.`suporte`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `script2`.`suporte` (
  `idsuporte` INT NOT NULL AUTO_INCREMENT,
  `nomesuporte` VARCHAR(75) NOT NULL,
  `tiposuporte` VARCHAR(10) NOT NULL,
  PRIMARY KEY (`idsuporte`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `script2`.`estilo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `script2`.`estilo` (
  `idestilo` INT NOT NULL AUTO_INCREMENT,
  `nomeestilo` VARCHAR(50) NOT NULL,
  PRIMARY KEY (`idestilo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `script2`.`obra`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `script2`.`obra` (
  `numobra` INT NOT NULL AUTO_INCREMENT,
  `titulo` VARCHAR(75) NOT NULL,
  `ano` VARCHAR(4) NOT NULL,
  `idautor` INT NOT NULL,
  `idsuporte` INT NOT NULL,
  `idestilo` INT NOT NULL,
  `comentario` VARCHAR(100) NOT NULL,
  PRIMARY KEY (`numobra`),
  INDEX `idautor_idx` (`idautor` ASC) VISIBLE,
  INDEX `idsuporte_idx` (`idsuporte` ASC) VISIBLE,
  INDEX `idestilo_idx` (`idestilo` ASC) VISIBLE,
  CONSTRAINT `idautor`
    FOREIGN KEY (`idautor`)
    REFERENCES `script2`.`autor` (`idautor`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `idsuporte`
    FOREIGN KEY (`idsuporte`)
    REFERENCES `script2`.`suporte` (`idsuporte`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `idestilo`
    FOREIGN KEY (`idestilo`)
    REFERENCES `script2`.`estilo` (`idestilo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
