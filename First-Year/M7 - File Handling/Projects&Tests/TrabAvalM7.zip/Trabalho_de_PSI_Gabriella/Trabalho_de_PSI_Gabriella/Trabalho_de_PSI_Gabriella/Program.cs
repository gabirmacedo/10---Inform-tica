﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Diagnostics.Contracts;
using System.Globalization;
using static System.Net.Mime.MediaTypeNames;
using System.Diagnostics.Eventing.Reader;

namespace Trabalho_de_PSI_Gabriella
{
    internal class Program
    {
        static bool TemDigito(string palavra)
        {
            foreach (char a in palavra)
            {
                if (char.IsDigit(a))
                {
                    return true;
                }
            }
                return false;
        }
        struct Contacto
        {   
            public string nome;
            public int numero;
            public string afiliacao;
            public string perfilSocial;
        }

        static bool NomeNaLista(List<Contacto> c, string p)
        {
            bool d = false;
            foreach (Contacto a in c)
            {
                if(a.nome == p)
                    return true;
            }
            return false;
        }

        static bool NumeroNaLista(List<Contacto> c, int n)
        {
            foreach (Contacto a in c)
            {
                if (a.numero == n)
                    return true;
            }
            return false;
        }

        static void Adicionar(ref List<Contacto> c, Contacto a)
        {
            int num;
            string palavra;
            do
            {
                Console.WriteLine("Introduza o nome do contacto:");
                palavra = Console.ReadLine().ToLower();

                if (NomeNaLista(c, palavra))
                {   Console.WriteLine("ERRO: O nome introduzido ja está na lista."); }
                else if (TemDigito(palavra))
                {   Console.WriteLine("ERRO: O nome deve ser introduzido sem dígitos."); }
                else 
                {
                    a.nome = palavra;
                }
                

            } while (NomeNaLista(c,palavra) || TemDigito(palavra));

            do
            {
                Console.WriteLine("Introduza o número do contacto:");
                palavra = Console.ReadLine();

                if (!Int32.TryParse(palavra, out num))
                {
                    Console.WriteLine("ERRO: O número deve ser introduzido sem texto.");
                }
                else if (NumeroNaLista(c, num))
                {   Console.WriteLine("ERRO: O número introduzido ja está na lista."); }
                else if (palavra.Length > 9 || palavra.Length < 9)
                {   Console.WriteLine("ERRO: O número introduzido deve ter 9 dígitos."); }
                else
                {
                    a.numero = num;
                }

            } while (NumeroNaLista(c, num) || !Int32.TryParse(palavra, out num) || (palavra.Length > 9 || palavra.Length < 9));

            do
            {
                Console.WriteLine("Deseja introduzir um nome social? 1- sim | 2- não");
                palavra = Console.ReadLine();

                if (!Int32.TryParse(palavra, out num))
                {
                    Console.WriteLine("ERRO: O número deve ser introduzido sem texto.");
                }
                else if (num < 1 || num > 2)
                {   Console.WriteLine("ERRO: Deve ser introduzido apenas 1 ou 2"); }
                
            } while (!Int32.TryParse(palavra, out num) || num < 1 || num > 2);

            if (num == 1 )
            {
                do
                {
                    Console.WriteLine("Introduza o nome social do contacto:");
                    palavra = Console.ReadLine().ToLower();

                    if (TemDigito(palavra))
                    { Console.WriteLine("ERRO: O nome deve ser introduzido sem dígitos."); }
                    else 
                    {
                        a.perfilSocial = palavra;
                    }
                } while (TemDigito(palavra));
            }
            
            do
            {
                Console.WriteLine("Introduza a afiliação do contacto:");
                palavra = Console.ReadLine().ToLower();

                if (TemDigito(palavra))
                { Console.WriteLine("ERRO: A afiliação deve ser introduzido sem dígitos."); }
                else 
                {
                    a.afiliacao = palavra;
                }
            } while (TemDigito(palavra));
            c.Add(a);
        }

        static void Remover(ref List<Contacto> c, Contacto a)
        {
            int num;
            string palavra;

            if (c.Count == 0)
            {
                Console.WriteLine("ERRO: A lista esta vazia");
            }
            else
            {
                do
                {
                    Console.WriteLine("Introduza o nome do contacto:");
                    palavra = Console.ReadLine();
                    if (TemDigito(palavra))
                    { Console.WriteLine("ERRO: O nome deve ser introduzido sem dígitos."); }
                } while (TemDigito(palavra));

                for (int i = 0; i < c.Count; i++)
                {
                    if (palavra == c[i].nome)
                    {
                        c.RemoveAt(i);
                        Console.WriteLine("O contacto foi removido.");
                        break;
                    }
                    else
                    Console.WriteLine("O contacto introduzido não existe dentro da lista");
                }
                
            }
        }

        static void Alterar(ref List<Contacto> c, Contacto a)
        {
            int num;
            string palavra;

            if (c.Count == 0)
            {
                Console.WriteLine("ERRO: A lista esta vazia");
            }
            else
            {
                do
                {
                    Console.WriteLine("Introduza o nome do contacto que quer alterar:");
                    palavra = Console.ReadLine();
                    if (TemDigito(palavra))
                    { Console.WriteLine("ERRO: O nome deve ser introduzido sem dígitos."); }
                } while (TemDigito(palavra));

                for (int i = 0; i < c.Count; i++)
                {
                    if (palavra == c[i].nome)
                    {
                        Console.WriteLine("O contacto foi encontrado, insira as novas informações a seguir:");
                        c.RemoveAt(i);
                        Adicionar(ref c, a);
                        Console.WriteLine("O contacto foi alterado.");
                        break;
                    }
                    else
                    { Console.WriteLine("O contacto introduzido não existe dentro da lista"); }
                }
            }
        }

        static void Listar(ref List<Contacto> c, Contacto a)
        {

            if (c.Count != 0)
            {
                Console.WriteLine("Existem " + c.Count + " contactos na lista:");
                Console.WriteLine();

                for (int i =0; i < c.Count ; i++)
                {
                    Console.WriteLine(c[i].nome);
                    Console.WriteLine(c[i].numero);
                    Console.WriteLine(c[i].afiliacao);
                    Console.WriteLine(c[i].perfilSocial);
                    Console.WriteLine();
                }
            }
            else
            { Console.WriteLine("Lista Vazia"); }
        }

        static void Main(string[] args)
        {
            List<Contacto> contactos = new List<Contacto>();
            Contacto a = new Contacto();
            int num;
            string palavra;

            const string caminho = "C:/Users/Aluno/Downloads/Trabalho_de_PSI_Gabriella/Trabalho_de_PSI_Gabriella/Teste;";
            FileStream fich = new FileStream(caminho, FileMode.Create, FileAccess.Write);
            BinaryWriter bw = new BinaryWriter(fich);

            do
            {
                do
                {
                    Console.WriteLine("Oque deseja fazer?");
                    Console.WriteLine("Adicionar contacto - 1 ");
                    Console.WriteLine("Remover contacto - 2 ");
                    Console.WriteLine("Listar contactos - 3 ");
                    Console.WriteLine("Alterar contacto - 4 ");
                    Console.WriteLine("Terminar sessão - 5 ");

                    palavra = Console.ReadLine();

                    if (!Int32.TryParse(palavra, out num))
                    {
                        Console.WriteLine("Introduza um valor numérico!");
                    }
                    else if (num < 1 || num > 5)
                    { Console.WriteLine("ERRO: O número introduzido deve ser 1,2,3,4 ou 5."); }

                } while (!Int32.TryParse(palavra, out num) || (num < 1 || num > 5));

                if (num == 1)
                {
                    Console.WriteLine();
                    Adicionar(ref contactos, a);
                }
                else if (num == 2)
                {
                    Console.WriteLine();
                    Remover(ref contactos, a);
                }
                else if (num == 3)
                {
                    Console.WriteLine();
                    Listar(ref contactos, a);
                }
                else if (num == 4)   
                {
                    Console.WriteLine();
                    Alterar(ref contactos, a);
                }
                else if (num == 5)
                {
                    Console.WriteLine();
                    Console.WriteLine("Insira qualquer tecla para sair");
                    break;
                }
                do
                {
                    Console.WriteLine();
                    Console.WriteLine("Deseja continuar? 1-sim | 2-não");
                    palavra = Console.ReadLine();

                    if (!Int32.TryParse(palavra, out num))
                    {
                        Console.WriteLine("ERRO: O número deve ser introduzido sem texto.");
                    }
                    else if (num < 1 || num > 2)
                    { Console.WriteLine("ERRO: Deve ser introduzido apenas 1 ou 2"); }
                } while (!Int32.TryParse(palavra, out num) || num < 1 || num > 2);
                

            } while (num == 1);

            for (int i = 0; i < contactos.Count; i++)
            {
                bw.Write(contactos[i].nome);
                bw.Write(contactos[i].numero);
                bw.Write(contactos[i].afiliacao);
                bw.Write(contactos[i].perfilSocial);
            }
            Console.ReadKey();

        }
    }
}
