﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercício_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x, y, soma, prod, dif, quo;
            Console.WriteLine("Introduza um valor");
            x = Convert.ToDouble (Console.ReadLine());
            Console.WriteLine("Introduza outro valor");
            y = Convert.ToDouble(Console.ReadLine());
            soma = Convert.ToDouble(x + y);
            dif = Convert.ToDouble(Math.Max(x, y) - Math.Min(x, y));
            quo = Convert.ToDouble(x / y);
            prod = Convert.ToDouble(x * y);
            Console.WriteLine("A sua soma é " + soma + ", a diferença é " + dif + " o quociente é " + quo + " e o produto é " + prod);
            Console.ReadKey();
        }
    }
}
