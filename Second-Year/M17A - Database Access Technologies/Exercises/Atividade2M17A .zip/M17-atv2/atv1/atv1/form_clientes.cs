﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using MySqlX.XDevAPI;

namespace atv1
{
    public partial class Form_Clientes : Form
    {
        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=loja";
        struct Cliente
        {
            public int idcliente;
            public string nome;
            public string email;
            public int nif;
        }
        List<Cliente> clientes = new List<Cliente>();
        Cliente cliente = new Cliente();
        private void LimparCampos()
        {
            tb_id.Text = "";
            tb_nome.Text = "";
            tb_email.Text = "";
            tb_nif.Text = "";
        }
        private void Preencher()
        {
            string sql = "select * from clientes";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        cliente.idcliente = reader.GetInt32("idClientes");
                        cliente.nome = reader.GetString("nome");
                        cliente.email = reader.GetString("email");
                        cliente.nif = reader.GetInt32("nif");

                        clientes.Add(cliente);
                    }
                }
            }
        }
        private void Form_Clientes_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();

                MessageBox.Show("Conexão efetuada com sucesso");
                Preencher();
                tb_id.Text = (clientes.Count()+1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Form_produto.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void bt_limpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }
        public Form_Clientes()
        {
            InitializeComponent();
        }
        private void bt_inserircli_Click(object sender, EventArgs e)
        {
            if (tb_id.Text != "" && tb_nome.Text != "" && tb_email.Text != "" && tb_nif.Text != "")
            {
                MessageBox.Show("O Formulário foi preenchido");

                cliente.idcliente = Convert.ToInt32(tb_id.Text);
                cliente.nome = tb_nome.Text;
                cliente.email = tb_email.Text;
                cliente.nif = Convert.ToInt32(tb_nif.Text);
                clientes.Add(cliente);

                string sql = "insert into loja.clientes values(@idClientes,@nome,@email,@nif)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@idClientes", null);
                    cmd.Parameters.AddWithValue("@nome", cliente.nome);
                    cmd.Parameters.AddWithValue("@email", cliente.email);
                    cmd.Parameters.AddWithValue("@nif", cliente.nif);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Registo inserido!", "Informação");
                }

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
        }

        private void bt_Listagem_Click(object sender, EventArgs e)
        {
            this.Close();
            Listagem_Clientes listagem = new Listagem_Clientes();

            foreach (Cliente a in clientes)
            {
                listagem.lista_clientes.Rows.Add(
                a.idcliente, a.nome, a.email, a.nif);
            }

            listagem.Show();
        }

        private void bt_alterar_Click(object sender, EventArgs e)
        {
            if (tb_id.Text != "" && tb_nome.Text != "" && tb_email.Text != "" && tb_nif.Text != "")
            {
                int id = Convert.ToInt32(tb_id.Text);

                string sql = "UPDATE clientes SET nome=@nome, email=@email, nif=@nif WHERE idClientes=@id";

                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@nome", tb_nome.Text);
                    cmd.Parameters.AddWithValue("@email", tb_email.Text);
                    cmd.Parameters.AddWithValue("@nif", Convert.ToInt32(tb_nif.Text));

                    cmd.ExecuteNonQuery();
                }

                // Atualizar lista local
                for (int i = 0; i < clientes.Count; i++)
                {
                    if (clientes[i].idcliente == id)
                    {
                        cliente.idcliente = id;
                        cliente.nome = tb_nome.Text;
                        cliente.email = tb_email.Text;
                        cliente.nif = Convert.ToInt32(tb_nif.Text);

                        clientes[i] = cliente;
                        break;
                    }
                }

                MessageBox.Show("Cliente alterado com sucesso!", "Informação");

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
        }
    }
}
