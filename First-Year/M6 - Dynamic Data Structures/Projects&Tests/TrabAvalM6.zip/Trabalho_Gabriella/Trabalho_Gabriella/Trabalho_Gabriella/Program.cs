﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Net;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using FakeItEasy;
using static System.Net.Mime.MediaTypeNames;

namespace Trabalho_Gabriella
{
    class Program
    {

        struct Contacto
        {
            public string nome;
            public string perfilsocial;
            public string pronomes;
            public string numero;
            public string afiliacao;
        }
        static bool Verificacao(string palavra)
        {
            bool d = false;
            foreach (char c in palavra)
            {
                if (char.IsDigit(c))
                {
                    d = true;
                }
            }
            return d;
        }
        static void Main(string[] args)
        {
            List<Contacto> contactos = new List<Contacto>();
            Contacto a = new Contacto();

            string txt;
            int num, num2;
            do
            {
                //Introduzir,Remover ou Listar os contactos
                do
                {
                    Console.WriteLine("Oque deseja fazer?");
                    Console.WriteLine("Adicionar um contacto - 1 | Remover um contacto - 2 | Listar os contactos - 3");
                    txt = Console.ReadLine();
                    //verifica se a resposta é um valor numérico
                    if (!Int32.TryParse(txt, out num2))
                    {
                        Console.WriteLine("Introduza um valor numérico!");
                    }
                } while (!Int32.TryParse(txt, out num2));

                if (num2 == 1)
                {
                    //verifica se foi introduzido apenas caracteres de texto
                    do
                    {
                        do
                        {
                            do { 
                            Console.WriteLine("Introduza o nome do contacto");
                            a.nome = Console.ReadLine();
                            if (a.nome.Contains(a.nome))
                            {
                                Console.WriteLine("esse nome ja foi introduzido");
                            }
                        } while (a.nome.Contains(a.nome));
                        if (Verificacao(a.nome))
                                Console.WriteLine(a.nome + " deve ser introduzido sem números ");

                        } while (Verificacao(a.nome));

                        do
                        {
                            Console.WriteLine(a.nome + " esta correto? sim - 1 / não - 2");
                            txt = Console.ReadLine();
                            if (!Int32.TryParse(txt, out num))
                            {
                                Console.WriteLine("Introduza um valor numérico!");
                            }
                            else if (num != 1 && num != 2)
                            { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                        } while (num != 2 && num != 1);

                    } while (num == 2);
                    //verifica se o usuário quer preencher um espaço opcional


                    do
                    {
                        
                            Console.WriteLine("Deseja introduzir o perfil social do contacto? sim - 1 / não - 2");
                            txt = Console.ReadLine();
                           
                            
                        if (!Int32.TryParse(txt, out num))
                        {
                            Console.WriteLine("Introduza um valor numérico!");
                        }
                        else if (num != 1 && num != 2)
                        { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                    } while (!Int32.TryParse(txt, out num) || (num != 1 && num != 2));

                    if (num == 1)
                    {
                        do
                        {
                            do
                            {
                                do { 
                                Console.WriteLine("Introduza o nome social do contacto");
                                a.perfilsocial = Console.ReadLine();
                                if (a.nome.Contains(a.perfilsocial))
                                {
                                    Console.WriteLine("esse nome ja foi introduzido");
                                }
                            } while (a.nome.Contains(a.perfilsocial));
                            if (Verificacao(a.perfilsocial))
                                    Console.WriteLine(a.perfilsocial + " deve ser introduzido sem números ");

                            } while (Verificacao(a.perfilsocial));


                            do
                            {
                                Console.WriteLine(a.perfilsocial + " esta correto? sim - 1 / não - 2");
                                txt = Console.ReadLine();
                                if (!Int32.TryParse(txt, out num))
                                {
                                    Console.WriteLine("Introduza um valor numérico!");
                                }
                                else if (num != 1 && num != 2)
                                { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                            } while (num != 2 && num != 1);

                        } while (num == 2);

                    }
                    num = 0;
                    //verifica se o usuário quer preencher outro espaço opcional
                    do
                    {
                        Console.WriteLine("Deseja introduzir os pronomes do contacto? sim - 1 / não - 2");
                        txt = Console.ReadLine();
                        if (!Int32.TryParse(txt, out num))
                        {
                            Console.WriteLine("Introduza um valor numérico!");
                        }
                        else if (num != 1 && num != 2)
                        { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                    } while (!Int32.TryParse(txt, out num) || (num != 2 && num != 1));
                    num = 0;
                    if (num == 1)
                    {
                        do
                        {
                            do
                            {
                                Console.WriteLine("Introduza os pronomes do contacto");
                                a.pronomes = Console.ReadLine();
                                if (Verificacao(a.pronomes))
                                    Console.WriteLine(a.pronomes + " deve ser introduzido sem números ");

                            } while (Verificacao(a.pronomes));

                            Console.WriteLine(a.pronomes + " esta correto? sim - 1 / não - 2");
                            txt = Console.ReadLine();
                            if (!Int32.TryParse(txt, out num))
                            {
                                Console.WriteLine("Introduza um valor numérico!");
                            }
                            else if (num != 1 && num != 2)
                            { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                        } while (num != 2 && num != 1 || !Int32.TryParse(txt, out num));
                    } while (num == 2) ;
                    num = 0;
                    //Introduz o número do contacto

                    do
                    {
                        do
                        {
                            int resp1 = 0;
                            do
                            {
                                do { 
                                Console.WriteLine("Introduza o número do contacto");
                                a.numero = Console.ReadLine();
                                if (a.numero.Contains(a.numero))
                                {
                                    Console.WriteLine("esse nome ja foi introduzido");
                                }
                            } while (a.nome.Contains(a.numero));
                        } while (resp1 == 1);
                            if (a.numero.Length < 9 || a.numero.Length > 9)
                            {
                                Console.WriteLine("O número de telefone deve possuir 9 dígitos");
                            }
                        } while (a.numero.Length < 9 || a.numero.Length > 9);
                        do
                        {
                            Console.WriteLine(a.numero + " esta correto? sim - 1 / não - 2");
                            txt = Console.ReadLine();
                            if (!Int32.TryParse(txt, out num))
                            {
                                Console.WriteLine("Introduza um valor numérico!");
                            }
                            else if (num != 1 && num != 2)
                            { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                        } while (num != 2 && num != 1 || !Int32.TryParse(txt, out num));
                    } while (num == 2);
                    num = 0;
                    //Introduz a afiliação do contacto
                    do
                    {
                        do
                        {
                            Console.WriteLine("Introduza a afiliação com o contacto");
                            a.afiliacao = Console.ReadLine();
                            if (Verificacao(a.afiliacao))
                                Console.WriteLine(a.afiliacao + " deve ser introduzido sem números ");

                        } while (Verificacao(a.afiliacao));
                        //verifica se esta correto a afiliação introduzida
                        do
                        {
                            Console.WriteLine(a.afiliacao + " esta correta? sim - 1 / não - 2");
                            txt = Console.ReadLine();
                            if (!Int32.TryParse(txt, out num))
                            {
                                Console.WriteLine("Introduza um valor numérico!");
                            }
                            else if (num != 1 && num != 2)
                            { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                        } while ((num != 2 && num != 1) || !Int32.TryParse(txt, out num));
                    } while (num == 2);
                    contactos.Add(a);
                    Console.WriteLine("O Índice deste contacto é " + contactos.Count);
                    num = 0;
                }
                else if (num2 == 2)
                {
                    do
                    {
                        Console.WriteLine("Deseja remover por índice ou por nome? índice - 1 | nome - 2");
                        txt = Console.ReadLine();
                        if (!Int32.TryParse(txt, out num))
                        {
                            Console.WriteLine("Introduza um valor numérico!");
                        }
                        else if (num != 1 && num != 2)
                        { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                    } while ((num != 2 && num != 1) || !Int32.TryParse(txt, out num));

                    if (num == 1)
                    {
                        do
                        {
                            Console.WriteLine("Insira o índice do contacto que quer remover:");
                            txt = Console.ReadLine();
                            if (!Int32.TryParse(txt, out num))
                            {
                                Console.WriteLine("Introduza um valor numérico!");
                            }
                            else if (num < 0 || num >= contactos.Count)
                            {
                                Console.WriteLine("Índice tem que estar dentro dos limites!");
                            }
                        } while (!Int32.TryParse(a.nome, out num));
                        contactos.RemoveAt(num);
                    }
                    else
                    {
                        do
                        {
                            Console.WriteLine("Insira o nome do contacto que quer remover:");
                            txt = Console.ReadLine();
                            if (Verificacao(txt))
                                Console.WriteLine(txt + " deve ser introduzido sem números ");
                            if (a.nome.Contains(txt))
                            {
                                Console.WriteLine("Contacto removido com sucesso.");
                            }
                            else
                            {
                                Console.WriteLine("Contacto não encontrado.");
                            }

                        } while (!Int32.TryParse(txt, out num));

                        if (contactos.Count != 0)
                        {
                            Console.WriteLine("Existem " + contactos.Count + " alunos na lista: ");
                        }
                        else
                            Console.WriteLine("Lista Vazia");
                    }



                }
                else if (num2 == 3)
                {
                    if (contactos.Count != 0)
                    {
                        Console.WriteLine("Existem " + contactos.Count + " contactos na lista:");
                        foreach (Contacto c in contactos)
                        {
                            Console.WriteLine("nome: " + a.nome);
                            Console.WriteLine("afiliação: " + a.afiliacao);
                            Console.WriteLine("número " + a.numero);
                        }
                    }
                    else
                        Console.WriteLine("Lista Vazia");
                }
                else { Console.WriteLine("Deve ser introduzido apenas 1,2 ou 3!"); }
                do
                {
                    Console.WriteLine("Deseja continuar? 1-sim | 2-não");
                    txt = Console.ReadLine();
                    if (!Int32.TryParse(txt, out num))
                    {
                        Console.WriteLine("Introduza um valor numérico!");
                    }
                    else if (num != 1 && num != 2)
                    { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
                } while (num != 2 && num != 1 || !Int32.TryParse(txt, out num));

            } while (num == 1);
        }
    }
}
