﻿namespace projetodepsi
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.GBIntrodução = new System.Windows.Forms.GroupBox();
            this.Sair = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.Mostrar = new System.Windows.Forms.Button();
            this.Alterar = new System.Windows.Forms.Button();
            this.Adicioanr = new System.Windows.Forms.Button();
            this.GBContinuação = new System.Windows.Forms.GroupBox();
            this.erro6num = new System.Windows.Forms.Label();
            this.erro5num = new System.Windows.Forms.Label();
            this.erro4num = new System.Windows.Forms.Label();
            this.erro3num = new System.Windows.Forms.Label();
            this.erro2num = new System.Windows.Forms.Label();
            this.erro1num = new System.Windows.Forms.Label();
            this.erro2txt = new System.Windows.Forms.Label();
            this.erro1txt = new System.Windows.Forms.Label();
            this.concluirinscricao = new System.Windows.Forms.Button();
            this.processoaluno = new System.Windows.Forms.TextBox();
            this.processoalunolb = new System.Windows.Forms.Label();
            this.inserir = new System.Windows.Forms.Button();
            this.Concluir = new System.Windows.Forms.Button();
            this.ndoprocesso = new System.Windows.Forms.TextBox();
            this.lblprocesso = new System.Windows.Forms.Label();
            this.veraluno = new System.Windows.Forms.Label();
            this.alteraraluno = new System.Windows.Forms.Label();
            this.preencheraluno = new System.Windows.Forms.Label();
            this.contactoed = new System.Windows.Forms.TextBox();
            this.nomed = new System.Windows.Forms.TextBox();
            this.idadealuno = new System.Windows.Forms.TextBox();
            this.cursoaluno = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.nomealuno = new System.Windows.Forms.TextBox();
            this.anoaluno = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.erro7num = new System.Windows.Forms.Label();
            this.aplicarinfo = new System.Windows.Forms.Button();
            this.erro1 = new System.Windows.Forms.Label();
            this.erro3txt = new System.Windows.Forms.Label();
            this.erro4txt = new System.Windows.Forms.Label();
            this.erroprocesso = new System.Windows.Forms.Label();
            this.GBIntrodução.SuspendLayout();
            this.GBContinuação.SuspendLayout();
            this.SuspendLayout();
            // 
            // GBIntrodução
            // 
            this.GBIntrodução.Controls.Add(this.Sair);
            this.GBIntrodução.Controls.Add(this.label10);
            this.GBIntrodução.Controls.Add(this.label9);
            this.GBIntrodução.Controls.Add(this.Mostrar);
            this.GBIntrodução.Controls.Add(this.Alterar);
            this.GBIntrodução.Controls.Add(this.Adicioanr);
            this.GBIntrodução.Location = new System.Drawing.Point(0, 0);
            this.GBIntrodução.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GBIntrodução.Name = "GBIntrodução";
            this.GBIntrodução.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GBIntrodução.Size = new System.Drawing.Size(1077, 769);
            this.GBIntrodução.TabIndex = 3;
            this.GBIntrodução.TabStop = false;
            this.GBIntrodução.Text = " ";
            // 
            // Sair
            // 
            this.Sair.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sair.Location = new System.Drawing.Point(351, 554);
            this.Sair.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Sair.Name = "Sair";
            this.Sair.Size = new System.Drawing.Size(368, 71);
            this.Sair.TabIndex = 17;
            this.Sair.Text = "Sair";
            this.Sair.UseVisualStyleBackColor = true;
            this.Sair.Click += new System.EventHandler(this.Sair_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(402, 180);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(240, 29);
            this.label10.TabIndex = 16;
            this.label10.Text = "Oque deseja fazer?";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(408, 43);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(241, 33);
            this.label9.TabIndex = 15;
            this.label9.Text = "Seja bem-vindo!";
            // 
            // Mostrar
            // 
            this.Mostrar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Mostrar.Location = new System.Drawing.Point(351, 474);
            this.Mostrar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Mostrar.Name = "Mostrar";
            this.Mostrar.Size = new System.Drawing.Size(368, 71);
            this.Mostrar.TabIndex = 3;
            this.Mostrar.Text = "Mostrar Aluno";
            this.Mostrar.UseVisualStyleBackColor = true;
            this.Mostrar.Click += new System.EventHandler(this.Mostrar_Click);
            // 
            // Alterar
            // 
            this.Alterar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Alterar.Location = new System.Drawing.Point(351, 394);
            this.Alterar.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Alterar.Name = "Alterar";
            this.Alterar.Size = new System.Drawing.Size(368, 71);
            this.Alterar.TabIndex = 2;
            this.Alterar.Text = "Alterar Aluno";
            this.Alterar.UseVisualStyleBackColor = true;
            this.Alterar.Click += new System.EventHandler(this.Alterar_Click);
            // 
            // Adicioanr
            // 
            this.Adicioanr.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Adicioanr.Location = new System.Drawing.Point(351, 314);
            this.Adicioanr.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Adicioanr.Name = "Adicioanr";
            this.Adicioanr.Size = new System.Drawing.Size(368, 71);
            this.Adicioanr.TabIndex = 1;
            this.Adicioanr.Text = "Adicionar Aluno";
            this.Adicioanr.UseVisualStyleBackColor = true;
            this.Adicioanr.Click += new System.EventHandler(this.Adicioanr_Click);
            // 
            // GBContinuação
            // 
            this.GBContinuação.Controls.Add(this.GBIntrodução);
            this.GBContinuação.Controls.Add(this.erroprocesso);
            this.GBContinuação.Controls.Add(this.erro4txt);
            this.GBContinuação.Controls.Add(this.erro3txt);
            this.GBContinuação.Controls.Add(this.erro1);
            this.GBContinuação.Controls.Add(this.aplicarinfo);
            this.GBContinuação.Controls.Add(this.erro7num);
            this.GBContinuação.Controls.Add(this.erro6num);
            this.GBContinuação.Controls.Add(this.erro5num);
            this.GBContinuação.Controls.Add(this.erro4num);
            this.GBContinuação.Controls.Add(this.erro3num);
            this.GBContinuação.Controls.Add(this.erro2num);
            this.GBContinuação.Controls.Add(this.erro1num);
            this.GBContinuação.Controls.Add(this.erro2txt);
            this.GBContinuação.Controls.Add(this.erro1txt);
            this.GBContinuação.Controls.Add(this.concluirinscricao);
            this.GBContinuação.Controls.Add(this.processoaluno);
            this.GBContinuação.Controls.Add(this.processoalunolb);
            this.GBContinuação.Controls.Add(this.inserir);
            this.GBContinuação.Controls.Add(this.Concluir);
            this.GBContinuação.Controls.Add(this.ndoprocesso);
            this.GBContinuação.Controls.Add(this.lblprocesso);
            this.GBContinuação.Controls.Add(this.veraluno);
            this.GBContinuação.Controls.Add(this.alteraraluno);
            this.GBContinuação.Controls.Add(this.preencheraluno);
            this.GBContinuação.Controls.Add(this.contactoed);
            this.GBContinuação.Controls.Add(this.nomed);
            this.GBContinuação.Controls.Add(this.idadealuno);
            this.GBContinuação.Controls.Add(this.cursoaluno);
            this.GBContinuação.Controls.Add(this.label7);
            this.GBContinuação.Controls.Add(this.label6);
            this.GBContinuação.Controls.Add(this.label5);
            this.GBContinuação.Controls.Add(this.label4);
            this.GBContinuação.Controls.Add(this.label3);
            this.GBContinuação.Controls.Add(this.label2);
            this.GBContinuação.Controls.Add(this.nomealuno);
            this.GBContinuação.Controls.Add(this.anoaluno);
            this.GBContinuação.Controls.Add(this.label1);
            this.GBContinuação.Location = new System.Drawing.Point(36, 18);
            this.GBContinuação.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GBContinuação.Name = "GBContinuação";
            this.GBContinuação.Padding = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.GBContinuação.Size = new System.Drawing.Size(1077, 769);
            this.GBContinuação.TabIndex = 2;
            this.GBContinuação.TabStop = false;
            this.GBContinuação.Text = " ";
            // 
            // erro6num
            // 
            this.erro6num.AutoSize = true;
            this.erro6num.ForeColor = System.Drawing.Color.Red;
            this.erro6num.Location = new System.Drawing.Point(760, 314);
            this.erro6num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro6num.Name = "erro6num";
            this.erro6num.Size = new System.Drawing.Size(198, 20);
            this.erro6num.TabIndex = 31;
            this.erro6num.Text = "A idade não deve ter letras";
            // 
            // erro5num
            // 
            this.erro5num.AutoSize = true;
            this.erro5num.ForeColor = System.Drawing.Color.Red;
            this.erro5num.Location = new System.Drawing.Point(756, 422);
            this.erro5num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro5num.Name = "erro5num";
            this.erro5num.Size = new System.Drawing.Size(266, 20);
            this.erro5num.TabIndex = 30;
            this.erro5num.Text = "O nº de processo não deve ter letras";
            // 
            // erro4num
            // 
            this.erro4num.AutoSize = true;
            this.erro4num.ForeColor = System.Drawing.Color.Red;
            this.erro4num.Location = new System.Drawing.Point(756, 395);
            this.erro4num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro4num.Name = "erro4num";
            this.erro4num.Size = new System.Drawing.Size(255, 20);
            this.erro4num.TabIndex = 29;
            this.erro4num.Text = "O nº de processo deve ter 5 dígitos";
            // 
            // erro3num
            // 
            this.erro3num.AutoSize = true;
            this.erro3num.ForeColor = System.Drawing.Color.Red;
            this.erro3num.Location = new System.Drawing.Point(760, 583);
            this.erro3num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro3num.Name = "erro3num";
            this.erro3num.Size = new System.Drawing.Size(288, 20);
            this.erro3num.TabIndex = 28;
            this.erro3num.Text = "O número de celular não pode ter letras";
            // 
            // erro2num
            // 
            this.erro2num.AutoSize = true;
            this.erro2num.ForeColor = System.Drawing.Color.Red;
            this.erro2num.Location = new System.Drawing.Point(756, 365);
            this.erro2num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro2num.Name = "erro2num";
            this.erro2num.Size = new System.Drawing.Size(313, 20);
            this.erro2num.TabIndex = 27;
            this.erro2num.Text = "Esse número de processo já foi introduzido";
            // 
            // erro1num
            // 
            this.erro1num.ForeColor = System.Drawing.Color.Red;
            this.erro1num.Location = new System.Drawing.Point(760, 269);
            this.erro1num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro1num.Name = "erro1num";
            this.erro1num.Size = new System.Drawing.Size(267, 49);
            this.erro1num.TabIndex = 26;
            this.erro1num.Text = "Não existem pessoas com essa idade no secundario";
            // 
            // erro2txt
            // 
            this.erro2txt.AutoSize = true;
            this.erro2txt.ForeColor = System.Drawing.Color.Red;
            this.erro2txt.Location = new System.Drawing.Point(760, 534);
            this.erro2txt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro2txt.Name = "erro2txt";
            this.erro2txt.Size = new System.Drawing.Size(295, 20);
            this.erro2txt.TabIndex = 25;
            this.erro2txt.Text = "O nome deve ser introduzido sem dígitos";
            // 
            // erro1txt
            // 
            this.erro1txt.AutoSize = true;
            this.erro1txt.ForeColor = System.Drawing.Color.Red;
            this.erro1txt.Location = new System.Drawing.Point(760, 245);
            this.erro1txt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro1txt.Name = "erro1txt";
            this.erro1txt.Size = new System.Drawing.Size(295, 20);
            this.erro1txt.TabIndex = 24;
            this.erro1txt.Text = "O nome deve ser introduzido sem dígitos";
            // 
            // concluirinscricao
            // 
            this.concluirinscricao.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.concluirinscricao.Location = new System.Drawing.Point(231, 651);
            this.concluirinscricao.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.concluirinscricao.Name = "concluirinscricao";
            this.concluirinscricao.Size = new System.Drawing.Size(266, 65);
            this.concluirinscricao.TabIndex = 23;
            this.concluirinscricao.Text = "Concluir";
            this.concluirinscricao.UseVisualStyleBackColor = true;
            this.concluirinscricao.Click += new System.EventHandler(this.concluirinscricao_Click);
            // 
            // processoaluno
            // 
            this.processoaluno.Location = new System.Drawing.Point(296, 391);
            this.processoaluno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.processoaluno.Name = "processoaluno";
            this.processoaluno.Size = new System.Drawing.Size(454, 26);
            this.processoaluno.TabIndex = 22;
            // 
            // processoalunolb
            // 
            this.processoalunolb.AutoSize = true;
            this.processoalunolb.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.processoalunolb.Location = new System.Drawing.Point(96, 394);
            this.processoalunolb.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.processoalunolb.Name = "processoalunolb";
            this.processoalunolb.Size = new System.Drawing.Size(179, 29);
            this.processoalunolb.TabIndex = 21;
            this.processoalunolb.Text = "Nº do processo";
            // 
            // inserir
            // 
            this.inserir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.inserir.Location = new System.Drawing.Point(778, 102);
            this.inserir.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.inserir.Name = "inserir";
            this.inserir.Size = new System.Drawing.Size(178, 48);
            this.inserir.TabIndex = 20;
            this.inserir.Text = "Mostrar";
            this.inserir.UseVisualStyleBackColor = true;
            this.inserir.Click += new System.EventHandler(this.inserir_Click);
            // 
            // Concluir
            // 
            this.Concluir.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Concluir.Location = new System.Drawing.Point(387, 651);
            this.Concluir.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Concluir.Name = "Concluir";
            this.Concluir.Size = new System.Drawing.Size(266, 65);
            this.Concluir.TabIndex = 19;
            this.Concluir.Text = "Concluir";
            this.Concluir.UseVisualStyleBackColor = true;
            this.Concluir.Click += new System.EventHandler(this.Concluir_Click);
            // 
            // ndoprocesso
            // 
            this.ndoprocesso.Location = new System.Drawing.Point(296, 112);
            this.ndoprocesso.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.ndoprocesso.Name = "ndoprocesso";
            this.ndoprocesso.Size = new System.Drawing.Size(454, 26);
            this.ndoprocesso.TabIndex = 18;
            this.ndoprocesso.TextChanged += new System.EventHandler(this.ndoprocesso_TextChanged);
            // 
            // lblprocesso
            // 
            this.lblprocesso.AutoSize = true;
            this.lblprocesso.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblprocesso.Location = new System.Drawing.Point(96, 111);
            this.lblprocesso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblprocesso.Name = "lblprocesso";
            this.lblprocesso.Size = new System.Drawing.Size(179, 29);
            this.lblprocesso.TabIndex = 17;
            this.lblprocesso.Text = "Nº do processo";
            // 
            // veraluno
            // 
            this.veraluno.AutoSize = true;
            this.veraluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.veraluno.Location = new System.Drawing.Point(210, 49);
            this.veraluno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.veraluno.Name = "veraluno";
            this.veraluno.Size = new System.Drawing.Size(620, 29);
            this.veraluno.TabIndex = 16;
            this.veraluno.Text = "Insira o número de processo do aluno de deseja ver";
            // 
            // alteraraluno
            // 
            this.alteraraluno.AutoSize = true;
            this.alteraraluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.alteraraluno.Location = new System.Drawing.Point(210, 49);
            this.alteraraluno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.alteraraluno.Name = "alteraraluno";
            this.alteraraluno.Size = new System.Drawing.Size(659, 29);
            this.alteraraluno.TabIndex = 15;
            this.alteraraluno.Text = "Insira o número de processo do aluno de deseja alterar";
            // 
            // preencheraluno
            // 
            this.preencheraluno.AutoSize = true;
            this.preencheraluno.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.preencheraluno.Location = new System.Drawing.Point(309, 43);
            this.preencheraluno.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.preencheraluno.Name = "preencheraluno";
            this.preencheraluno.Size = new System.Drawing.Size(428, 29);
            this.preencheraluno.TabIndex = 14;
            this.preencheraluno.Text = "Preencha as seguintes informações";
            // 
            // contactoed
            // 
            this.contactoed.Location = new System.Drawing.Point(296, 578);
            this.contactoed.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.contactoed.Name = "contactoed";
            this.contactoed.Size = new System.Drawing.Size(454, 26);
            this.contactoed.TabIndex = 13;
            // 
            // nomed
            // 
            this.nomed.Location = new System.Drawing.Point(296, 529);
            this.nomed.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nomed.Name = "nomed";
            this.nomed.Size = new System.Drawing.Size(454, 26);
            this.nomed.TabIndex = 12;
            // 
            // idadealuno
            // 
            this.idadealuno.Location = new System.Drawing.Point(296, 288);
            this.idadealuno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.idadealuno.Name = "idadealuno";
            this.idadealuno.Size = new System.Drawing.Size(454, 26);
            this.idadealuno.TabIndex = 11;
            // 
            // cursoaluno
            // 
            this.cursoaluno.FormattingEnabled = true;
            this.cursoaluno.Items.AddRange(new object[] {
            "Científico-Humanísticos",
            "Profissional",
            "Artístico Especializado",
            "Ensino e formação",
            "Aprendizazem "});
            this.cursoaluno.Location = new System.Drawing.Point(420, 340);
            this.cursoaluno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.cursoaluno.Name = "cursoaluno";
            this.cursoaluno.Size = new System.Drawing.Size(330, 28);
            this.cursoaluno.TabIndex = 10;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(156, 582);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(108, 29);
            this.label7.TabIndex = 9;
            this.label7.Text = "Contacto";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(186, 532);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 29);
            this.label6.TabIndex = 8;
            this.label6.Text = "Nome";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(360, 448);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(322, 29);
            this.label5.TabIndex = 7;
            this.label5.Text = "Encarregado de Educação";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(186, 345);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(77, 29);
            this.label4.TabIndex = 6;
            this.label4.Text = "Curso";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(195, 291);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 29);
            this.label3.TabIndex = 5;
            this.label3.Text = "Idade";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(186, 243);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 29);
            this.label2.TabIndex = 4;
            this.label2.Text = "Nome";
            // 
            // nomealuno
            // 
            this.nomealuno.Location = new System.Drawing.Point(296, 240);
            this.nomealuno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nomealuno.Name = "nomealuno";
            this.nomealuno.Size = new System.Drawing.Size(454, 26);
            this.nomealuno.TabIndex = 3;
            // 
            // anoaluno
            // 
            this.anoaluno.FormattingEnabled = true;
            this.anoaluno.Items.AddRange(new object[] {
            "10º",
            "11º",
            "12º"});
            this.anoaluno.Location = new System.Drawing.Point(296, 340);
            this.anoaluno.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.anoaluno.Name = "anoaluno";
            this.anoaluno.Size = new System.Drawing.Size(114, 28);
            this.anoaluno.TabIndex = 2;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(470, 180);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(79, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Aluno";
            // 
            // erro7num
            // 
            this.erro7num.AutoSize = true;
            this.erro7num.ForeColor = System.Drawing.Color.Red;
            this.erro7num.Location = new System.Drawing.Point(760, 605);
            this.erro7num.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro7num.Name = "erro7num";
            this.erro7num.Size = new System.Drawing.Size(211, 20);
            this.erro7num.TabIndex = 32;
            this.erro7num.Text = "O contacto deve ter 7 dígitos";
            // 
            // aplicarinfo
            // 
            this.aplicarinfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aplicarinfo.Location = new System.Drawing.Point(505, 651);
            this.aplicarinfo.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.aplicarinfo.Name = "aplicarinfo";
            this.aplicarinfo.Size = new System.Drawing.Size(266, 65);
            this.aplicarinfo.TabIndex = 33;
            this.aplicarinfo.Text = "Aplicar";
            this.aplicarinfo.UseVisualStyleBackColor = true;
            this.aplicarinfo.Click += new System.EventHandler(this.aplicarinfo_Click);
            // 
            // erro1
            // 
            this.erro1.AutoSize = true;
            this.erro1.ForeColor = System.Drawing.Color.Red;
            this.erro1.Location = new System.Drawing.Point(365, 626);
            this.erro1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro1.Name = "erro1";
            this.erro1.Size = new System.Drawing.Size(288, 20);
            this.erro1.TabIndex = 34;
            this.erro1.Text = "Introduza as informações corretamente";
            // 
            // erro3txt
            // 
            this.erro3txt.AutoSize = true;
            this.erro3txt.ForeColor = System.Drawing.Color.Red;
            this.erro3txt.Location = new System.Drawing.Point(760, 245);
            this.erro3txt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro3txt.Name = "erro3txt";
            this.erro3txt.Size = new System.Drawing.Size(215, 20);
            this.erro3txt.TabIndex = 35;
            this.erro3txt.Text = "O nome deve ser introduzido ";
            // 
            // erro4txt
            // 
            this.erro4txt.AutoSize = true;
            this.erro4txt.ForeColor = System.Drawing.Color.Red;
            this.erro4txt.Location = new System.Drawing.Point(760, 534);
            this.erro4txt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erro4txt.Name = "erro4txt";
            this.erro4txt.Size = new System.Drawing.Size(215, 20);
            this.erro4txt.TabIndex = 36;
            this.erro4txt.Text = "O nome deve ser introduzido ";
            // 
            // erroprocesso
            // 
            this.erroprocesso.AutoSize = true;
            this.erroprocesso.ForeColor = System.Drawing.Color.Red;
            this.erroprocesso.Location = new System.Drawing.Point(401, 87);
            this.erroprocesso.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.erroprocesso.Name = "erroprocesso";
            this.erroprocesso.Size = new System.Drawing.Size(215, 20);
            this.erroprocesso.TabIndex = 37;
            this.erroprocesso.Text = "O nº de processso não existe";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1156, 800);
            this.Controls.Add(this.GBContinuação);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.GBIntrodução.ResumeLayout(false);
            this.GBIntrodução.PerformLayout();
            this.GBContinuação.ResumeLayout(false);
            this.GBContinuação.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox GBIntrodução;
        private System.Windows.Forms.GroupBox GBContinuação;
        private System.Windows.Forms.TextBox contactoed;
        private System.Windows.Forms.TextBox nomed;
        private System.Windows.Forms.TextBox idadealuno;
        private System.Windows.Forms.ComboBox cursoaluno;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox nomealuno;
        private System.Windows.Forms.ComboBox anoaluno;
        private System.Windows.Forms.Button Adicioanr;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Mostrar;
        private System.Windows.Forms.Button Alterar;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox ndoprocesso;
        private System.Windows.Forms.Label lblprocesso;
        private System.Windows.Forms.Label veraluno;
        private System.Windows.Forms.Label alteraraluno;
        private System.Windows.Forms.Label preencheraluno;
        private System.Windows.Forms.Button Sair;
        private System.Windows.Forms.Button Concluir;
        private System.Windows.Forms.Button inserir;
        private System.Windows.Forms.TextBox processoaluno;
        private System.Windows.Forms.Label processoalunolb;
        private System.Windows.Forms.Button concluirinscricao;
        private System.Windows.Forms.Label erro1txt;
        private System.Windows.Forms.Label erro3num;
        private System.Windows.Forms.Label erro2num;
        private System.Windows.Forms.Label erro1num;
        private System.Windows.Forms.Label erro2txt;
        private System.Windows.Forms.Label erro5num;
        private System.Windows.Forms.Label erro4num;
        private System.Windows.Forms.Label erro6num;
        private System.Windows.Forms.Label erro7num;
        private System.Windows.Forms.Button aplicarinfo;
        private System.Windows.Forms.Label erro1;
        private System.Windows.Forms.Label erro4txt;
        private System.Windows.Forms.Label erro3txt;
        private System.Windows.Forms.Label erroprocesso;
    }
}

