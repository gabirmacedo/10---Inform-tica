﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int resp,sun;
            Console.WriteLine("Introduza um valor");
            resp = Convert.ToInt32(Console.ReadLine());
            sun = resp;
            for (int i = 2; i <= resp+1; i++)
            {
                Console.WriteLine(i +" e " +sun);
                sun= sun - 1;
            }

            Console.ReadKey();
        }
    }
}
