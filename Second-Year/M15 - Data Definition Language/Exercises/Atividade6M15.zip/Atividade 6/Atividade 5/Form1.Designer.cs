﻿namespace Atividade_5
{
    partial class Inscrições
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_camisola = new System.Windows.Forms.TextBox();
            this.tb_nome = new System.Windows.Forms.TextBox();
            this.cb_clube = new System.Windows.Forms.ComboBox();
            this.cb_prova = new System.Windows.Forms.ComboBox();
            this.bt_inserir = new System.Windows.Forms.Button();
            this.bt_listagem = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(223, 133);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(115, 30);
            this.label1.TabIndex = 0;
            this.label1.Text = "Camisola";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(223, 198);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 30);
            this.label2.TabIndex = 2;
            this.label2.Text = "Nome";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(223, 264);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 30);
            this.label3.TabIndex = 3;
            this.label3.Text = "Clube";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(227, 337);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 30);
            this.label4.TabIndex = 5;
            this.label4.Text = "Prova";
            // 
            // tb_camisola
            // 
            this.tb_camisola.BackColor = System.Drawing.SystemColors.HighlightText;
            this.tb_camisola.Enabled = false;
            this.tb_camisola.Location = new System.Drawing.Point(384, 137);
            this.tb_camisola.Name = "tb_camisola";
            this.tb_camisola.Size = new System.Drawing.Size(100, 26);
            this.tb_camisola.TabIndex = 12;
            // 
            // tb_nome
            // 
            this.tb_nome.Location = new System.Drawing.Point(384, 203);
            this.tb_nome.Name = "tb_nome";
            this.tb_nome.Size = new System.Drawing.Size(212, 26);
            this.tb_nome.TabIndex = 7;
            // 
            // cb_clube
            // 
            this.cb_clube.FormattingEnabled = true;
            this.cb_clube.Items.AddRange(new object[] {
            "rosa",
            "azul",
            "preto",
            "roxo"});
            this.cb_clube.Location = new System.Drawing.Point(384, 266);
            this.cb_clube.Name = "cb_clube";
            this.cb_clube.Size = new System.Drawing.Size(315, 28);
            this.cb_clube.TabIndex = 8;
            // 
            // cb_prova
            // 
            this.cb_prova.FormattingEnabled = true;
            this.cb_prova.Items.AddRange(new object[] {
            "CS",
            "FORTNITE",
            "MARVEL RIVALS"});
            this.cb_prova.Location = new System.Drawing.Point(384, 340);
            this.cb_prova.Name = "cb_prova";
            this.cb_prova.Size = new System.Drawing.Size(315, 28);
            this.cb_prova.TabIndex = 9;
            // 
            // bt_inserir
            // 
            this.bt_inserir.Location = new System.Drawing.Point(232, 488);
            this.bt_inserir.Name = "bt_inserir";
            this.bt_inserir.Size = new System.Drawing.Size(203, 38);
            this.bt_inserir.TabIndex = 10;
            this.bt_inserir.Text = "Inserir";
            this.bt_inserir.UseVisualStyleBackColor = true;
            this.bt_inserir.Click += new System.EventHandler(this.bt_inserir_Click);
            // 
            // bt_listagem
            // 
            this.bt_listagem.Location = new System.Drawing.Point(496, 488);
            this.bt_listagem.Name = "bt_listagem";
            this.bt_listagem.Size = new System.Drawing.Size(203, 38);
            this.bt_listagem.TabIndex = 11;
            this.bt_listagem.Text = "Listagem";
            this.bt_listagem.UseVisualStyleBackColor = true;
            this.bt_listagem.Click += new System.EventHandler(this.bt_listagem_Click);
            // 
            // Inscrições
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1490, 810);
            this.Controls.Add(this.bt_listagem);
            this.Controls.Add(this.bt_inserir);
            this.Controls.Add(this.cb_prova);
            this.Controls.Add(this.cb_clube);
            this.Controls.Add(this.tb_nome);
            this.Controls.Add(this.tb_camisola);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Inscrições";
            this.Text = "Inscrições";
            this.Load += new System.EventHandler(this.Inscrições_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_camisola;
        private System.Windows.Forms.TextBox tb_nome;
        private System.Windows.Forms.ComboBox cb_clube;
        private System.Windows.Forms.ComboBox cb_prova;
        private System.Windows.Forms.Button bt_inserir;
        private System.Windows.Forms.Button bt_listagem;
    }
}

