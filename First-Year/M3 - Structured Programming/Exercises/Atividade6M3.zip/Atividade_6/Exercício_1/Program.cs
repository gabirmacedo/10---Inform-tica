﻿using System;
using System.Collections.Generic;
using System.IO.Pipes;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Schema;

namespace Exercício_1
{
    internal class Program
    {
        static bool AnoBissexto(int ano)
        {
            if (ano % 4 == 0 && ano % 100 == 0 && ano % 400 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static int CalculoAno(int ano)
        {
            if (AnoBissexto(ano))
            {
                return 366;
            }
            else
            {
                return 365;
            }
        }
        static int QuantoEMes(int ano, int mes)
        {
            switch (mes)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    return 31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    return 30;
                    break;
                case 2:
                    {
                        if (AnoBissexto(ano))
                            return 29;
                        else
                            return 28;
                    }
                    break;
                default:
                    return 0;
             }
        }
       static int DiasPassados(int dias, int mes, int ano)
       {
            int soma = 0;
            for (int i=1; i < mes; i++)
            {
                soma = soma + QuantoEMes(ano, i);
            }
            return dias + soma;
         }
       static int DiasQueFaltam(int dia, int mes, int ano )
       {
            return CalculoAno(ano) - DiasPassados(dia, mes, ano);
       }
       static void Main(string[] args)
        {
            int dias, ano, mes;

            Console.WriteLine("Introduza em que ano estamos");
            ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza em que mês estamos");
            mes = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza em que dia estamos");
            dias = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Estamos em um ano Bissexto? "+ AnoBissexto(ano));
            Console.WriteLine("Quantos dias tem esse ano: " + CalculoAno(ano));
            Console.WriteLine("Quantos dias tem esse mês: " + QuantoEMes(ano,mes));
            Console.WriteLine("Quantos dias já se passaram: " + DiasPassados(dias, mes,ano));
            Console.WriteLine("Quantos dias faltam para o final do ano: " + DiasQueFaltam(dias, mes, ano));
            
            Console.ReadKey();


        }
    }
}
