﻿using System;
using System.Collections.Generic;
using System.Deployment.Internal;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string p1, p2;
            int cont = 0;

            Console.WriteLine("Introduza uma palavra: ");
            p1 = Console.ReadLine().ToUpper();
            Console.WriteLine("Introduza outra palavra: ");
            p2 = Console.ReadLine().ToUpper();

            char[] c1 = p1.ToCharArray(), c2 = p2.ToCharArray();
            for (int i = 0; i < Math.Min(c1.Length,c2.Length); i++)
            {
                if (c1[i] != c2[i])
                { Console.WriteLine($"A posição { i + 1 } é diferente"); }
            }

            Console.ReadKey();


        }
    }
}
