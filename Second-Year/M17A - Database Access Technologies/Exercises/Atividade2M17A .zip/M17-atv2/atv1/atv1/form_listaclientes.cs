﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv1
{
    public partial class Listagem_Clientes : Form
    {
        public Listagem_Clientes()
        {
            InitializeComponent();
        }

        public void Listagem_Clientes_Load(object sender, EventArgs e)
        {
            Listagem_Clientes listagem = new Listagem_Clientes();
        }

        private void lista_clientes_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
