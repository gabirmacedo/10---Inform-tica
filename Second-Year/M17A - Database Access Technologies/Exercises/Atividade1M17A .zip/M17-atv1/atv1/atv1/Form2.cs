﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;
using MySqlX.XDevAPI;

namespace atv1
{
    public partial class Form_produto : Form
    {
        struct Produto
        {
            public int idproduto;
            public string nomeprod;
            public string tipoprod;
            public double preco;
            public int quantstock;
        }
        List<Produto> produtos = new List<Produto>();
        Produto produto = new Produto();

        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=loja";
        public Form_produto()
        {
            InitializeComponent();
        }
        private void Preencher()
        {
            string sql = "select * from produto";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        produto.idproduto = reader.GetInt32("idProduto");
                        produto.nomeprod = reader.GetString("nomeprod");
                        produto.tipoprod = reader.GetString("tipoprod");
                        produto.preco = reader.GetDouble("preço");
                        produto.quantstock = reader.GetInt32("quantstock");

                        produtos.Add(produto);
                    }
                }
            }
        }
        private void LimparCampos()
        {
            tb_nomeprod.Clear();
            cb_tipoprod.Text = "";
            nud_preco.ResetText();
            nud_quantstock.ResetText();
        }
        private void Form_produto_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();
                MessageBox.Show("Conexão efetuada com sucesso");
                Preencher();
                tb_idproduto.Text = (produtos.Count() + 1).ToString();
            }
            catch(Exception ex) 
            {
                MessageBox.Show(Form_produto.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }
            cb_tipoprod.Items.Add("Casaco");
            cb_tipoprod.Items.Add("Calças");
            cb_tipoprod.Items.Add("Blusas");
            cb_tipoprod.Items.Add("Chapéis");
            cb_tipoprod.Items.Add("Sapatos");
            cb_tipoprod.Items.Add("Acessórios");
        }
        private void bt_inserirprod_Click(object sender, EventArgs e)
        {
            if (tb_nomeprod.Text != "" && cb_tipoprod.Text != "" && nud_preco.Text != "" && nud_quantstock.Text != "")
            {
                MessageBox.Show("O Formulário foi preenchido");

                produto.idproduto = Convert.ToInt32(tb_idproduto.Text);
                produto.nomeprod = tb_nomeprod.Text;
                produto.tipoprod = cb_tipoprod.Text;
                produto.preco = Convert.ToDouble(nud_preco.Value);
                produto.quantstock = Convert.ToInt32(nud_quantstock.Value);
                produtos.Add(produto);
                LimparCampos();


                string sql = "insert into loja.produto values(@idProduto,@nomeprod,@tipoprod,@preço,@quantstock)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@idProduto", produto.idproduto);
                    cmd.Parameters.AddWithValue("@nomeprod", produto.nomeprod);
                    cmd.Parameters.AddWithValue("@tipoprod", produto.tipoprod);
                    cmd.Parameters.AddWithValue("@preço", produto.preco);
                    cmd.Parameters.AddWithValue("@quantstock", produto.quantstock);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Registo inserido!", "Informação");
                }
            }
            else 
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
        }
        private void bt_limpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }
    }
}
