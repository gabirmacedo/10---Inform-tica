﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random aleatorio = new Random();
            int n, alae = aleatorio.Next(1,10);
            Console.WriteLine("Introduza um valor aleatório");
            do
            {
                n = Convert.ToInt32(Console.ReadLine());
                if (n < 1) {
                Console.WriteLine("Deve ser Introduzido um valor de 1 a 10");
                }
                else if (n > alae) 
                {
                    Console.WriteLine("O valor é maior que o número aleatório");
                    Console.WriteLine("Introduza outro valor");
                }
                else if (n < alae)
                {
                    Console.WriteLine("O valor é menor que o número aleatório");
                    Console.WriteLine("Introduza outro valor");
                }
            }
            while (n != alae);
            { Console.WriteLine("Você acertou! Parabéns!!");
            }
            Console.ReadKey();


        }
    }
}
