﻿namespace atv1
{
    partial class Listagem_Clientes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lista_clientes = new System.Windows.Forms.DataGridView();
            this.IdClientes = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NomeCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.emailCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.NifCliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.lista_clientes)).BeginInit();
            this.SuspendLayout();
            // 
            // lista_clientes
            // 
            this.lista_clientes.AllowUserToAddRows = false;
            this.lista_clientes.AllowUserToDeleteRows = false;
            this.lista_clientes.AllowUserToResizeColumns = false;
            this.lista_clientes.AllowUserToResizeRows = false;
            this.lista_clientes.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.lista_clientes.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lista_clientes.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lista_clientes.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.IdClientes,
            this.NomeCliente,
            this.emailCliente,
            this.NifCliente});
            this.lista_clientes.GridColor = System.Drawing.Color.Black;
            this.lista_clientes.Location = new System.Drawing.Point(-61, -2);
            this.lista_clientes.Name = "lista_clientes";
            this.lista_clientes.RowHeadersWidth = 62;
            this.lista_clientes.RowTemplate.Height = 28;
            this.lista_clientes.Size = new System.Drawing.Size(872, 369);
            this.lista_clientes.TabIndex = 0;
            this.lista_clientes.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.lista_clientes_CellContentClick);
            // 
            // IdClientes
            // 
            this.IdClientes.HeaderText = "ID";
            this.IdClientes.MinimumWidth = 8;
            this.IdClientes.Name = "IdClientes";
            this.IdClientes.Width = 150;
            // 
            // NomeCliente
            // 
            this.NomeCliente.HeaderText = "Nome";
            this.NomeCliente.MinimumWidth = 8;
            this.NomeCliente.Name = "NomeCliente";
            this.NomeCliente.Width = 150;
            // 
            // emailCliente
            // 
            this.emailCliente.HeaderText = "E-mail";
            this.emailCliente.MinimumWidth = 8;
            this.emailCliente.Name = "emailCliente";
            this.emailCliente.Width = 150;
            // 
            // NifCliente
            // 
            this.NifCliente.HeaderText = "NIF";
            this.NifCliente.MinimumWidth = 8;
            this.NifCliente.Name = "NifCliente";
            this.NifCliente.Width = 150;
            // 
            // Listagem_Clientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lista_clientes);
            this.Name = "Listagem_Clientes";
            this.Text = "Listagem Clientes";
            this.Load += new System.EventHandler(this.Listagem_Clientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lista_clientes)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView lista_clientes;
        private System.Windows.Forms.DataGridViewTextBoxColumn IdClientes;
        private System.Windows.Forms.DataGridViewTextBoxColumn NomeCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn emailCliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn NifCliente;
    }
}