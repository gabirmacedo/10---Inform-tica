﻿namespace trabalho_de_avaliação.livro
{
    partial class form_listaliv
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_listaliv));
            this.listalivros = new System.Windows.Forms.DataGridView();
            this.id_livro = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.titulo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoria = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomeautor = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.data = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idioma = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.preco = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.listalivros)).BeginInit();
            this.SuspendLayout();
            // 
            // listalivros
            // 
            this.listalivros.AllowUserToAddRows = false;
            this.listalivros.AllowUserToDeleteRows = false;
            this.listalivros.AllowUserToResizeColumns = false;
            this.listalivros.BackgroundColor = System.Drawing.Color.White;
            this.listalivros.CausesValidation = false;
            this.listalivros.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.listalivros.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.id_livro,
            this.titulo,
            this.categoria,
            this.idade,
            this.nomeautor,
            this.data,
            this.idioma,
            this.preco});
            this.listalivros.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listalivros.Location = new System.Drawing.Point(0, 0);
            this.listalivros.Name = "listalivros";
            this.listalivros.ReadOnly = true;
            this.listalivros.RowHeadersVisible = false;
            this.listalivros.RowHeadersWidth = 62;
            this.listalivros.RowTemplate.Height = 28;
            this.listalivros.Size = new System.Drawing.Size(2189, 1296);
            this.listalivros.TabIndex = 0;
            // 
            // id_livro
            // 
            this.id_livro.HeaderText = "ID";
            this.id_livro.MinimumWidth = 8;
            this.id_livro.Name = "id_livro";
            this.id_livro.ReadOnly = true;
            this.id_livro.Width = 150;
            // 
            // titulo
            // 
            this.titulo.HeaderText = "Título";
            this.titulo.MinimumWidth = 8;
            this.titulo.Name = "titulo";
            this.titulo.ReadOnly = true;
            this.titulo.Width = 150;
            // 
            // categoria
            // 
            this.categoria.HeaderText = "Categoria";
            this.categoria.MinimumWidth = 8;
            this.categoria.Name = "categoria";
            this.categoria.ReadOnly = true;
            this.categoria.Width = 150;
            // 
            // idade
            // 
            this.idade.HeaderText = "Faixa Etária";
            this.idade.MinimumWidth = 8;
            this.idade.Name = "idade";
            this.idade.ReadOnly = true;
            this.idade.Width = 150;
            // 
            // nomeautor
            // 
            this.nomeautor.HeaderText = "Autor";
            this.nomeautor.MinimumWidth = 8;
            this.nomeautor.Name = "nomeautor";
            this.nomeautor.ReadOnly = true;
            this.nomeautor.Width = 150;
            // 
            // data
            // 
            this.data.HeaderText = "Data";
            this.data.MinimumWidth = 8;
            this.data.Name = "data";
            this.data.ReadOnly = true;
            this.data.Width = 150;
            // 
            // idioma
            // 
            this.idioma.HeaderText = "Idioma";
            this.idioma.MinimumWidth = 8;
            this.idioma.Name = "idioma";
            this.idioma.ReadOnly = true;
            this.idioma.Width = 150;
            // 
            // preco
            // 
            this.preco.HeaderText = "Preço";
            this.preco.MinimumWidth = 8;
            this.preco.Name = "preco";
            this.preco.ReadOnly = true;
            this.preco.Width = 150;
            // 
            // form_listaliv
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2189, 1296);
            this.Controls.Add(this.listalivros);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_listaliv";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_listaliv";
            this.Load += new System.EventHandler(this.form_listaliv_Load);
            ((System.ComponentModel.ISupportInitialize)(this.listalivros)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView listalivros;
        private System.Windows.Forms.DataGridViewTextBoxColumn id_livro;
        private System.Windows.Forms.DataGridViewTextBoxColumn titulo;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoria;
        private System.Windows.Forms.DataGridViewTextBoxColumn idade;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomeautor;
        private System.Windows.Forms.DataGridViewTextBoxColumn data;
        private System.Windows.Forms.DataGridViewTextBoxColumn idioma;
        private System.Windows.Forms.DataGridViewTextBoxColumn preco;
    }
}