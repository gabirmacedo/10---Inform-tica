﻿namespace trabalho_de_avaliação.compra
{
    partial class form_listacompras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_listacompras));
            this.lista_compras = new System.Windows.Forms.DataGridView();
            this.idcompra = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idcliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.idliv = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantidade = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.lista_compras)).BeginInit();
            this.SuspendLayout();
            // 
            // lista_compras
            // 
            this.lista_compras.AllowUserToAddRows = false;
            this.lista_compras.AllowUserToDeleteRows = false;
            this.lista_compras.AllowUserToResizeColumns = false;
            this.lista_compras.BackgroundColor = System.Drawing.Color.White;
            this.lista_compras.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lista_compras.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idcompra,
            this.idcliente,
            this.idliv,
            this.Quantidade});
            this.lista_compras.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lista_compras.GridColor = System.Drawing.Color.White;
            this.lista_compras.Location = new System.Drawing.Point(0, 0);
            this.lista_compras.Name = "lista_compras";
            this.lista_compras.ReadOnly = true;
            this.lista_compras.RowHeadersWidth = 62;
            this.lista_compras.RowTemplate.Height = 28;
            this.lista_compras.Size = new System.Drawing.Size(2152, 1292);
            this.lista_compras.TabIndex = 0;
            // 
            // idcompra
            // 
            this.idcompra.HeaderText = "ID";
            this.idcompra.MinimumWidth = 8;
            this.idcompra.Name = "idcompra";
            this.idcompra.ReadOnly = true;
            this.idcompra.Width = 150;
            // 
            // idcliente
            // 
            this.idcliente.HeaderText = "Cliente";
            this.idcliente.MinimumWidth = 8;
            this.idcliente.Name = "idcliente";
            this.idcliente.ReadOnly = true;
            this.idcliente.Width = 150;
            // 
            // idliv
            // 
            this.idliv.HeaderText = "Livro";
            this.idliv.MinimumWidth = 8;
            this.idliv.Name = "idliv";
            this.idliv.ReadOnly = true;
            this.idliv.Width = 150;
            // 
            // Quantidade
            // 
            this.Quantidade.HeaderText = "Quantidade";
            this.Quantidade.MinimumWidth = 8;
            this.Quantidade.Name = "Quantidade";
            this.Quantidade.ReadOnly = true;
            this.Quantidade.Width = 150;
            // 
            // form_listacompras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2152, 1292);
            this.Controls.Add(this.lista_compras);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_listacompras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_listacompras";
            this.Load += new System.EventHandler(this.form_listacompras_Load);
            ((System.ComponentModel.ISupportInitialize)(this.lista_compras)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView lista_compras;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcompra;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn idliv;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantidade;
    }
}