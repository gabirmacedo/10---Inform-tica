﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int[] num = new int[15];
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine("Insira 15 valores");
                num[i] = Convert.ToInt32(Console.ReadLine());
            }
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(i + 1 + "º Número");
                Console.WriteLine(num[i]);
                Console.WriteLine(num[i] * num[i] + "É o quadrado do número" );
                Console.WriteLine(Math.Sqrt(num[i])+ "É a raiz quadrada do número");
            }
            Console.ReadKey();
        }
    }
}
