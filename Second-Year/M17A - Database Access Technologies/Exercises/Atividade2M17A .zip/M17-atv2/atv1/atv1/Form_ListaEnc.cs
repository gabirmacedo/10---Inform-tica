﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv1
{
    public partial class Form_ListaEnc : Form
    {
        public Form_ListaEnc()
        {
            InitializeComponent();
        }

        private void Form_ListaEnc_Load(object sender, EventArgs e)
        {
            Form_ListaEnc listagem = new Form_ListaEnc();
        }
    }
}
