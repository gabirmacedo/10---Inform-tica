﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n;
            do
            {
                Console.WriteLine("Introduza um valor.");
                n = Convert.ToInt32(Console.ReadLine());
            }
            while (n != 0);
            Console.ReadKey();
        }
    }
}
