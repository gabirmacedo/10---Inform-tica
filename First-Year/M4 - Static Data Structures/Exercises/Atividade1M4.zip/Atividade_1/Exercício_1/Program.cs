﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_1
{
    internal class Program
    {
        static void Main(string[] args)
        {


            int[] num = new int[5];
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine("Insira 5 valores");
                num[i] = Convert.ToInt32(Console.ReadLine());
            }

            Console.WriteLine("Os valores pares são:");
            for (int i = 0; i < num.Length; i++)
            {
                if (num[i] % 2 == 0)
                { Console.WriteLine(num[i]); }
            }
            Console.ReadKey();
        }
    }
}
