﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Channels;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] humidade = new double[3,4];

            //Pede e atribui os valores ao array (exercício 2: a)
            for (int i = 0; i < humidade.GetLength(0); i++)
            {
                for (int j = 0; j < humidade.GetLength(1); j++)
                {
                    Console.WriteLine($"Insira a humidade pela {j + 1}º vez do {i + 1}º mês.");
                    humidade[i,j] = Convert.ToDouble(Console.ReadLine());
                }

            }

            //Pede ao utilizador que escolha um dos 3 meses para consultar a média dos 4 valores pedidos (exercício 2: b)
            double soma=0;
            int resp; 
            Console.WriteLine("De qual mês gostaria de consultar a média?");
            resp = Convert.ToInt32(Console.ReadLine());
            for (int j = 0; j < humidade.GetLength(1); j++)
            {
                soma = soma + humidade[resp-1,j];
            }
            Console.WriteLine($"A média dos 4 valores do {resp}º mês é {soma / 4}");

            //Alterar o código anterior de forma a que esteja sempre pedindo o número do mês e afixada a média (exercício 2: c)
            string resposta;
            do
            { 
                int resp2;
                double soma2 = 0;
                
                Console.WriteLine("De qual mês gostaria de consultar a média?");
                resp2 = Convert.ToInt32(Console.ReadLine());
                for (int j = 0; j < humidade.GetLength(1); j++)
                {
                    soma2 = soma2 + humidade[resp2 - 1, j];
                }
                Console.WriteLine($"A média dos 4 valores do {resp2}º mês é {soma2 / 4}");
                
                Console.WriteLine("Deseja continuar? SIM/NÃO");
                resposta = Console.ReadLine().ToUpper(); 
                if(resposta != "NÃO" && resposta != "SIM")
                {
                    Console.WriteLine("Deve ser introduzido apenas SIM/NÃO");

                }
                
            } while (resposta == "SIM");


            Console.ReadKey();


        }
    }
}
