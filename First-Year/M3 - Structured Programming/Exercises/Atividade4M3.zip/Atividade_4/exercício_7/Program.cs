﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercício_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double soma=0,peso, cont =0;
            while (cont < 10) 
            {
                Console.WriteLine("Introduza o peso");
                peso = Convert.ToDouble(Console.ReadLine());
                cont = cont + 1;
                soma= soma + peso;
                if (cont == 10) { Console.WriteLine("Foi introduzido o valor máximo de 10 valores"); }
                else if (peso > 5000){ Console.WriteLine("Foi atingido o valor máximo de soma"); }
            }
            Console.WriteLine("A média dos valores todos é " + soma/cont);
            Console.ReadKey();
        }
    }
}
