﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.IO;


namespace Atividade_5
{
    public partial class Inscrições : Form
    {
        MySqlConnection conexao;
        const string infConexao = "datasource=localhost;port=3306;username=root;password=mysql;database=atividade_6";
        
        struct Atleta
        {
            public string camisola;
            public string nome;
            public string clube;
            public string prova;
        }
        List<Atleta> inscricoes = new List<Atleta>();
        Atleta a = new Atleta();
        public Inscrições()
        {
            InitializeComponent();
        }
        private void PreencherLista()
        {
            string sql = "select * from inscricoes";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        a.camisola = reader.GetString("camisola");
                        a.nome = reader.GetString("nome");
                        a.clube = reader.GetString("clube");
                        a.prova = reader.GetString("prova");

                        inscricoes.Add(a);
                    }
                }
            }
        }
        private void Inscrições_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infConexao);
                conexao.Open();

                MessageBox.Show("Conexão efetuada com sucesso");
                PreencherLista();
                tb_camisola.Text = (inscricoes.Count + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Inscrições.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void bt_inserir_Click(object sender, EventArgs e)
        {
                if (tb_nome.Text != "" && cb_clube.Text != "" && cb_prova.Text != "")
                {
                    //Adicionar a Lista
                    a.camisola = tb_camisola.Text;
                    a.nome = tb_nome.Text;
                    a.clube = cb_clube.Text;
                    a.prova = cb_prova.Text;
                    inscricoes.Add(a);

                    string sql = "insert into atividade_6.inscricoes values(@camisola,@nome,@clube,@prova)";
                    using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                    {
                        cmd.Parameters.AddWithValue("@camisola", a.camisola);
                        cmd.Parameters.AddWithValue("@nome", a.nome);
                        cmd.Parameters.AddWithValue("@clube", a.clube);
                        cmd.Parameters.AddWithValue("@prova", a.prova);

                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Registo inserido!", "Informação");
                    }
                    //Limpar campos
                    
                    tb_nome.Clear();
                    cb_clube.Text = "";
                    cb_prova.Text = "";
                    tb_camisola.Text = (inscricoes.Count + 1).ToString();
                }
                else
                {
                    MessageBox.Show("Todos os campos devem ser preenchidos antes de continuar..");
                }
        }
        private void bt_listagem_Click(object sender, EventArgs e)
        {
            frmListagem listagem = new frmListagem();
            foreach (Atleta a in inscricoes)
            {
            listagem.dGvGrelha.Rows.Add(
            a.camisola, a.nome, a.clube,a.prova);
            }
            listagem.Show()                                                ;        
        }
    }
}
