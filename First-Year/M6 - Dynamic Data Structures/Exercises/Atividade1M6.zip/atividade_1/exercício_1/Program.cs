﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_1
{
    class Program
    {
        struct Doente
        {
            public string nome;
            public string especialidade;
            public double horario;
        }
        static int Verificação(string verificar)
        {
            for (int i = 0; i > verificar.Length; i++)
            {
                if (char.IsDigit(verificar[i]))
                {
                    Console.WriteLine("A resposta introduzida não pode ter valores númericos..");
                    return 1;
                }
            }
            return 0;
        }
        static void Main(string[] args)
        {
            int resp1;
            string resptxt;
            char resptxt1;
            string verificar;
            Queue<Doente> doentes = new Queue<Doente>();
            Doente d;

            do
            {
                do{
                    Console.WriteLine("Olá, o que deseja fazer? " +
                        " Adicionar um doente - 1 / Atender um doente - 2 / Listar os doentes - 3");
                    resptxt = Console.ReadLine();

                    if (int.TryParse(resptxt, out resp1) == false || resp1 < 1 || resp1 > 3)
                    {
                        Console.WriteLine("Deve ser introduzido um valor numérico");
                    }
                } while (int.TryParse(resptxt, out resp1) == false || resp1 < 1 || resp1 > 3);

                if (resp1 == 1)
                {
                    do { 
                        Console.WriteLine("Qual o nome do doente?");
                        d.nome = Console.ReadLine();
                        verificar = d.nome;
                    } while (Verificação(verificar) == 1);
                    do
                    {
                        Console.WriteLine("Qual a espcialidade do doente?");
                        d.especialidade = Console.ReadLine();
                        verificar = d.especialidade;
                    } while (Verificação(verificar) == 1);
                    Console.WriteLine("Que horas foi a visita do doente?");
                    resptxt = Console.ReadLine();
                    if (double.TryParse(resptxt, out d.horario) == false)
                    {
                        Console.WriteLine("Deve ser introduzido um valor numérico");
                    }
                    doentes.Enqueue(d);
                }
                else if (resp1 == 2)
                {
                    if (doentes.Count != 0)
                    {
                        d = doentes.Dequeue();
                        Console.WriteLine("O paciente "+ d.nome + " foi atendido");
                    }
                    else 
                    {
                        Console.WriteLine("A fila está vazia");
                    }
                }
                else
                {
                    if (doentes.Count != 0)
                    {
                        foreach (Doente dt in doentes)
                        {
                            Console.WriteLine(" As informações dos pacientes em espera são:");
                            Console.WriteLine("Nome:" + dt.nome);
                            Console.WriteLine("Especialidade:" + dt.especialidade);
                            Console.WriteLine("Horário:" + dt.horario);
                        }
                    }
                    else { Console.WriteLine("A fila está vazia"); }
                }
                
                do{
                    Console.WriteLine("Deseja continuar a consultar? S/N");
                    resptxt1 = Convert.ToChar(Console.ReadLine().ToUpper());
                    if (resptxt1 != 'N'&& resptxt1 != 'S')
                    {
                        Console.WriteLine("A resposta introduzida deve ser apenas não ou sim");
                    }
                } while (resptxt1 != 'N' && resptxt1 != 'S');
            } while (resptxt1 == 'S');

            Console.ReadKey();

        }
    }
}
