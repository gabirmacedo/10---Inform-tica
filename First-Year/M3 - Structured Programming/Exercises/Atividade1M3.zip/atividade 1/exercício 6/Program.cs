﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Double cat1, cat2, hip;
            Console.WriteLine("Insire o valor do primeiro cateto do triangulo retangulo");
            cat1 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Insire o valor do primeiro cateto do triangulo retangulo");
            cat2 = Convert.ToDouble(Console.ReadLine());
            hip = Convert.ToDouble(Math.Sqrt(Math.Pow(cat1, 2) + Math.Pow(cat2, 2)));
            Console.WriteLine("A hipotenusa do triangulo retangulo é " + Math.Round(hip));
            Console.ReadKey();

        }
    }
}
