﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercíci_o_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] preço = new double[8];
            int resp;
            string resposta;
            do
            {
                for (int i = 0; i < 8; i++)
                {
                    Console.WriteLine();
                    preço[8] = Convert.ToDouble(Console.ReadLine());
                }

                Console.WriteLine("Gostaria de consultar os preços de saldo(1) ou os preços originais(2)?");
                resp = Convert.ToInt32(Console.ReadLine());

                if (resp == 1)
                {
                    for (int i = 0; i < 8; i++)
                    { Console.WriteLine(preço[i] * 0.25); }

                } else if (resp == 2) 
                { 
                    for (int i = 0; i < 8; i++)
                    { Console.WriteLine(preço[i]); }
                }
                else { Console.WriteLine("Apenas deve ser introduzido 1 ou 2"); }

                Console.WriteLine("Gostaria de continuar? Sim/Não");
                resposta = Console.ReadLine();

                if (resposta != "Não" || resposta != "não")
                {
                    Console.WriteLine("Deve ser introduzido apenas Sim ou Não");
                }
                
            } while (resposta == "Sim" || resposta == "sim");
            Console.ReadKey();
        }
    }
}
