﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace execício_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int soma = 0;
            for (int i = 0; i <= 100; i++)
            {
                if (i % 2 == 0)
                {
                    soma = soma + i;
                }
            }
            Console.WriteLine("A soma de todos os números pares de 0 até 100 é " + soma);
            Console.ReadKey();

            int soma2 = 0;
            for (int i = 0; i <= 100; i=i+2)
            {
                    soma2 = soma2 + i;
            }
            Console.WriteLine("A soma de todos os números pares de 0 até 100 é " + soma);
            Console.ReadKey();
        }
    }
}
