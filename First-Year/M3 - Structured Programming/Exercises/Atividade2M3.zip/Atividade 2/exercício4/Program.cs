﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string mes;
            Console.WriteLine("Introduza o valor de um dos meses do ano");
            mes = Console.ReadLine();
            if (mes == "1" || mes == "3" || mes == "5" || mes == "7" || mes == "8" || mes == "10" || mes == "12")
            { Console.WriteLine("Esse mês tem 31 dias"); }
            else if (mes == "2")
            { Console.WriteLine("Esse mês tem 28/29 dias"); }
            else if (mes == "4" || mes == "6" || mes == "9" || mes == "11")
            { Console.WriteLine("Esse mês tem 30 dias"); }
            else
            { Console.WriteLine("Deve ser inserido um valor de mês válido"); }

            Console.ReadKey();




        }
    }
}
