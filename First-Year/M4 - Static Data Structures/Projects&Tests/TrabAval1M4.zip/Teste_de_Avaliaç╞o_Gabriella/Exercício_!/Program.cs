﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício__
{
    internal class Program
    {
        static void Main(string[] args)
        { 

            double[] valor = new double[9];
            
                for (int i = 0; i < valor.Length; i++)
                {
                    Console.WriteLine("Introduza 9 valores");
                    valor[i] = Convert.ToDouble(Console.ReadLine());
                }
                for(int i = 0; i < valor.Length; i++)
                {
                Console.WriteLine($"O triplo de {valor[i]} é {valor[i]*3} e a sua metade é {valor[i]/2}");
                }
                Console.ReadKey();
        }
    }
}
