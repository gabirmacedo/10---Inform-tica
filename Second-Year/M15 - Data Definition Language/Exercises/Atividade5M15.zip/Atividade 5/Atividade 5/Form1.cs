﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Inscrições : Form
    {
        int x;
        struct Atleta
        {
            public string camisola;
            public string nome;
            public string clube;
            public string prova;
        }
        Atleta[] inscricoes = new Atleta[10];
        public Inscrições()
        {
            InitializeComponent();
        }
        private void Inscrições_Load(object sender, EventArgs e)
        {
            x = 1;
            tb_camisola.Text = x.ToString();
        }
        private void bt_inserir_Click(object sender, EventArgs e)
        {
            if(x == 10)
            {
            if (tb_nome.Text != "" && cb_clube.Text != "" && cb_prova.Text != "")
                {

                    inscricoes[x].camisola = tb_camisola.Text;
                    inscricoes[x].nome = tb_nome.Text;
                    inscricoes[x].clube = cb_clube.Text;
                    inscricoes[x].prova = cb_prova.Text;
                    x++;
                    tb_camisola.Text = x.ToString();
                    tb_camisola.Clear();
                    tb_nome.Clear();
                    cb_clube.Text = "";
                    cb_prova.Text = "";
                }
                else
                {
                    MessageBox.Show("Todos os campos devem ser preenchidos antes de continuar..");
                }
            }
            else
            {
                MessageBox.Show("Devem ser preenchidos 10 atletas");
            }
            
        }
        private void bt_listagem_Click(object sender, EventArgs e)
        {
            
            frmListagem listagem = new frmListagem();

            for (int i = 0; i < inscricoes.Length; i++)
            {
                listagem.dGvGrelha.Rows.Add(
                    inscricoes[i].camisola,
                    inscricoes[i].nome,
                    inscricoes[i].clube,
                    inscricoes[i].prova
                );
            }
            listagem.Show();
        }
    }
}
