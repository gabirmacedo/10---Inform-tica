﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2
{
    internal class Program
    {
        static int IntroduzirNumeros()
        {
            Console.WriteLine("Introduza um número");
            int a = Convert.ToInt32(Console.ReadLine());
            return a;
        }
        static int Maior(int x, int y, int z)
        {
            return Math.Max(Math.Max(x, y), z);
        }
        static void Main(string[] args)
        {
            int x, y, z;
            x = IntroduzirNumeros();
            z = IntroduzirNumeros();
            y = IntroduzirNumeros();
            
            Console.WriteLine(Maior(x,y,z));
            Console.ReadKey();


        }
    }
}
