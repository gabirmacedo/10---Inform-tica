﻿namespace trabalho_de_avaliação
{
    partial class form_menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_menu));
            this.bt_compra = new System.Windows.Forms.Button();
            this.bt_livro = new System.Windows.Forms.Button();
            this.bt_cliente = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_compra
            // 
            this.bt_compra.AllowDrop = true;
            this.bt_compra.BackColor = System.Drawing.Color.White;
            this.bt_compra.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.bt_compra.FlatAppearance.BorderSize = 3;
            this.bt_compra.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_compra.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_compra.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bt_compra.Location = new System.Drawing.Point(688, 430);
            this.bt_compra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_compra.Name = "bt_compra";
            this.bt_compra.Size = new System.Drawing.Size(503, 70);
            this.bt_compra.TabIndex = 0;
            this.bt_compra.Text = "Registrar Compra";
            this.bt_compra.UseVisualStyleBackColor = false;
            this.bt_compra.Click += new System.EventHandler(this.bt_compra_Click);
            // 
            // bt_livro
            // 
            this.bt_livro.BackColor = System.Drawing.Color.White;
            this.bt_livro.FlatAppearance.BorderColor = System.Drawing.Color.DarkOrange;
            this.bt_livro.FlatAppearance.BorderSize = 3;
            this.bt_livro.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_livro.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_livro.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bt_livro.Location = new System.Drawing.Point(688, 302);
            this.bt_livro.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_livro.Name = "bt_livro";
            this.bt_livro.Size = new System.Drawing.Size(503, 70);
            this.bt_livro.TabIndex = 1;
            this.bt_livro.Text = "Registrar Livro";
            this.bt_livro.UseVisualStyleBackColor = false;
            this.bt_livro.Click += new System.EventHandler(this.bt_livro_Click);
            // 
            // bt_cliente
            // 
            this.bt_cliente.BackColor = System.Drawing.Color.White;
            this.bt_cliente.FlatAppearance.BorderColor = System.Drawing.Color.DeepSkyBlue;
            this.bt_cliente.FlatAppearance.BorderSize = 3;
            this.bt_cliente.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_cliente.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.bt_cliente.Location = new System.Drawing.Point(688, 176);
            this.bt_cliente.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_cliente.Name = "bt_cliente";
            this.bt_cliente.Size = new System.Drawing.Size(503, 70);
            this.bt_cliente.TabIndex = 2;
            this.bt_cliente.Text = "Registrar Cliente";
            this.bt_cliente.UseVisualStyleBackColor = false;
            this.bt_cliente.Click += new System.EventHandler(this.bt_cliente_Click);
            // 
            // form_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1283, 690);
            this.Controls.Add(this.bt_cliente);
            this.Controls.Add(this.bt_livro);
            this.Controls.Add(this.bt_compra);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "form_menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form menu";
            this.Load += new System.EventHandler(this.form_menu_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_compra;
        private System.Windows.Forms.Button bt_livro;
        private System.Windows.Forms.Button bt_cliente;
    }
}

