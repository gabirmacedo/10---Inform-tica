﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int n1, soma=0;
            do
            {
                Console.WriteLine("Introduza um valor");
                n1 = Convert.ToInt32(Console.ReadLine());
                soma = Convert.ToInt32(soma+n1);
            }
            while (soma <= 1000);
            Console.ReadKey();
        }
    }
}
