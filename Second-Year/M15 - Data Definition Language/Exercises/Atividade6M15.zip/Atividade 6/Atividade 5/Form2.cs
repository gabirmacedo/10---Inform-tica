﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class frmListagem : Form
    {
        public frmListagem()
        {
            InitializeComponent();
        }

        public void frmListagem_Load(object sender, EventArgs e)
        {
            frmListagem listagem = new frmListagem();
        }
        public void dGvGrelha_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
