﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_5
{
    public partial class Inscrições : Form
    {
        int x;
        struct Atleta
        {
            public string camisola;
            public string nome;
            public string clube;
            public string prova;
        }
        List<Atleta> inscricoes = new List<Atleta>();
        public Inscrições()
        {
            InitializeComponent();
        }
        private void Inscrições_Load(object sender, EventArgs e)
        {
            x = 1;
            tb_camisola.Text = x.ToString();
        }
        private void bt_inserir_Click(object sender, EventArgs e)
        {
            if (tb_camisola.Text == "10")
            {
                if (tb_nome.Text != "" && cb_clube.Text != "" && cb_prova.Text != "")
                {
                    Atleta a = new Atleta();
                    a.camisola = tb_camisola.Text;
                    a.nome = tb_nome.Text;
                    a.clube = cb_clube.Text;
                    a.prova = cb_prova.Text;
                    x++;
                    tb_camisola.Text = x.ToString();
                    inscricoes.Add(a);

                    tb_camisola.Clear();
                    tb_nome.Clear();
                    cb_clube.Text = "";
                    cb_prova.Text = "";
                }
                else
                {
                    MessageBox.Show("Todos os campos devem ser preenchidos antes de continuar..");
                }
            }
            else
            {
                MessageBox.Show("Devem ser preechidos 10 atletas");
            }
            
        }
        
            
        
        private void bt_listagem_Click(object sender, EventArgs e)
        {
            
            frmListagem listagem = new frmListagem();

            foreach (Atleta a in inscricoes)
            {
                listagem.dGvGrelha.Rows.Add(
                a.camisola, a.nome, a.clube,a.prova);
            }

            listagem.Show();
        }
    }
}
