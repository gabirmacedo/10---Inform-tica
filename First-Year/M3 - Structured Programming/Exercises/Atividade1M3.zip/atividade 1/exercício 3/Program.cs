﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercícios_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x, z;
            Console.WriteLine("Introduza o valor para concluirmos umas equação");
            x = Convert.ToInt32(Console.ReadLine());
            z = Convert.ToInt32(Math.Pow(x, 2) + (2 * x) + 3);
            Console.WriteLine("O número lido foi " + x + "e o resultado é " + z);
            Console.ReadKey();
        }
    }
}
