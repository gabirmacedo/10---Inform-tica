﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atv1
{
    public partial class Form_menu : System.Windows.Forms.Form
    {
        public Form_menu()
        {
            InitializeComponent();
        }

        private void bt_cliente_Click(object sender, EventArgs e)
        {
            Form_Clientes Form_Clientes = new Form_Clientes();
            Form_Clientes.ShowDialog();
            this.Close();
        }

        private void bt_produto_Click(object sender, EventArgs e)
        {
            Form_produto Form_produto = new Form_produto();
            Form_produto.ShowDialog();
            this.Close();
        }
    }
}
