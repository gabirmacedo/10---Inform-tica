﻿namespace Atividade_3
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.cbo_Ementa = new System.Windows.Forms.ComboBox();
            this.nud_Criancas = new System.Windows.Forms.NumericUpDown();
            this.nud_Adultos = new System.Windows.Forms.NumericUpDown();
            this.nud_Dieta = new System.Windows.Forms.NumericUpDown();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_NumAdultos = new System.Windows.Forms.Label();
            this.lbl_NumCriancas = new System.Windows.Forms.Label();
            this.lbl_NumDieta = new System.Windows.Forms.Label();
            this.bt_Calcular = new System.Windows.Forms.Button();
            this.bt_LimparValores = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lbl_PagFinal = new System.Windows.Forms.Label();
            this.lbl_SinDeReserva = new System.Windows.Forms.Label();
            this.lbl_PrecoTotal = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Criancas)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Adultos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dieta)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(318, 41);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(94, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ementa";
            // 
            // cbo_Ementa
            // 
            this.cbo_Ementa.FormattingEnabled = true;
            this.cbo_Ementa.Items.AddRange(new object[] {
            "Deluxe",
            "Portuguesa",
            "Prestígio",
            "Rodízio",
            "Soberba"});
            this.cbo_Ementa.Location = new System.Drawing.Point(435, 39);
            this.cbo_Ementa.Name = "cbo_Ementa";
            this.cbo_Ementa.Size = new System.Drawing.Size(121, 28);
            this.cbo_Ementa.TabIndex = 1;
            // 
            // nud_Criancas
            // 
            this.nud_Criancas.Location = new System.Drawing.Point(314, 203);
            this.nud_Criancas.Name = "nud_Criancas";
            this.nud_Criancas.Size = new System.Drawing.Size(124, 26);
            this.nud_Criancas.TabIndex = 2;
            this.nud_Criancas.ValueChanged += new System.EventHandler(this.nud_Criancas_ValueChanged);
            // 
            // nud_Adultos
            // 
            this.nud_Adultos.Location = new System.Drawing.Point(314, 144);
            this.nud_Adultos.Name = "nud_Adultos";
            this.nud_Adultos.Size = new System.Drawing.Size(124, 26);
            this.nud_Adultos.TabIndex = 3;
            this.nud_Adultos.ValueChanged += new System.EventHandler(this.nud_Adultos_ValueChanged);
            // 
            // nud_Dieta
            // 
            this.nud_Dieta.Location = new System.Drawing.Point(314, 264);
            this.nud_Dieta.Name = "nud_Dieta";
            this.nud_Dieta.Size = new System.Drawing.Size(124, 26);
            this.nud_Dieta.TabIndex = 4;
            this.nud_Dieta.ValueChanged += new System.EventHandler(this.nud_Dieta_ValueChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(231, 144);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 22);
            this.label2.TabIndex = 5;
            this.label2.Text = "Adultos";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(219, 203);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(89, 22);
            this.label3.TabIndex = 6;
            this.label3.Text = "Crianças";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(251, 264);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 22);
            this.label4.TabIndex = 7;
            this.label4.Text = "Dieta";
            // 
            // lbl_NumAdultos
            // 
            this.lbl_NumAdultos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_NumAdultos.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NumAdultos.Location = new System.Drawing.Point(502, 143);
            this.lbl_NumAdultos.Name = "lbl_NumAdultos";
            this.lbl_NumAdultos.Size = new System.Drawing.Size(114, 34);
            this.lbl_NumAdultos.TabIndex = 8;
            this.lbl_NumAdultos.Text = "0€";
            this.lbl_NumAdultos.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_NumAdultos.Click += new System.EventHandler(this.lbl_NumAdultos_Click);
            // 
            // lbl_NumCriancas
            // 
            this.lbl_NumCriancas.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_NumCriancas.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NumCriancas.Location = new System.Drawing.Point(502, 202);
            this.lbl_NumCriancas.Name = "lbl_NumCriancas";
            this.lbl_NumCriancas.Size = new System.Drawing.Size(114, 34);
            this.lbl_NumCriancas.TabIndex = 9;
            this.lbl_NumCriancas.Text = "0€";
            this.lbl_NumCriancas.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbl_NumDieta
            // 
            this.lbl_NumDieta.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_NumDieta.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_NumDieta.Location = new System.Drawing.Point(502, 263);
            this.lbl_NumDieta.Name = "lbl_NumDieta";
            this.lbl_NumDieta.Size = new System.Drawing.Size(114, 34);
            this.lbl_NumDieta.TabIndex = 10;
            this.lbl_NumDieta.Text = "0€";
            this.lbl_NumDieta.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lbl_NumDieta.Click += new System.EventHandler(this.lbl_NumDieta_Click);
            // 
            // bt_Calcular
            // 
            this.bt_Calcular.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.bt_Calcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_Calcular.Location = new System.Drawing.Point(212, 413);
            this.bt_Calcular.Name = "bt_Calcular";
            this.bt_Calcular.Size = new System.Drawing.Size(171, 73);
            this.bt_Calcular.TabIndex = 11;
            this.bt_Calcular.Text = "Calcular";
            this.bt_Calcular.UseVisualStyleBackColor = false;
            this.bt_Calcular.Click += new System.EventHandler(this.bt_Calcular_Click);
            // 
            // bt_LimparValores
            // 
            this.bt_LimparValores.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.bt_LimparValores.Font = new System.Drawing.Font("Microsoft Sans Serif", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_LimparValores.Location = new System.Drawing.Point(480, 413);
            this.bt_LimparValores.Name = "bt_LimparValores";
            this.bt_LimparValores.Size = new System.Drawing.Size(217, 73);
            this.bt_LimparValores.TabIndex = 12;
            this.bt_LimparValores.Text = "Limpar valores";
            this.bt_LimparValores.UseVisualStyleBackColor = false;
            this.bt_LimparValores.Click += new System.EventHandler(this.bt_LimparValores_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(235, 658);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(160, 22);
            this.label8.TabIndex = 15;
            this.label8.Text = "Pagamento Final";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(173, 597);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(222, 22);
            this.label9.TabIndex = 14;
            this.label9.Text = "Sinal de Reserva (30%)";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(281, 538);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(114, 22);
            this.label10.TabIndex = 13;
            this.label10.Text = "Preço Total";
            // 
            // lbl_PagFinal
            // 
            this.lbl_PagFinal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_PagFinal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PagFinal.Location = new System.Drawing.Point(442, 657);
            this.lbl_PagFinal.Name = "lbl_PagFinal";
            this.lbl_PagFinal.Size = new System.Drawing.Size(114, 34);
            this.lbl_PagFinal.TabIndex = 18;
            // 
            // lbl_SinDeReserva
            // 
            this.lbl_SinDeReserva.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_SinDeReserva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_SinDeReserva.Location = new System.Drawing.Point(442, 596);
            this.lbl_SinDeReserva.Name = "lbl_SinDeReserva";
            this.lbl_SinDeReserva.Size = new System.Drawing.Size(114, 34);
            this.lbl_SinDeReserva.TabIndex = 17;
            // 
            // lbl_PrecoTotal
            // 
            this.lbl_PrecoTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_PrecoTotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_PrecoTotal.Location = new System.Drawing.Point(442, 537);
            this.lbl_PrecoTotal.Name = "lbl_PrecoTotal";
            this.lbl_PrecoTotal.Size = new System.Drawing.Size(114, 34);
            this.lbl_PrecoTotal.TabIndex = 16;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(883, 756);
            this.Controls.Add(this.lbl_PagFinal);
            this.Controls.Add(this.lbl_SinDeReserva);
            this.Controls.Add(this.lbl_PrecoTotal);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.bt_LimparValores);
            this.Controls.Add(this.bt_Calcular);
            this.Controls.Add(this.lbl_NumDieta);
            this.Controls.Add(this.lbl_NumCriancas);
            this.Controls.Add(this.lbl_NumAdultos);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.nud_Dieta);
            this.Controls.Add(this.nud_Adultos);
            this.Controls.Add(this.nud_Criancas);
            this.Controls.Add(this.cbo_Ementa);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Eventos Sociais";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_Criancas)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Adultos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_Dieta)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cbo_Ementa;
        private System.Windows.Forms.NumericUpDown nud_Criancas;
        private System.Windows.Forms.NumericUpDown nud_Adultos;
        private System.Windows.Forms.NumericUpDown nud_Dieta;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lbl_NumAdultos;
        private System.Windows.Forms.Label lbl_NumCriancas;
        private System.Windows.Forms.Label lbl_NumDieta;
        private System.Windows.Forms.Button bt_Calcular;
        private System.Windows.Forms.Button bt_LimparValores;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lbl_PagFinal;
        private System.Windows.Forms.Label lbl_SinDeReserva;
        private System.Windows.Forms.Label lbl_PrecoTotal;
    }
}

