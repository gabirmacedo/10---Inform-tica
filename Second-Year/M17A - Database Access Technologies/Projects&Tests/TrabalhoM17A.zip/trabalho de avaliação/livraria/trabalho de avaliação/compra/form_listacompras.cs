﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_de_avaliação.compra
{
    public partial class form_listacompras : Form
    {
        public form_listacompras()
        {
            InitializeComponent();
        }

        private void form_listacompras_Load(object sender, EventArgs e)
        {
            form_listacompras listagem = new form_listacompras();
        }
    }
}
