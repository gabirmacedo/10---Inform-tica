﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace exercicio4
{
    public partial class Form1 : Form
    {
        private void PreencherCombos()
        {
            for (int i = 1; i <= 20; i++) 
            {
                cb_esc.Items.Add(i);
                cb_oral.Items.Add(i);
                cb_apt.Items.Add(i);           
            }
        }
        private int ContarLinguas()
        {
            int count = 0;

            if (cbx__espanhol.Checked)
            {
                count++;
            }
            if (cbx_ingles.Checked)
            {
                count++;
            }
            if (cbx_alemao.Checked)
            {
                count++;
            }
            if (cbx_portugues.Checked)
            {
                count++;
            }
            if (cbx_frances.Checked)
            {
                count++;
            }
            if (cbx_russo.Checked)
            {
                count++;
            }
            return count;
        }
        private void LimparControlos()
        {
            txtbox_nome.Clear();
            cbx__espanhol.Checked = false;
            cbx_russo.Checked = false;
            cbx_portugues.Checked = false;
            cbx_ingles.Checked = false;
            cbx_alemao.Checked = false;
            cbx_frances.Checked = false;
            cb_apt.Text = "";
            cb_esc.Text = "";
            cb_oral.Text = "";

        }
        private string CalcularResultado()
        {
            string classificacao;
            int media = 0;
            int apt = 0;
            int oral = 0;
            int esc = 0;

            Int32.TryParse(cb_apt.Text, out apt);
            Int32.TryParse(cb_oral.Text, out oral);
            Int32.TryParse(cb_esc.Text, out esc);
            media = (apt + oral + esc) / 3;


            if (media < 10)
            { classificacao = "Repovado"; }
            else
              classificacao = "Aprovado";

            return classificacao;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        { 
            PreencherCombos();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void bt_limpar_Click(object sender, EventArgs e)
        {
            LimparControlos();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void bt_submeter_Click(object sender, EventArgs e)
        {
            if ((ContarLinguas() == 0 || cb_apt.Text == "" || cb_esc.Text == "" || cb_oral.Text == "" || txtbox_nome.Text == ""))
            {
                MessageBox.Show("Preencha todos os Campos antes de Submeter");
            }
            dataGridView1.Rows.Add
            (txtbox_nome.Text, cb_esc.Text, cb_oral.Text, cb_apt.Text, ContarLinguas(), CalcularResultado());
            LimparControlos();
        }
    }
}
