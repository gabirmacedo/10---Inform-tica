﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n,maior;
            Console.WriteLine("Introduza um valor");
            n = Convert.ToDouble(Console.ReadLine());
            maior = n;
            for (int i = 0; i < 9; i++)
            {
                Console.WriteLine("Introduza um valor");
                n = Convert.ToDouble(Console.ReadLine());
                maior = Math.Max(n,maior);
                /*if(n > maior)
                    maior = n;*/
            }
            Console.WriteLine("O maior número é " + maior);
            Console.ReadKey();
        }
    }
}
