﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;

namespace atv1
{
    public partial class form_encomendas : Form
    {
        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=loja";
        struct Encomenda
        {
            public int idencomenda;
            public DateTime data;
            public int idproduto;
            public int quantidade;
            public double preco;
            public int idcliente;
        }
        List<Encomenda> encomendas = new List<Encomenda>();
        Encomenda encomenda = new Encomenda();
        private void LimparCampos()
        {
            tbidenc.Text = "";
            tbidcli.Text = "";
            tbidprod.Text = "";
            nudquant.Value= 0;
            nudpreco.Value = 0;
        }
        private void Preencher()
        {
            string sql = "select * from encomenda";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        encomenda.idencomenda = reader.GetInt32("idEncomenda");
                        encomenda.data = reader.GetDateTime("data");
                        encomenda.idproduto = reader.GetInt32("idproduto");
                        encomenda.quantidade = reader.GetInt32("quant");
                        encomenda.preco = reader.GetDouble("preço");
                        encomenda.idcliente = reader.GetInt32("idcliente");

                        encomendas.Add(encomenda);
                    }
                }
            }
        }

       
        public form_encomendas()
        {
            InitializeComponent();
        }

        private void form_encomendas_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();

                MessageBox.Show("Conexão efetuada com sucesso");
                Preencher();
                tbidenc.Text = (encomendas.Count() + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(Form_produto.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_limparenc_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void bt_inserirenc_Click(object sender, EventArgs e)
        {
            string sqlCheck = "SELECT COUNT(*) FROM produto WHERE idProduto=@id";

            using (MySqlCommand cmd = new MySqlCommand(sqlCheck, conexao))
            {
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(tbidprod.Text));

                int existe = Convert.ToInt32(cmd.ExecuteScalar());

                if (existe == 0)
                {
                    MessageBox.Show("Produto não existe!");
                    return;
                }
            }
            if (tbidenc.Text != "" && dtpenc.Text != "" && nudpreco.Text != "" && tbidcli.Text != "" && tbidprod.Text != "" && nudquant.Text != "")
            {
                MessageBox.Show("O Formulário foi preenchido");

                encomenda.idencomenda = Convert.ToInt32(tbidenc.Text);
                encomenda.data = Convert.ToDateTime(dtpenc.Value);
                encomenda.idproduto = Convert.ToInt32(tbidprod.Text);
                encomenda.quantidade = Convert.ToInt32(nudquant.Text);
                encomenda.preco = Convert.ToDouble(nudpreco.Text);
                encomenda.idcliente = Convert.ToInt32(tbidcli.Text);

                encomendas.Add(encomenda);

                string sql = "insert into loja.encomenda values(@idEncomenda,@data,@idproduto,@quant,@preço,@idcliente)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@idEncomenda", encomenda.idencomenda);
                    cmd.Parameters.AddWithValue("@data", encomenda.data);
                    cmd.Parameters.AddWithValue("@idproduto", encomenda.idproduto);
                    cmd.Parameters.AddWithValue("@quant", encomenda.quantidade);
                    cmd.Parameters.AddWithValue("@preço", encomenda.preco);
                    cmd.Parameters.AddWithValue("@idcliente", encomenda.idcliente);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Registo inserido!", "Informação");
                }

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
        }

        private void bt_Listagemenc_Click(object sender, EventArgs e)
        {
            this.Close();
            Form_ListaEnc listagem = new Form_ListaEnc();

            foreach (Encomenda a in encomendas)
            {
                listagem.dataGridView1.Rows.Add(
                a.idencomenda, a.data, a.idproduto, a.quantidade, a.preco, a.idcliente);
            }

            listagem.Show();
        }

        private void bt_editar_Click(object sender, EventArgs e)
        {
            if (tbidenc.Text != "" && tbidcli.Text != "" && tbidprod.Text != "")
            {
                int id = Convert.ToInt32(tbidenc.Text);

                string sql = "UPDATE encomenda SET data=@data, idproduto=@idproduto, quant=@quant, preço=@preço, idcliente=@idcliente WHERE idEncomenda=@id";

                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@id", id);
                    cmd.Parameters.AddWithValue("@data", Convert.ToDateTime(dtpenc.Value));
                    cmd.Parameters.AddWithValue("@idproduto", Convert.ToInt32(tbidprod.Text));
                    cmd.Parameters.AddWithValue("@quant", Convert.ToInt32(nudquant.Value));
                    cmd.Parameters.AddWithValue("@preço", Convert.ToDouble(nudpreco.Value));
                    cmd.Parameters.AddWithValue("@idcliente", Convert.ToInt32(tbidcli.Text));

                    cmd.ExecuteNonQuery();
                }

                // Atualizar lista local
                for (int i = 0; i < encomendas.Count; i++)
                {
                    if (encomendas[i].idencomenda == id)
                    {
                        encomenda.idencomenda = id;
                        encomenda.data = Convert.ToDateTime(dtpenc.Value);
                        encomenda.idproduto = Convert.ToInt32(tbidprod.Text);
                        encomenda.quantidade = Convert.ToInt32(nudquant.Value);
                        encomenda.preco = Convert.ToDouble(nudpreco.Value);
                        encomenda.idcliente = Convert.ToInt32(tbidcli.Text);

                        encomendas[i] = encomenda;
                        break;
                    }
                }

                MessageBox.Show("Encomenda alterada com sucesso!", "Informação");

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }
        }
    }
}
