﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void lst_Tabuada_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cbo_num_SelectedIndexChanged(object sender, EventArgs e)
        {
            int num = int.Parse(cbo_num.Text);
            lst_Tabuada.Items.Clear();
            for (int i = 0; i <= cbo_num.Items.Count; i++)
            {
                string linha = string.Format("{0} X {1} = {2}", num, i, num * i);
                lst_Tabuada.Items.Add(linha);
            }
        }
    }
}
