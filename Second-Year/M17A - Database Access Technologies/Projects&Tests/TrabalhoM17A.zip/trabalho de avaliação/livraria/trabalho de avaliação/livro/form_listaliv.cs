﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using trabalho_de_avaliação.cliente;

namespace trabalho_de_avaliação.livro
{
    public partial class form_listaliv : Form
    {
        public form_listaliv()
        {
            InitializeComponent();
        }
        private void form_listaliv_Load(object sender, EventArgs e)
        {
            form_listaliv listagem = new form_listaliv();
        }
    }
}
