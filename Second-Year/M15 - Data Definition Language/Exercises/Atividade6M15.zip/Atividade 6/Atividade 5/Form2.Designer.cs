﻿namespace Atividade_5
{
    partial class frmListagem
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dGvGrelha = new System.Windows.Forms.DataGridView();
            this.Camisola = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nome = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Clube = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Prova = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dGvGrelha)).BeginInit();
            this.SuspendLayout();
            // 
            // dGvGrelha
            // 
            this.dGvGrelha.AllowUserToAddRows = false;
            this.dGvGrelha.AllowUserToDeleteRows = false;
            this.dGvGrelha.AllowUserToResizeColumns = false;
            this.dGvGrelha.AllowUserToResizeRows = false;
            this.dGvGrelha.BackgroundColor = System.Drawing.SystemColors.ButtonFace;
            this.dGvGrelha.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dGvGrelha.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dGvGrelha.ColumnHeadersVisible = false;
            this.dGvGrelha.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Camisola,
            this.Nome,
            this.Clube,
            this.Prova});
            this.dGvGrelha.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dGvGrelha.GridColor = System.Drawing.Color.Black;
            this.dGvGrelha.Location = new System.Drawing.Point(0, 0);
            this.dGvGrelha.Name = "dGvGrelha";
            this.dGvGrelha.ReadOnly = true;
            this.dGvGrelha.RowHeadersVisible = false;
            this.dGvGrelha.RowHeadersWidth = 62;
            this.dGvGrelha.RowTemplate.Height = 28;
            this.dGvGrelha.Size = new System.Drawing.Size(1145, 621);
            this.dGvGrelha.TabIndex = 0;
            this.dGvGrelha.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dGvGrelha_CellContentClick);
            // 
            // Camisola
            // 
            this.Camisola.HeaderText = "camisola";
            this.Camisola.MinimumWidth = 8;
            this.Camisola.Name = "Camisola";
            this.Camisola.ReadOnly = true;
            this.Camisola.Width = 50;
            // 
            // Nome
            // 
            this.Nome.HeaderText = "nome";
            this.Nome.MinimumWidth = 8;
            this.Nome.Name = "Nome";
            this.Nome.ReadOnly = true;
            this.Nome.Width = 200;
            // 
            // Clube
            // 
            this.Clube.HeaderText = "clube";
            this.Clube.MinimumWidth = 8;
            this.Clube.Name = "Clube";
            this.Clube.ReadOnly = true;
            this.Clube.Width = 200;
            // 
            // Prova
            // 
            this.Prova.HeaderText = "prova";
            this.Prova.MinimumWidth = 8;
            this.Prova.Name = "Prova";
            this.Prova.ReadOnly = true;
            this.Prova.Width = 150;
            // 
            // frmListagem
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1145, 621);
            this.Controls.Add(this.dGvGrelha);
            this.Name = "frmListagem";
            this.Text = "Listagem";
            this.Load += new System.EventHandler(this.frmListagem_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dGvGrelha)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView dGvGrelha;
        private System.Windows.Forms.DataGridViewTextBoxColumn Camisola;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nome;
        private System.Windows.Forms.DataGridViewTextBoxColumn Clube;
        private System.Windows.Forms.DataGridViewTextBoxColumn Prova;
    }
}