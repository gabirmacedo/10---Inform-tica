﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int resp;
            Console.WriteLine("Introduza um valor para a quantidade de multiplos");
            resp = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Os primeiros " + resp + " mútliplos de 3 são: ");

            for (int i = 1; i <= resp; i++)
            {
                Console.WriteLine(3 * i);
                
            }
           
            Console.ReadKey();
        }
    }
}
