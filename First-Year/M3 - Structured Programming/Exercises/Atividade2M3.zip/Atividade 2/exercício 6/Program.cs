﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            Console.WriteLine("Insire o dia de hoje");
            y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insire o mês de hoje");
            x = Convert.ToInt32(Console.ReadLine());
            switch (x)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    if (y < 0 || y > 31)
                        Console.WriteLine("O dia deve ser entre 1 a 31");
                    else Console.WriteLine("Faltam " + (y - 31) + "dias/dia para o final do mês");
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    if (y < 0 || y > 30)
                        Console.WriteLine("O dia deve ser entre 1 a 30");
                    else Console.WriteLine("Faltam " + (y - 30) + "dias/dia para o final do mês");
                    break;
                case 2:
                    if (y < 0 || y > 29)
                        Console.WriteLine("O dia deve ser entre 1 a 29");
                    else Console.WriteLine("Faltam " + (y - 29)+"/"+ (y - 28) + "dias/dia para o final do mês");
                    break;
                default: Console.WriteLine("O mês deve ser de 1 a 12.");
                    break;
                    
            }
            Console.ReadKey();
        }
    }
}
