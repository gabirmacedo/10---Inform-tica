﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace trabalho_de_avaliação.cliente
{
    public partial class form_listcli : Form
    {
        public form_listcli()
        {
            InitializeComponent();
        }

        public void form_listcli_Load(object sender, EventArgs e)
        {
            form_listcli listagem = new form_listcli();
        }
    }
}
