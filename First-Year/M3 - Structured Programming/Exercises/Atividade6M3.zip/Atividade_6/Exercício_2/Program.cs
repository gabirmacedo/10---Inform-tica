﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2
{
    internal class Program
    {
        static bool AnoBissexto(int ano)
        {
            if (ano % 4 == 0 && ano % 100 == 0 && ano % 400 == 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        static int QuantoEMes(int ano, int mes)
        {
            switch (mes)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    return 31;
                case 4:
                case 6:
                case 9:
                case 11:
                    return 30;
                case 2:
                    {
                        if (AnoBissexto(ano))
                            return 29;
                        else
                            return 28;
                    }
                default:
                    return 0;
            }
        }
        static int MesQueEstamos(int dia, int ano)
        {
            int cont = 0;
            do
            {
                dia = dia - QuantoEMes(ano, cont);
                cont = cont + 1;
            } while (dia > QuantoEMes(ano, cont) && cont != 12);
            return cont;
        }
        static int DiaQueEstamos(int dia, int ano)
        {
            int cont = 0;
            do
            {
                dia = dia - QuantoEMes(ano, cont);
                cont = cont + 1;
                 
            } while (dia > QuantoEMes(ano, cont) && cont != 12);
            return dia;
        }
        static void Main(string[] args)
        {
            int ano, dia;

            Console.WriteLine("Introduza em que ano estamos");
            ano = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza em que dia estamos");
            dia = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Estamos no mês:" + MesQueEstamos(dia,ano));
            Console.WriteLine("Estamos no dia:" + DiaQueEstamos(dia,ano));

            Console.ReadKey();
        }
    }
}
