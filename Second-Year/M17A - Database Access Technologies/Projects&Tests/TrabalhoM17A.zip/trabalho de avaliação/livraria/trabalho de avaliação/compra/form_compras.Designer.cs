﻿namespace trabalho_de_avaliação
{
    partial class form_compras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_compras));
            this.ID_Cliente = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.tb_idcli = new System.Windows.Forms.TextBox();
            this.tb_idliv = new System.Windows.Forms.TextBox();
            this.nud_quant = new System.Windows.Forms.NumericUpDown();
            this.bt_limpar = new System.Windows.Forms.Button();
            this.bt_voltar = new System.Windows.Forms.Button();
            this.bt_inserir = new System.Windows.Forms.Button();
            this.bt_consultar = new System.Windows.Forms.Button();
            this.tb_idcompra = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nud_quant)).BeginInit();
            this.SuspendLayout();
            // 
            // ID_Cliente
            // 
            this.ID_Cliente.AutoSize = true;
            this.ID_Cliente.BackColor = System.Drawing.Color.White;
            this.ID_Cliente.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ID_Cliente.Location = new System.Drawing.Point(376, 149);
            this.ID_Cliente.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.ID_Cliente.Name = "ID_Cliente";
            this.ID_Cliente.Size = new System.Drawing.Size(125, 29);
            this.ID_Cliente.TabIndex = 0;
            this.ID_Cliente.Text = "ID_Cliente";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(399, 217);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 29);
            this.label2.TabIndex = 1;
            this.label2.Text = "ID_Livro";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(364, 275);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(138, 29);
            this.label3.TabIndex = 2;
            this.label3.Text = "Quantidade";
            // 
            // tb_idcli
            // 
            this.tb_idcli.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_idcli.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_idcli.Location = new System.Drawing.Point(540, 144);
            this.tb_idcli.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_idcli.Name = "tb_idcli";
            this.tb_idcli.Size = new System.Drawing.Size(379, 35);
            this.tb_idcli.TabIndex = 3;
            // 
            // tb_idliv
            // 
            this.tb_idliv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_idliv.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_idliv.Location = new System.Drawing.Point(540, 211);
            this.tb_idliv.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_idliv.Name = "tb_idliv";
            this.tb_idliv.Size = new System.Drawing.Size(379, 35);
            this.tb_idliv.TabIndex = 4;
            // 
            // nud_quant
            // 
            this.nud_quant.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nud_quant.Location = new System.Drawing.Point(540, 275);
            this.nud_quant.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.nud_quant.Name = "nud_quant";
            this.nud_quant.Size = new System.Drawing.Size(379, 35);
            this.nud_quant.TabIndex = 5;
            // 
            // bt_limpar
            // 
            this.bt_limpar.BackColor = System.Drawing.Color.White;
            this.bt_limpar.FlatAppearance.BorderColor = System.Drawing.Color.YellowGreen;
            this.bt_limpar.FlatAppearance.BorderSize = 3;
            this.bt_limpar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_limpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_limpar.Location = new System.Drawing.Point(433, 349);
            this.bt_limpar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_limpar.Name = "bt_limpar";
            this.bt_limpar.Size = new System.Drawing.Size(431, 37);
            this.bt_limpar.TabIndex = 17;
            this.bt_limpar.Text = "Limpar";
            this.bt_limpar.UseVisualStyleBackColor = false;
            this.bt_limpar.Click += new System.EventHandler(this.bt_limpar_Click);
            // 
            // bt_voltar
            // 
            this.bt_voltar.BackColor = System.Drawing.Color.White;
            this.bt_voltar.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.bt_voltar.FlatAppearance.BorderSize = 3;
            this.bt_voltar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_voltar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_voltar.Location = new System.Drawing.Point(162, 456);
            this.bt_voltar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_voltar.Name = "bt_voltar";
            this.bt_voltar.Size = new System.Drawing.Size(305, 56);
            this.bt_voltar.TabIndex = 18;
            this.bt_voltar.Text = "Voltar ao Menu";
            this.bt_voltar.UseVisualStyleBackColor = false;
            this.bt_voltar.Click += new System.EventHandler(this.bt_voltar_Click);
            // 
            // bt_inserir
            // 
            this.bt_inserir.BackColor = System.Drawing.Color.White;
            this.bt_inserir.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bt_inserir.FlatAppearance.BorderSize = 3;
            this.bt_inserir.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_inserir.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_inserir.Location = new System.Drawing.Point(486, 456);
            this.bt_inserir.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_inserir.Name = "bt_inserir";
            this.bt_inserir.Size = new System.Drawing.Size(305, 56);
            this.bt_inserir.TabIndex = 19;
            this.bt_inserir.Text = "Inserir Compra";
            this.bt_inserir.UseVisualStyleBackColor = false;
            this.bt_inserir.Click += new System.EventHandler(this.bt_inserir_Click);
            // 
            // bt_consultar
            // 
            this.bt_consultar.BackColor = System.Drawing.Color.White;
            this.bt_consultar.FlatAppearance.BorderColor = System.Drawing.Color.SkyBlue;
            this.bt_consultar.FlatAppearance.BorderSize = 3;
            this.bt_consultar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.bt_consultar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bt_consultar.Location = new System.Drawing.Point(807, 456);
            this.bt_consultar.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.bt_consultar.Name = "bt_consultar";
            this.bt_consultar.Size = new System.Drawing.Size(305, 56);
            this.bt_consultar.TabIndex = 20;
            this.bt_consultar.Text = "Consultar Compra";
            this.bt_consultar.UseVisualStyleBackColor = false;
            this.bt_consultar.Click += new System.EventHandler(this.bt_consultar_Click);
            // 
            // tb_idcompra
            // 
            this.tb_idcompra.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tb_idcompra.Enabled = false;
            this.tb_idcompra.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_idcompra.Location = new System.Drawing.Point(540, 78);
            this.tb_idcompra.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tb_idcompra.Name = "tb_idcompra";
            this.tb_idcompra.Size = new System.Drawing.Size(379, 35);
            this.tb_idcompra.TabIndex = 21;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(366, 83);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(135, 29);
            this.label1.TabIndex = 22;
            this.label1.Text = "ID_Compra";
            // 
            // form_compras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1283, 690);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tb_idcompra);
            this.Controls.Add(this.bt_consultar);
            this.Controls.Add(this.bt_inserir);
            this.Controls.Add(this.bt_voltar);
            this.Controls.Add(this.bt_limpar);
            this.Controls.Add(this.nud_quant);
            this.Controls.Add(this.tb_idliv);
            this.Controls.Add(this.tb_idcli);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.ID_Cliente);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "form_compras";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_compras";
            this.Load += new System.EventHandler(this.form_compras_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_quant)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label ID_Cliente;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox tb_idcli;
        private System.Windows.Forms.TextBox tb_idliv;
        private System.Windows.Forms.NumericUpDown nud_quant;
        private System.Windows.Forms.Button bt_limpar;
        private System.Windows.Forms.Button bt_voltar;
        private System.Windows.Forms.Button bt_inserir;
        private System.Windows.Forms.Button bt_consultar;
        private System.Windows.Forms.TextBox tb_idcompra;
        private System.Windows.Forms.Label label1;
    }
}