﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_1
{
    internal class Program
    {
        static double SomarDoisValores(int y,int x)
        { return y + x; }
        static double DividirDoisValores(int y, int x)
        { return y / x; }
        static double SubtrairDoisValores(int y, int x)
        { return y - x; }
        static double MultiplicarDoisValores(int y, int x)
        { return y * x; }
        
        static void Main(string[] args)
        {
            int w, r, z;
            Console.WriteLine("Insira um valor");
            w = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira outro valor");
            z = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Escolha uma das seguintes operações: Soma(1) Divisão(2) Subtração(3) Multiplicação(4)");
            r = Convert.ToInt32(Console.ReadLine());
            switch (r)
            {   case 1:
                    Console.WriteLine(SomarDoisValores(w, z));
                    break;
                case 2:
                    if (z != 0)
                    {
                        Console.WriteLine(DividirDoisValores(w, z));
                    }
                    else { Console.WriteLine("O segundo valor não pode ser 0"); }
                    break;
                case 3:
                    Console.WriteLine(SubtrairDoisValores(w, z));
                    break;
                case 4:
                    Console.WriteLine(MultiplicarDoisValores(w, z));
                    break;
                default:
                    Console.WriteLine("Deve ser introduzido um dos valores acima");
                    break; }
            Console.ReadKey();
        }
    
    }
}
