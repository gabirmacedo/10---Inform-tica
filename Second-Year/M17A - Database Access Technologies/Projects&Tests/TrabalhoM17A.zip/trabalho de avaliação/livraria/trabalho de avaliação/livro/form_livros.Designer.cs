﻿namespace trabalho_de_avaliação
{
    partial class form_livros
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_livros));
            this.bt_voltar = new System.Windows.Forms.Button();
            this.bt_inserir = new System.Windows.Forms.Button();
            this.bt_consultar = new System.Windows.Forms.Button();
            this.bt_limpar = new System.Windows.Forms.Button();
            this.ID = new System.Windows.Forms.Label();
            this.tb_idliv = new System.Windows.Forms.TextBox();
            this.tb_titulo = new System.Windows.Forms.TextBox();
            this.tb_idade = new System.Windows.Forms.TextBox();
            this.tb_nomeautor = new System.Windows.Forms.TextBox();
            this.cb_categ = new System.Windows.Forms.ComboBox();
            this.cb_idioma = new System.Windows.Forms.ComboBox();
            this.dtp_lanc = new System.Windows.Forms.DateTimePicker();
            this.nud_preco = new System.Windows.Forms.NumericUpDown();
            this.Título = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.nud_preco)).BeginInit();
            this.SuspendLayout();
            // 
            // bt_voltar
            // 
            this.bt_voltar.BackColor = System.Drawing.Color.White;
            this.bt_voltar.FlatAppearance.BorderColor = System.Drawing.Color.Yellow;
            this.bt_voltar.FlatAppearance.BorderSize = 3;
            resources.ApplyResources(this.bt_voltar, "bt_voltar");
            this.bt_voltar.Name = "bt_voltar";
            this.bt_voltar.UseVisualStyleBackColor = false;
            this.bt_voltar.Click += new System.EventHandler(this.bt_voltar_Click);
            // 
            // bt_inserir
            // 
            this.bt_inserir.BackColor = System.Drawing.Color.White;
            this.bt_inserir.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.bt_inserir.FlatAppearance.BorderSize = 3;
            resources.ApplyResources(this.bt_inserir, "bt_inserir");
            this.bt_inserir.Name = "bt_inserir";
            this.bt_inserir.UseVisualStyleBackColor = false;
            this.bt_inserir.Click += new System.EventHandler(this.bt_inserir_Click_1);
            // 
            // bt_consultar
            // 
            this.bt_consultar.BackColor = System.Drawing.Color.White;
            this.bt_consultar.FlatAppearance.BorderColor = System.Drawing.Color.SkyBlue;
            this.bt_consultar.FlatAppearance.BorderSize = 3;
            resources.ApplyResources(this.bt_consultar, "bt_consultar");
            this.bt_consultar.Name = "bt_consultar";
            this.bt_consultar.UseVisualStyleBackColor = false;
            this.bt_consultar.Click += new System.EventHandler(this.bt_consultar_Click_1);
            // 
            // bt_limpar
            // 
            this.bt_limpar.BackColor = System.Drawing.Color.White;
            this.bt_limpar.FlatAppearance.BorderColor = System.Drawing.Color.YellowGreen;
            this.bt_limpar.FlatAppearance.BorderSize = 3;
            resources.ApplyResources(this.bt_limpar, "bt_limpar");
            this.bt_limpar.Name = "bt_limpar";
            this.bt_limpar.UseVisualStyleBackColor = false;
            this.bt_limpar.Click += new System.EventHandler(this.bt_limpar_Click_1);
            // 
            // ID
            // 
            resources.ApplyResources(this.ID, "ID");
            this.ID.BackColor = System.Drawing.Color.White;
            this.ID.Name = "ID";
            // 
            // tb_idliv
            // 
            this.tb_idliv.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.tb_idliv, "tb_idliv");
            this.tb_idliv.Name = "tb_idliv";
            // 
            // tb_titulo
            // 
            this.tb_titulo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.tb_titulo, "tb_titulo");
            this.tb_titulo.Name = "tb_titulo";
            // 
            // tb_idade
            // 
            this.tb_idade.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.tb_idade, "tb_idade");
            this.tb_idade.Name = "tb_idade";
            // 
            // tb_nomeautor
            // 
            this.tb_nomeautor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            resources.ApplyResources(this.tb_nomeautor, "tb_nomeautor");
            this.tb_nomeautor.Name = "tb_nomeautor";
            // 
            // cb_categ
            // 
            resources.ApplyResources(this.cb_categ, "cb_categ");
            this.cb_categ.FormattingEnabled = true;
            this.cb_categ.Items.AddRange(new object[] {
            resources.GetString("cb_categ.Items"),
            resources.GetString("cb_categ.Items1"),
            resources.GetString("cb_categ.Items2"),
            resources.GetString("cb_categ.Items3"),
            resources.GetString("cb_categ.Items4"),
            resources.GetString("cb_categ.Items5"),
            resources.GetString("cb_categ.Items6"),
            resources.GetString("cb_categ.Items7"),
            resources.GetString("cb_categ.Items8"),
            resources.GetString("cb_categ.Items9"),
            resources.GetString("cb_categ.Items10"),
            resources.GetString("cb_categ.Items11"),
            resources.GetString("cb_categ.Items12"),
            resources.GetString("cb_categ.Items13"),
            resources.GetString("cb_categ.Items14")});
            this.cb_categ.Name = "cb_categ";
            // 
            // cb_idioma
            // 
            resources.ApplyResources(this.cb_idioma, "cb_idioma");
            this.cb_idioma.FormattingEnabled = true;
            this.cb_idioma.Items.AddRange(new object[] {
            resources.GetString("cb_idioma.Items"),
            resources.GetString("cb_idioma.Items1"),
            resources.GetString("cb_idioma.Items2"),
            resources.GetString("cb_idioma.Items3"),
            resources.GetString("cb_idioma.Items4"),
            resources.GetString("cb_idioma.Items5"),
            resources.GetString("cb_idioma.Items6"),
            resources.GetString("cb_idioma.Items7"),
            resources.GetString("cb_idioma.Items8"),
            resources.GetString("cb_idioma.Items9"),
            resources.GetString("cb_idioma.Items10")});
            this.cb_idioma.Name = "cb_idioma";
            // 
            // dtp_lanc
            // 
            resources.ApplyResources(this.dtp_lanc, "dtp_lanc");
            this.dtp_lanc.Name = "dtp_lanc";
            // 
            // nud_preco
            // 
            resources.ApplyResources(this.nud_preco, "nud_preco");
            this.nud_preco.Name = "nud_preco";
            // 
            // Título
            // 
            resources.ApplyResources(this.Título, "Título");
            this.Título.BackColor = System.Drawing.Color.White;
            this.Título.Name = "Título";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.Name = "label3";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.Name = "label4";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.BackColor = System.Drawing.Color.White;
            this.label6.Name = "label6";
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.BackColor = System.Drawing.Color.White;
            this.label7.Name = "label7";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.BackColor = System.Drawing.Color.White;
            this.label8.Name = "label8";
            // 
            // form_livros
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.Título);
            this.Controls.Add(this.nud_preco);
            this.Controls.Add(this.dtp_lanc);
            this.Controls.Add(this.cb_idioma);
            this.Controls.Add(this.cb_categ);
            this.Controls.Add(this.tb_nomeautor);
            this.Controls.Add(this.tb_idade);
            this.Controls.Add(this.tb_titulo);
            this.Controls.Add(this.tb_idliv);
            this.Controls.Add(this.ID);
            this.Controls.Add(this.bt_limpar);
            this.Controls.Add(this.bt_consultar);
            this.Controls.Add(this.bt_inserir);
            this.Controls.Add(this.bt_voltar);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Name = "form_livros";
            this.Load += new System.EventHandler(this.form_livros_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_preco)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button bt_voltar;
        private System.Windows.Forms.Button bt_inserir;
        private System.Windows.Forms.Button bt_consultar;
        private System.Windows.Forms.Button bt_limpar;
        private System.Windows.Forms.Label ID;
        private System.Windows.Forms.TextBox tb_idliv;
        private System.Windows.Forms.TextBox tb_titulo;
        private System.Windows.Forms.TextBox tb_idade;
        private System.Windows.Forms.TextBox tb_nomeautor;
        private System.Windows.Forms.ComboBox cb_categ;
        private System.Windows.Forms.ComboBox cb_idioma;
        private System.Windows.Forms.DateTimePicker dtp_lanc;
        private System.Windows.Forms.NumericUpDown nud_preco;
        private System.Windows.Forms.Label Título;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
    }
}