﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace exercício_2
{
    class Program
    {
        
        struct Mensagem
        {
            public string Remetente;
            public string Assunto;
            public double horariodechegada;
            public string conteúdo;
        }
        static int Verificação (string verificar)
        {
            for (int i=0; i > verificar.Length;i++)
            {
                if (char.IsDigit(verificar[i]))
                {
                    Console.WriteLine("A resposta introduzida não pode ter valores númericos.."); 
                    return 1;
                }
            }
            return 0;
        }
        static void Main(string[] args)
        {
            int resp1;
            string resptxt;
            char resptxt1;
            string verificar;

            Stack<Mensagem> mensagens = new Stack<Mensagem>();
            Mensagem m;

            do
            {
                do
                {
                    Console.WriteLine("Olá, o que deseja fazer? " +
                        " Criar mensagem - 1 / Ler mensagem - 2 / Mostrar todas as mensagens - 3");
                    resptxt = Console.ReadLine();

                    if (int.TryParse(resptxt, out resp1) == false || resp1 < 1 || resp1 > 3)
                    {
                        Console.WriteLine("Deve ser introduzido um valor numérico");
                    }
                } while (int.TryParse(resptxt, out resp1) == false || resp1 < 1 || resp1 > 3);

                if (resp1 == 1)
                {
                    do
                    {
                        Console.WriteLine("Qual o nome do remetente?");
                        m.Remetente = Console.ReadLine();
                        verificar = m.Remetente;
                        Verificação(verificar);
                    } while (Verificação(verificar) == 1);
                    do 
                    { 
                        Console.WriteLine("Qual o assunto da mensagem?");
                        m.Assunto = Console.ReadLine();
                        verificar = m.Assunto;
                        Verificação(verificar);
                    } while (Verificação(verificar) == 1);
                    Console.WriteLine("Que horas foi enviada a mensagem?");
                    resptxt = Console.ReadLine();
                    if (double.TryParse(resptxt, out m.horariodechegada) == false)
                    {
                        Console.WriteLine("Deve ser introduzido um valor numérico");
                    }

                    do { 
                        Console.WriteLine("Qual o conteúdo da mensagem?");
                        m.conteúdo = Console.ReadLine();
                        verificar = m.conteúdo;
                        Verificação(verificar);
                    } while (Verificação(verificar) == 1);
                    mensagens.Push(m);
                }
                else if (resp1 == 2)
                {
                    if (mensagens.Count > 0)
                    {
                        m = mensagens.Pop();
                        Console.WriteLine("A mensagem com remetente " + m.Remetente + " assunto "+m.Assunto+" foi processada");
                    }
                    else
                    {
                        Console.WriteLine("Não existem mensagens para serem processadas");
                    }
                }
                else
                {
                    if (mensagens.Count > 0)
                    {
                        foreach (Mensagem msg in mensagens)
                        {
                            Console.WriteLine("As informações da mensagem são:");
                            Console.WriteLine("Remetente:" + msg.Remetente);
                            Console.WriteLine("Assunto:" + msg.Assunto);
                            Console.WriteLine("Horário:" + msg.horariodechegada);
                            Console.WriteLine("Conteúdo:" + msg.conteúdo);
                        }
                    }
                    else { Console.WriteLine("A pilha de mensagens está vazia"); }
                }

                do
                {
                    Console.WriteLine("Deseja continuar a consultar? S/N");
                    resptxt1 = Convert.ToChar(Console.ReadLine().ToUpper());
                    if (resptxt1 != 'N' && resptxt1 != 'S')
                    {
                        Console.WriteLine("A resposta introduzida deve ser apenas não ou sim");
                    }
                } while (resptxt1 != 'N' && resptxt1 != 'S');
            } while (resptxt1 == 'S');

            Console.ReadKey();

        }
    }
}
