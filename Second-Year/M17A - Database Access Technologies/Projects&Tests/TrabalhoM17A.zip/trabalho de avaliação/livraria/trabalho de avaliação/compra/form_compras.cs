﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using trabalho_de_avaliação.compra;
using trabalho_de_avaliação.livro;

namespace trabalho_de_avaliação
{
    public partial class form_compras : Form
    {
        public form_compras()
        {
            InitializeComponent();
        }
        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=livraria";
        struct Compra
        {
            public int idcompra;
            public int idcli;
            public int idliv;
            public int quant;
        }
        List<Compra> compras = new List<Compra>();
        Compra compra = new Compra();
        private void LimparCampos()
        {
            tb_idcompra.Text = "";
            tb_idcli.Text = "";
            tb_idliv.Text = "";
            nud_quant.Value = 0;
        }
        private void form_compras_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();
                Preencher();
                tb_idcompra.Text = (compras.Count() + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(form_clientes.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_limpar_Click(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void bt_voltar_Click(object sender, EventArgs e)
        {
            form_menu form_menu = new form_menu();
            form_menu.ShowDialog();
            this.Close();
        }

        private void bt_inserir_Click(object sender, EventArgs e)
        {
            if (tb_idliv.Text != "" && tb_idcli.Text != "" && tb_idcompra.Text != "" && nud_quant.Text != "")
            {

                compra.idcompra = Convert.ToInt32(tb_idliv.Text);
                compra.idcli = Convert.ToInt32(tb_idcli.Text);
                compra.idliv = Convert.ToInt32(tb_idliv.Text);
                compra.quant = Convert.ToInt32(nud_quant.Value);

                compras.Add(compra);

                string sql = "insert into livraria.compra values(@idcompra, @idcliente, @idlivro, @quantidade)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {   
                    cmd.Parameters.AddWithValue("@idcompra", null);
                    cmd.Parameters.AddWithValue("@idcliente", compra.idcli);
                    cmd.Parameters.AddWithValue("@idlivro", compra.idliv);
                    cmd.Parameters.AddWithValue("@quantidade", compra.quant);

                    cmd.ExecuteNonQuery();
                }
                // UPDATE no cliente (+1 compra)
                string sqlUpdate = "Update cliente Set ncompras = ncompras + 1 Where idcliente = @idcliente;";
                using (MySqlCommand cmd2 = new MySqlCommand(sqlUpdate, conexao))
                {
                    cmd2.Parameters.AddWithValue("@idcliente", compra.idcli);
                    cmd2.ExecuteNonQuery();
                }
                LimparCampos();


            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }

            tb_idcompra.Text = (compras.Count() + 1).ToString();
        }

        private void bt_consultar_Click(object sender, EventArgs e)
        {
            form_listacompras listagem = new form_listacompras();
            foreach (Compra a in compras)
            {
                listagem.lista_compras.Rows.Add(
                a.idcompra, a.idcli, a.idliv, a.quant);
            }
            listagem.Show();
        }
        private void Preencher()
        {
            string sql = "select * from compra";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        compra.idcompra = reader.GetInt32("idcompra");
                        compra.idcli = reader.GetInt32("idcliente");
                        compra.quant = reader.GetInt32("quantidade");
                        compra.idliv = reader.GetInt32("idlivro");

                        compras.Add(compra);
                    }
                }
            }
        }
    }
}
