﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício4B
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int mes;
            Console.WriteLine("Introduza o valor de um dos meses do ano");
            mes = Convert.ToInt32(Console.ReadLine());
            switch (mes)
            {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                   Console.WriteLine("Esse mês tem 31 dias");
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    Console.WriteLine("Esse mês tem 30 dias");
                    break;
                case 2:
                    Console.WriteLine("Esse mês tem 28/29 dias");
                    break;
                default:
                    Console.WriteLine("O mês deve ser de 1 a 12.");
                    break;
            }
            Console.ReadKey();



        }
    }
}
