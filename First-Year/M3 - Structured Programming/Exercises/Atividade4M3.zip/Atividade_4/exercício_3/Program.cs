﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercício_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double val, media=0,cont=0;
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Insira um valor");
                val = Convert.ToDouble(Console.ReadLine());
                if (val >= 0)
                {
                    media = media + val;
                    cont = cont + 1;
                }
            }
            Console.WriteLine("A media de todos os valores é " + media/cont);
            Console.ReadKey();
        }
    }
}
