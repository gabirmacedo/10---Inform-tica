﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_1
{
    internal class Program
    {
        struct Artigos
        {
            public double Preço;
            public int Quant;
        }
       
            static void Main(string[] args)
            {
                double média;
                Artigos art1, art2, art3;

                Console.WriteLine("Preço do artigo 1:");
                art1.Preço = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Quantidade do artigo 1:");
                art1.Quant = Convert.ToInt32(Console.ReadLine());
                média = art1.Preço * art1.Quant;
                Console.WriteLine("Preço do artigo 2:");
                art2.Preço = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Quantidade do artigo 2:");
                art2.Quant = Convert.ToInt32(Console.ReadLine());
                média = média + art1.Preço * art1.Quant;
                Console.WriteLine("Preço do artigo 3:");
                art3.Preço = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Quantidade do artigo 3:");
                art3.Quant = Convert.ToInt32(Console.ReadLine());
                média = (média + art1.Preço * art1.Quant) / 3;

                Console.WriteLine("Valor total do artigo 1 = " + (art1.Preço * art1.Quant));

                Console.WriteLine("A média dos 3 artigos é = " + (média));

                Console.ReadKey();
            }
        
    }
}
