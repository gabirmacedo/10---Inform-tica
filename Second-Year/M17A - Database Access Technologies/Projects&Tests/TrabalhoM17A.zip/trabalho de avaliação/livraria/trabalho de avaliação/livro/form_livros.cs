﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using trabalho_de_avaliação.cliente;
using trabalho_de_avaliação.livro;

namespace trabalho_de_avaliação
{
    public partial class form_livros : Form
    {
        MySqlConnection conexao;
        const string infconexao = "datasource=localhost;port=3306;username=root;password=mysql;database=livraria";
        struct Livro
        {
            public int idlivro;
            public string titulo;
            public string categoria;
            public int faixaetaria;
            public string nome_autor;
            public DateTime lancamento;
            public string idioma;
            public double preco;
        }
        List<Livro> livros = new List<Livro>();
        Livro livro = new Livro();
        private void LimparCampos()
        {
            tb_titulo.Text = "";
            cb_categ.Text = "";
            tb_idade.Text = "";
            tb_nomeautor.Text = "";
            cb_idioma.Text = "";
            nud_preco.Value = 0;
        }
        private void Preencher()
        {
            string sql = "select * from livro";
            using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
            {
                using (MySqlDataReader reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        livro.idlivro = reader.GetInt32("idlivro");
                        livro.titulo = reader.GetString("nomelivro");
                        livro.categoria = reader.GetString("categoria");
                        livro.faixaetaria = reader.GetInt32("idademin");
                        livro.nome_autor = reader.GetString("autor");
                        livro.lancamento = reader.GetDateTime("datalanc");
                        livro.idioma = reader.GetString("idioma");
                        livro.preco = reader.GetInt32("preco");

                        livros.Add(livro);
                    }
                }
            }
        }

        public form_livros()
        {
            InitializeComponent();
        }

        private void form_livros_Load(object sender, EventArgs e)
        {
            try
            {
                conexao = new MySqlConnection(infconexao);
                conexao.Open();
                Preencher();
                tb_idliv.Text = (livros.Count() + 1).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(form_clientes.ActiveForm, ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void bt_limpar_Click_1(object sender, EventArgs e)
        {
            LimparCampos();
        }

        private void bt_inserir_Click_1(object sender, EventArgs e)
        {
            if (tb_idliv.Text != "" && tb_titulo.Text != "" && cb_categ.Text != "" && tb_idade.Text != "" && tb_nomeautor.Text != "" && cb_idioma.Text != "" && nud_preco.Value != 0)
            {

                livro.idlivro = Convert.ToInt32(tb_idliv.Text);
                livro.titulo = tb_titulo.Text;
                livro.categoria = cb_categ.Text;
                livro.faixaetaria = Convert.ToInt32(tb_idade.Text);
                livro.nome_autor = tb_nomeautor.Text;
                livro.lancamento = Convert.ToDateTime(dtp_lanc.Text);
                livro.idioma = cb_idioma.Text;
                livro.preco = Convert.ToInt32(nud_preco.Text);

                livros.Add(livro);

                string sql = "insert into livraria.livro values(@idlivro,@nomelivro,@categoria,@idademin,@autor,@datalanc,@idioma,@preco)";
                using (MySqlCommand cmd = new MySqlCommand(sql, conexao))
                {
                    cmd.Parameters.AddWithValue("@idlivro", null);
                    cmd.Parameters.AddWithValue("@nomelivro", livro.nome_autor);
                    cmd.Parameters.AddWithValue("@categoria", livro.categoria);
                    cmd.Parameters.AddWithValue("@idademin", livro.faixaetaria);
                    cmd.Parameters.AddWithValue("@autor", livro.nome_autor);
                    cmd.Parameters.AddWithValue("@datalanc", livro.lancamento);
                    cmd.Parameters.AddWithValue("@idioma", livro.idioma);
                    cmd.Parameters.AddWithValue("@preco", livro.preco);

                    cmd.ExecuteNonQuery();
                }

                LimparCampos();
            }
            else
            {
                MessageBox.Show("Todos os campos devem ser preenchidos");
            }

            tb_idliv.Text = (livros.Count() + 1).ToString();
        }

        private void bt_consultar_Click_1(object sender, EventArgs e)
        {
            form_listaliv listagem = new form_listaliv();
            foreach (Livro a in livros)
            {
                listagem.listalivros.Rows.Add(
                a.idlivro, a.titulo, a.categoria, a.faixaetaria, a.nome_autor, a.lancamento,a.idioma,a.preco);
            }
            listagem.Show();
        }

        private void bt_voltar_Click(object sender, EventArgs e)
        {
            form_menu form_menu = new form_menu();
            form_menu.ShowDialog();
            this.Close();
        }
    }
}
