﻿namespace trabalho_de_avaliação.cliente
{
    partial class form_listcli
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_listcli));
            this.listagem_cli = new System.Windows.Forms.DataGridView();
            this.idcliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nomecliente = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nif = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ncompras = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.morada = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.email = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.listagem_cli)).BeginInit();
            this.SuspendLayout();
            // 
            // listagem_cli
            // 
            this.listagem_cli.AllowUserToAddRows = false;
            this.listagem_cli.AllowUserToDeleteRows = false;
            this.listagem_cli.AllowUserToResizeColumns = false;
            this.listagem_cli.BackgroundColor = System.Drawing.Color.White;
            this.listagem_cli.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.listagem_cli.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.listagem_cli.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.idcliente,
            this.nomecliente,
            this.nif,
            this.ncompras,
            this.morada,
            this.email});
            this.listagem_cli.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listagem_cli.Location = new System.Drawing.Point(0, 0);
            this.listagem_cli.Name = "listagem_cli";
            this.listagem_cli.RowHeadersVisible = false;
            this.listagem_cli.RowHeadersWidth = 62;
            this.listagem_cli.RowTemplate.Height = 28;
            this.listagem_cli.Size = new System.Drawing.Size(2189, 1297);
            this.listagem_cli.TabIndex = 0;
            // 
            // idcliente
            // 
            this.idcliente.HeaderText = "ID";
            this.idcliente.MinimumWidth = 8;
            this.idcliente.Name = "idcliente";
            this.idcliente.Width = 150;
            // 
            // nomecliente
            // 
            this.nomecliente.HeaderText = "Nome";
            this.nomecliente.MinimumWidth = 8;
            this.nomecliente.Name = "nomecliente";
            this.nomecliente.Width = 150;
            // 
            // nif
            // 
            this.nif.HeaderText = "NIF";
            this.nif.MinimumWidth = 8;
            this.nif.Name = "nif";
            this.nif.Width = 150;
            // 
            // ncompras
            // 
            this.ncompras.HeaderText = "Nº Compras";
            this.ncompras.MinimumWidth = 8;
            this.ncompras.Name = "ncompras";
            this.ncompras.Width = 150;
            // 
            // morada
            // 
            this.morada.HeaderText = "Morada";
            this.morada.MinimumWidth = 8;
            this.morada.Name = "morada";
            this.morada.Width = 150;
            // 
            // email
            // 
            this.email.HeaderText = "E-mail";
            this.email.MinimumWidth = 8;
            this.email.Name = "email";
            this.email.Width = 150;
            // 
            // form_listcli
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2189, 1297);
            this.Controls.Add(this.listagem_cli);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "form_listcli";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "form_listcli";
            this.Load += new System.EventHandler(this.form_listcli_Load);
            ((System.ComponentModel.ISupportInitialize)(this.listagem_cli)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        public System.Windows.Forms.DataGridView listagem_cli;
        private System.Windows.Forms.DataGridViewTextBoxColumn idcliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn nomecliente;
        private System.Windows.Forms.DataGridViewTextBoxColumn nif;
        private System.Windows.Forms.DataGridViewTextBoxColumn ncompras;
        private System.Windows.Forms.DataGridViewTextBoxColumn morada;
        private System.Windows.Forms.DataGridViewTextBoxColumn email;
    }
}