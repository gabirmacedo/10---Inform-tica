﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_7
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int soma = 0;
                for (int i=0; i <= 100; i ++)
            {
                soma = soma + i;
            }
                Console.WriteLine("A soma de todos os números de 0 até 100 é " + soma);
            Console.ReadKey();
        }
    }
}
