﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_3
{
    internal class Program
    {
        
            struct Computador
        {
            public string marca;
            public string processador;
            public double velocidade;
            public double tamanho;
            public double preço;
        }
        static void Main(string[] args)
        {
            Computador[] outros = new Computador[6];

            double soma1 = 0, soma2 = 0;

            for (int i = 0; i < outros.Length; i++)
            {

                Console.WriteLine("Insira a marca do " + (i + 1) + " computador");
                outros[i].marca = Console.ReadLine();
                Console.WriteLine("Insira o processador do " + (i + 1) + " primeiro computador");
                outros[i].processador = Console.ReadLine();
                Console.WriteLine("Insira a velocidade do " + (i + 1) + " computador");
                outros[i].velocidade = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Insira a quantidade de ram do " + (i + 1) + " computador");
                outros[i].tamanho = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Insira o preço do " + (i + 1) + " computador");
                outros[i].preço = Convert.ToDouble(Console.ReadLine());
            }

            for (int i = 0; i < outros.Length; i++)
            {
                Console.WriteLine(outros[i].marca);
                Console.WriteLine(outros[i].processador);
                Console.WriteLine(outros[i].velocidade);
                Console.WriteLine(outros[i].tamanho);
                Console.WriteLine(outros[i].preço);
                soma1 = soma1 + outros[i].velocidade;
                soma2 = soma2 + outros[i].preço;
            }
            Console.WriteLine("A média da velocidade é " + soma1/6);
            Console.WriteLine("A média o preço é " + soma2/6);

            Console.ReadKey();
        }
    }
}
