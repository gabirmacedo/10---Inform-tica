﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_3
{
    internal class Program
    {
        static string LerPalavra(string p)
        {

            Console.WriteLine("Introduza uma palavra: ");
            p =Console.ReadLine();

            return p;
        }
        static int ContarVogais(string p)
        {   
            int cont = 0;
            p.ToUpper();
            char[] c = p.ToCharArray();
            for (int i = 0; i < c.Length; i++)
            {
                
                if (c[i] == 'A' || c[i] == 'E' || c[i] == 'I' || c[i] == 'O' || c[i] == 'U')
                {
                    cont++;
                }

            }
            return cont;
        }
        static void Main(string[] args)
        {
            string p;

            //Alterar o código de modo a diminuir ele (Exercício 3: a)
            Console.WriteLine("Introduza uma palavra: ");
            p = Console.ReadLine().ToUpper();

            int cont = 0;

            for (int i = 0; i < p.Length; i++)
            {
                if (p[i] == 'A' || p[i] == 'E' || p[i] == 'I' || p[i] == 'O' || p[i] == 'U') 
                    cont++; 
            }
            Console.WriteLine("A palavra tem " + cont + " vogais.");


            //Criar uma nova versão do programa utilizando o método pedir e ler. (Exercício 3: b)
            LerPalavra(p);
            Console.WriteLine($"A palavra tem {ContarVogais(p)} vogais.");

            Console.ReadKey();
        }
    }
}
