﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício8
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const double din =50, pen=7.13;
            double quan;
            Console.WriteLine("Qual a quantidade que pretendes comprar?");
            quan = Convert.ToDouble(Console.ReadLine());
            if (din - (quan * pen) <0)
            {
                Console.WriteLine("O dinheiro não é o suficiente para comprar essa quantidade. Faltam: " + ((quan * pen) - din) + "€");
            }
            else
            { 
                Console.WriteLine("O dinheiro é suficiente para comprar essa quantidade, troco: " + Math.Round((din - (quan * pen))) + "€"); 
            }
            Console.ReadKey();
        }
    }
}
