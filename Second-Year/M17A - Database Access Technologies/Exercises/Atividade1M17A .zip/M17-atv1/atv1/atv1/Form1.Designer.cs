﻿namespace atv1
{
    partial class Form_menu
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.bt_cliente = new System.Windows.Forms.Button();
            this.bt_produto = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // bt_cliente
            // 
            this.bt_cliente.Location = new System.Drawing.Point(230, 115);
            this.bt_cliente.Name = "bt_cliente";
            this.bt_cliente.Size = new System.Drawing.Size(329, 52);
            this.bt_cliente.TabIndex = 0;
            this.bt_cliente.Text = "Criar Cliente";
            this.bt_cliente.UseVisualStyleBackColor = true;
            this.bt_cliente.Click += new System.EventHandler(this.bt_cliente_Click);
            // 
            // bt_produto
            // 
            this.bt_produto.Location = new System.Drawing.Point(230, 196);
            this.bt_produto.Name = "bt_produto";
            this.bt_produto.Size = new System.Drawing.Size(329, 52);
            this.bt_produto.TabIndex = 1;
            this.bt_produto.Text = "Criar Produto";
            this.bt_produto.UseVisualStyleBackColor = true;
            this.bt_produto.Click += new System.EventHandler(this.bt_produto_Click);
            // 
            // Form_menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.bt_produto);
            this.Controls.Add(this.bt_cliente);
            this.Name = "Form_menu";
            this.Text = "Menu";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button bt_cliente;
        private System.Windows.Forms.Button bt_produto;
    }
}

