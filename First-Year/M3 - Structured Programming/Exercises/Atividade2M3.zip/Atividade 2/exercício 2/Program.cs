﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Double sal;
                Console.WriteLine("Introduza seu salário para calcularmos a porcentagem de imposto e quando deve pagar.");
            sal = Convert.ToDouble(Console.ReadLine());
            if (sal > 1000)
            { Console.WriteLine("O imposto é de 10% e você deve pagar " + sal * 0.10 + " euros"); }
            else if (sal < 0 ) { Console.WriteLine("O valor introduzido deve ser de 0 ou superior"); }
            else { Console.WriteLine("O imposto é de 5% e você deve pagar " + sal * 0.05 + " euros"); }
            Console.ReadKey();
        }
    }
}
