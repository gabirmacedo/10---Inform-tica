﻿namespace Atividade_2
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.cbo_num = new System.Windows.Forms.ComboBox();
            this.lst_Tabuada = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // cbo_num
            // 
            this.cbo_num.FormattingEnabled = true;
            this.cbo_num.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
            "7",
            "8",
            "9",
            "10"});
            this.cbo_num.Location = new System.Drawing.Point(312, 47);
            this.cbo_num.Name = "cbo_num";
            this.cbo_num.Size = new System.Drawing.Size(204, 28);
            this.cbo_num.TabIndex = 0;
            this.cbo_num.SelectedIndexChanged += new System.EventHandler(this.cbo_num_SelectedIndexChanged);
            // 
            // lst_Tabuada
            // 
            this.lst_Tabuada.FormattingEnabled = true;
            this.lst_Tabuada.ItemHeight = 20;
            this.lst_Tabuada.Location = new System.Drawing.Point(312, 81);
            this.lst_Tabuada.Name = "lst_Tabuada";
            this.lst_Tabuada.Size = new System.Drawing.Size(204, 324);
            this.lst_Tabuada.TabIndex = 1;
            this.lst_Tabuada.SelectedIndexChanged += new System.EventHandler(this.lst_Tabuada_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lst_Tabuada);
            this.Controls.Add(this.cbo_num);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox cbo_num;
        private System.Windows.Forms.ListBox lst_Tabuada;
    }
}

