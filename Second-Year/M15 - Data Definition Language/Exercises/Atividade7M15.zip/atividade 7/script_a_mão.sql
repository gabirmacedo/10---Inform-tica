create database adicao;

create table autor(
idautor int auto_increment Primary Key,
nomeautor varchar(75) NOT NULL);

create table suporte(
idsuporte int auto_increment Primary Key,
nomesuporte varchar(75) NOT NULL,
tiposuporte varchar(10) NOT NULL);

create table estilo(
idestilo int auto_increment Primary Key,
nomeestilo varchar(50)NOT NULL);

create table obra(
numobra int auto_increment Primary Key,
titulo varchar(75)NOT NULL, 
ano varchar(4)NOT NULL, 
idautor int references autor(idautor),
idestilo int references estilo(idestilo),
idsuporte int references suporte(idsuporte),
comentario varchar(100));