﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2
{
    internal class Program
    {
        struct Cidade
        {
            public double Tempmax;
            public double Tempmin;
        }
        static void Main(string[] args)
        {
            Cidade[] cidades = new Cidade[4];
            double soma1 = 0, soma2 = 0, maior1, maior2;

            for (int i = 0; i < cidades.Length; i++)
            {
                Console.WriteLine("Insira a temperatura máxima da " + (i + 1) + "º cidade");
                cidades[i].Tempmax = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("Insira a temperatura mínima da " + (i + 1) + "º cidade");
                cidades[i].Tempmin = Convert.ToDouble(Console.ReadLine());
                soma1 = soma1 + cidades[i].Tempmax;
                soma2 = soma2 + cidades[i].Tempmin;
            }
            maior1 = cidades[1].Tempmax;
            maior2 = cidades[1].Tempmin;
            for (int j = 2; j < cidades.Length; j++)
            {
                maior1 = Math.Max(cidades[j].Tempmax, maior1);
                maior2 = Math.Min(cidades[j].Tempmin, maior2);
            }

            Console.WriteLine("A média da temperatura máxima é: " + soma1 / 4);
            Console.WriteLine("A média da temperatura mínima é: " + soma2 / 4);
            Console.WriteLine("A maior Temperatura Máxima é: " + maior1);
            Console.WriteLine("A menor Temperatura Mínima é: " + maior2);

            Console.ReadKey();
        }
    }
}
