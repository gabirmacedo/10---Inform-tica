﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_9
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int val,soma=0;
            do
            {
                Console.WriteLine("Introduza um valor");
                val = Convert.ToInt32(Console.ReadLine());
                if (val % 7 == 0)
                {
                    soma = soma + val;
                }
                Console.WriteLine("Por enquanto, a soma é "+ soma);
            }
            while (val <= 100 || val >= 200);
            Console.ReadLine();
        }
    }
}
