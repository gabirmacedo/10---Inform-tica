﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_4
{
    internal class Program
    {
        struct Informações
        {
            public string nome;
            public int nota;
        }
        static void Main(string[] args)
        {
            Informações[] vezes = new Informações[5];

            int soma = 0;
                Console.WriteLine("Insira o nome do aluno");
                vezes[1].nome = Console.ReadLine();
                for (int i = 0; i < vezes.Length; i++)
                {
                    Console.WriteLine("Insira a nota da " + (i + 1) + "º disciplina");
                    vezes[i].nota = Convert.ToInt32(Console.ReadLine());
                soma = soma + vezes[i].nota;
                }
            int resp;
            do
            {
                Console.WriteLine("Oque deseja consultar?");
                resp = Convert.ToInt32(Console.ReadLine());
                if (resp == 1)
                {
                    Console.WriteLine("Deseja consultar a nota de qual disciplina");
                    do
                    {
                        resp = Convert.ToInt32(Console.ReadLine());
                        if (resp > 5 || resp > 1)
                        {
                            Console.WriteLine("Deve ser introduzido um valor de 1 a 5");
                        }
                        else
                        {
                            Console.WriteLine(vezes[resp].nota);
                            Console.WriteLine(vezes[1].nome);
                        }
                    } while (resp > 5 || resp > 1);
                }
                else if (resp == 2)
                {
                    Console.WriteLine("A soma das notas do aluno são " + soma / 5);
                }
                Console.WriteLine("Deseja consultar outra coisa? 1-Sim/2-Não");
                resp = Convert.ToInt32(Console.ReadLine());
                if (resp != 2 || resp != 1 )
                { Console.WriteLine("Deve ser introduzido apenas 1 ou 2"); }
            } while (resp == 1);

                

                Console.ReadKey();
            
        }
    }
}
