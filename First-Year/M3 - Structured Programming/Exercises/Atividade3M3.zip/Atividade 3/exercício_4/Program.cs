﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;

namespace exercício_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double nt, ntx=0, cont=0;
            Console.WriteLine("Introduza um valor");
            do
            {
                nt = Convert.ToDouble(Console.ReadLine()); 
                ntx = Convert.ToDouble(+nt);
                cont = cont + 1;
                if (cont > 1) 
                { 
                    Console.WriteLine("A média é: " + (ntx / cont)); 
                }
                else { Console.WriteLine("Deve ser introduzido um valor positivo."); }
                Console.WriteLine("Introduza outro valor");
            }
            while (nt >= 0);
            Console.ReadKey();
        }
    }
}
