﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercícioo_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] notas = new double[3,4];

            for (int i=0; i < notas.GetLength(0); i++)
            {
                for (int j=0; j < notas.GetLength(1); j++)
                {
                    Console.WriteLine("Insira a nota da " + (j + 1) + "º matéria do " + (i + 1) + "º aluno");
                    notas[i, j] = Convert.ToDouble(Console.ReadLine());
                }
            }

            for (int i = 0; i < notas.GetLength(0); i++)
            {
                double soma = 0;
                for (int j = 0; j < notas.GetLength(1); j++)
                {
                    soma = soma + notas[i, j];
                    
                }
                Console.WriteLine("A média do " + (i + 1) + "º aluno é " + (soma / 4));
            }
            
            Console.ReadKey();

        }
    }
}
