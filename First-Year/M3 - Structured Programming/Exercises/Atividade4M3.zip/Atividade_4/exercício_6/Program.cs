﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double n, ultimo=0, soma=0;
            do
            {
                Console.WriteLine("Introduza um número");
                n = Convert.ToDouble(Console.ReadLine());
                if (n != ultimo && n >0)
                {
                    soma = soma + n;
                }
                ultimo = n;

            } while (n >=0 );
            Console.WriteLine("A soma final é de " + soma);
            Console.ReadKey();


        }
    }
}
