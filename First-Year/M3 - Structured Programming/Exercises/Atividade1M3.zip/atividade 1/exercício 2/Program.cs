﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int resp, resultado;
            Console.WriteLine("Introduza um número");
            resp = Convert.ToInt32(Console.ReadLine());
            resultado = Convert.ToInt32(resp + 1);
            Console.WriteLine("O número a seguir a esse é " + resultado);
            Console.ReadKey();
        }
    }
}
