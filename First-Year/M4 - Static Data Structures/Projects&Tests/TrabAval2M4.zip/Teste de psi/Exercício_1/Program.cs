﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercíciio_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[] temperaturaverao= new double[6];
            double[] temperaturainverno= new double[6];
            

            for (int i = 0; i > 7; i++)
            {
                double soma = 0;
                Console.WriteLine("Insira as temperaturas do verão. ");
                temperaturaverao[6] = Convert.ToDouble(Console.ReadLine());
                soma = soma + temperaturaverao[i];
                Console.WriteLine("A média das temperaturas no inverno e no verão é:" + soma / 6);
            }
            for (int i = 0; i > 7; i++)
            {
                double soma = 0;
                Console.WriteLine("Insira as temperaturas inverno.");
                temperaturainverno[6] = Convert.ToDouble(Console.ReadLine());
                soma = soma + temperaturainverno[i];
                Console.WriteLine("A média das temperaturas no inverno e no verão é:" + soma / 6);
            }
            
            Console.WriteLine("A amplitude das cidades é:");
            for (int i = 0;i > 7; i++)
            {
                double amplitude = 0;
                amplitude = temperaturaverao[i] - temperaturainverno[i];
            }
            Console.ReadKey();
            
        }
    }
}
