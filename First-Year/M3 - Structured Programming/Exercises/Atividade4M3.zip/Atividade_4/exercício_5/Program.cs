﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Char turma;
            int resp;
            do
            {
                Console.WriteLine("Qual a letra da turma");
                turma = Convert.ToChar(Console.ReadLine().ToUpper());
                switch (turma)
                {
                    case 'A':
                    case 'C':
                        { Console.WriteLine("Curso de Humanidades"); }
                        break;
                    case 'D':
                    case 'F':
                        { Console.WriteLine("Curso de Economia"); }
                        break;
                    case 'G':
                    case 'I':
                        { Console.WriteLine("Curso de Informática"); }
                        break;
                    case 'J':
                    case 'M':
                        { Console.WriteLine("Curso de Contabilidade"); }
                        break;
                    default:
                        { Console.WriteLine("Esta letra não corresponde a uma turma"); }
                        break;
                }
                Console.WriteLine("Deseja continuar? sim(1) não(2)");
                resp = Convert.ToInt32(Console.ReadLine());
            } while (resp == 1);
            Console.ReadKey();
        }
    }
}
