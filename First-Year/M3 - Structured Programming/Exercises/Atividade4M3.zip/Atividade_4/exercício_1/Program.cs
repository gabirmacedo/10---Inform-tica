﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double sal;
            Console.WriteLine("Insira seu salário para calcularmos sua porcentagem de imposto e o total");
            sal = Convert.ToDouble(Console.ReadLine());
                while (sal < 0)
                {
                Console.WriteLine("Introduza um valor válido");
                sal = Convert.ToDouble(Console.ReadLine());
                }
            if (sal > 1000)
            { 
            Console.WriteLine("Seu imposto é de 10% e fica num total de " + sal*0.10);
            }
            else
            {
            Console.WriteLine("Seu imposto é de 5% e fica num total de " + sal * 0.05);
            }
            Console.ReadKey();
        }
    }
}
