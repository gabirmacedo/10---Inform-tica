﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double x, y, media;
            Console.WriteLine("Introduza um valor");
            x = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Introduza outro valor");
            y = Convert.ToDouble(Console.ReadLine());
            media = Convert.ToDouble((x + y) / 2);
            Console.WriteLine("A média do seus valores é " + media);
            Console.WriteLine("A raiz quadrada do prmeiro número é " +Math.Sqrt(x) + " e seu quadrado é " + (x * x));
            Console.WriteLine("A raiz do segundo número é " + Math.Sqrt(y) + " e seu quadrado é " + (y * y));
            Console.ReadKey();
        }
    }
}
