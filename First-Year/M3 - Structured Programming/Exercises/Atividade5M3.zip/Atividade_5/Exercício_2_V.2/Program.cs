﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercício_2_V._2
{
    internal class Program
    {
        static void IntroduzirTresNumeros(ref double a, ref double b, ref double c)
        {
            Console.WriteLine("Introduza um número");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza outro número");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza outro número");
            c = Convert.ToInt32(Console.ReadLine());

        }
        static double Maior(double x, double y, double z)
        {
            return Math.Max(Math.Max(x, y), z);
        }
        static void Main(string[] args)
        {
            char resp;
            do
            {
                Console.WriteLine("Calcule o maior dos tres valores");
                double a = 0, b = 0, c = 0;
                IntroduzirTresNumeros(ref a, ref b, ref c);
                Console.WriteLine(Maior(a, b, c));
                Console.Write(" é o maior dos Três");
                do
                {
                    Console.WriteLine("Deseja continuar? (S/N)");
                    resp = Convert.ToChar(Console.ReadLine().ToUpper());
                    if (resp != 'S' || resp != 'N')
                    {
                        Console.WriteLine("Deve ser introduzido S ou N");
                    }
                } while (resp != 'S' || resp != 'N');
            } while (resp == 'S' || resp == 'N');
            Console.ReadKey();



        }
    }
}
