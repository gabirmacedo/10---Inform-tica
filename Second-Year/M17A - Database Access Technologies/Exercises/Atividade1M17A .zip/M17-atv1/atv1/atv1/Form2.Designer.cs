﻿namespace atv1
{
    partial class Form_produto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tb_nomeprod = new System.Windows.Forms.TextBox();
            this.cb_tipoprod = new System.Windows.Forms.ComboBox();
            this.nud_quantstock = new System.Windows.Forms.NumericUpDown();
            this.nud_preco = new System.Windows.Forms.NumericUpDown();
            this.bt_inserirprod = new System.Windows.Forms.Button();
            this.bt_limpar = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_idproduto = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.nud_quantstock)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_preco)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(233, 88);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Desinação";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(279, 133);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(39, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Tipo";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(234, 180);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(84, 20);
            this.label3.TabIndex = 2;
            this.label3.Text = "Preço unid";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(155, 226);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(163, 20);
            this.label4.TabIndex = 3;
            this.label4.Text = "Quantidade em Stock";
            // 
            // tb_nomeprod
            // 
            this.tb_nomeprod.Location = new System.Drawing.Point(346, 81);
            this.tb_nomeprod.Name = "tb_nomeprod";
            this.tb_nomeprod.Size = new System.Drawing.Size(232, 26);
            this.tb_nomeprod.TabIndex = 4;
            // 
            // cb_tipoprod
            // 
            this.cb_tipoprod.FormattingEnabled = true;
            this.cb_tipoprod.Location = new System.Drawing.Point(346, 133);
            this.cb_tipoprod.Name = "cb_tipoprod";
            this.cb_tipoprod.Size = new System.Drawing.Size(232, 28);
            this.cb_tipoprod.TabIndex = 5;
            // 
            // nud_quantstock
            // 
            this.nud_quantstock.Location = new System.Drawing.Point(346, 220);
            this.nud_quantstock.Name = "nud_quantstock";
            this.nud_quantstock.Size = new System.Drawing.Size(232, 26);
            this.nud_quantstock.TabIndex = 6;
            // 
            // nud_preco
            // 
            this.nud_preco.Location = new System.Drawing.Point(346, 178);
            this.nud_preco.Name = "nud_preco";
            this.nud_preco.Size = new System.Drawing.Size(232, 26);
            this.nud_preco.TabIndex = 7;
            // 
            // bt_inserirprod
            // 
            this.bt_inserirprod.Location = new System.Drawing.Point(199, 295);
            this.bt_inserirprod.Name = "bt_inserirprod";
            this.bt_inserirprod.Size = new System.Drawing.Size(176, 38);
            this.bt_inserirprod.TabIndex = 8;
            this.bt_inserirprod.Text = "Inserir";
            this.bt_inserirprod.UseVisualStyleBackColor = true;
            this.bt_inserirprod.Click += new System.EventHandler(this.bt_inserirprod_Click);
            // 
            // bt_limpar
            // 
            this.bt_limpar.Location = new System.Drawing.Point(402, 295);
            this.bt_limpar.Name = "bt_limpar";
            this.bt_limpar.Size = new System.Drawing.Size(176, 38);
            this.bt_limpar.TabIndex = 9;
            this.bt_limpar.Text = "Limpar";
            this.bt_limpar.UseVisualStyleBackColor = true;
            this.bt_limpar.Click += new System.EventHandler(this.bt_limpar_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(292, 36);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Nº";
            // 
            // tb_idproduto
            // 
            this.tb_idproduto.Enabled = false;
            this.tb_idproduto.Location = new System.Drawing.Point(346, 29);
            this.tb_idproduto.Name = "tb_idproduto";
            this.tb_idproduto.Size = new System.Drawing.Size(52, 26);
            this.tb_idproduto.TabIndex = 11;
            // 
            // Form_produto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.tb_idproduto);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.bt_limpar);
            this.Controls.Add(this.bt_inserirprod);
            this.Controls.Add(this.nud_preco);
            this.Controls.Add(this.nud_quantstock);
            this.Controls.Add(this.cb_tipoprod);
            this.Controls.Add(this.tb_nomeprod);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form_produto";
            this.Text = "Criar Produto";
            this.Load += new System.EventHandler(this.Form_produto_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nud_quantstock)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nud_preco)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tb_nomeprod;
        private System.Windows.Forms.ComboBox cb_tipoprod;
        private System.Windows.Forms.NumericUpDown nud_quantstock;
        private System.Windows.Forms.NumericUpDown nud_preco;
        private System.Windows.Forms.Button bt_inserirprod;
        private System.Windows.Forms.Button bt_limpar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_idproduto;
    }
}