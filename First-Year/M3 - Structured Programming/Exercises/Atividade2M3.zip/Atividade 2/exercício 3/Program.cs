﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace exercício_3
{
    internal class Program
    {
        static void Main(string[] args, int somap)
        {
            int a, b, c, d, somap, soman;
            Console.WriteLine("Insira um valor");
            a = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira outro valor");
            b = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira outro valor");
            c = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Insira outro valor");
            d = Convert.ToInt32(Console.ReadLine());
            somap = 0;
            if (a <= 0)
            { somap = somap + a; }
            else if (b <= 0)
            { somap = somap + b; }
            else if (c <= 0)
            { somap = somap + c; }
            else if (d <= 0)
            { somap = somap + d; }
            else { soman = a + b + c + d; }
            Console.WriteLine("A soma positiva é " + somap + " e a soma negativa é " + soman);
            Console.ReadKey();
        }
    }
}
