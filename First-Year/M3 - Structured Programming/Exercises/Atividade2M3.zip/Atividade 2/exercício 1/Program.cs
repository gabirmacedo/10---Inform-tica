﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int x, y;
            Console.WriteLine("Introduza um valor");
            x = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Introduza outro valor");
            y = Convert.ToInt32(Console.ReadLine());

            if (x > y)
            { Console.WriteLine(x + " é maior que " + y); }
            else if (y > x)
            { Console.WriteLine(y + " é maior que " + x); }
            else { Console.WriteLine(x + " e " + y + " são iguais."); }
                Console.ReadKey();
        }
    }
}
