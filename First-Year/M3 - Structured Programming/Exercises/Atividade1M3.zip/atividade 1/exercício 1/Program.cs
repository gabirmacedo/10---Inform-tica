﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercício_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double comp, larg, alt, vol;
            Console.WriteLine("Introduza as medidas do tanque");
            Console.WriteLine("comprimento da base");
            comp = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("largura da base");
            larg = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("altura do tanque");
            alt = Convert.ToDouble(Console.ReadLine());
            vol = (comp * larg * alt);
            Console.WriteLine("Volume = " + vol);
            Console.ReadKey();

        }
    }
}
